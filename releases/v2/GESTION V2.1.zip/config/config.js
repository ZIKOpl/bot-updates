module.exports = {

  "token": "MTQzMzU3OTM3Njk1MTI5NjEwMw.G_87i9.OH-nbU3lDsCbT4uHRuVGoznzcFrVrtGRBzTQqA",

  "bot_id": "1433579376951296103",

  "buyers": [

    "1398750844459024454"

  ],

  "prefix": "+",

  "panel": "81.254.194.142:3002",

  "default_color": "#000000"

};