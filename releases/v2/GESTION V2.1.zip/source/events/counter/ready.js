module.exports = {
    name: "clientReady",
    run: async (client) => {    
        setInterval(() => {
            client.guilds.cache.forEach(async guild => {
            const data = await client.db.get(`counters_${guild.id}`) || []
        
            data.forEach(async (channelData) => {
                const channel = guild.channels.cache.get(channelData.id)
                const role = await guild.roles.fetch(channelData.text.includes('[server.get/') ? channelData.text.split("/")[1].replace("]", "") : 111).catch(() => false)
                //console.log(role?.name)
                //console.log(channelData.text.includes('[server.get/') ? channelData.text.split("/")[1].replace("]", "") : 111)
                if (channel) channel.setName(
                    channelData.text
                        .replaceAll(`[server.get/${role?.id}]`, role ? role.members.size : 0)
                        .replaceAll("[server.roles]", `${guild.roles.cache.size}`)
                        .replaceAll("[server.channels]", `${guild.channels.cache.size}`)
                        .replaceAll("[server.boosts]", `${guild.premiumSubscriptionCount}`)
                        .replaceAll("[server.onlines]", `${guild.members.cache.filter(m => m.presence && m.presence.status != "offline").size}`)
                        .replaceAll("[server.idle]", `${guild.members.cache.filter(m => m.presence && m.presence.status == "idle").size}`)
                        .replaceAll("[server.dnd]", `${guild.members.cache.filter(m => m.presence && m.presence.status == "dnd").size}`)
                        .replaceAll("[server.offlines]", `${guild.members.cache.filter(m => m.presence && m.presence.status == "offline").size}`)
                        .replaceAll("[server.human]", `${guild.members.cache.filter(m => !m.user.bot).size}`)
                        .replaceAll("[server.bots]", `${guild.members.cache.filter(m => m.user.bot).size}`)
                        .replaceAll("[server.memberCount]", `${guild.memberCount}`)
                        .replaceAll("[server.voice]", `${guild.members.cache.filter(m => m.voice.channel).size}`)
                        .replaceAll("[server.name]", `${guild.name}`)
                        .replaceAll("[server.id]", `${guild.id}`)
                    )
                })
            })
        }, 1000 * 60 * 1)
    }
}