const Discord = require("discord.js");
const { ActivityType } = require("discord.js");
const Astroia = require("../../structures/client/index");

module.exports = {
    name: "ready",
    /**
     *
     * @param {Astroia} client
     */
    run: async (client) => {
        setInterval(() => { 
            // Récupère les données de la base de données
            const status = client.db.get('nomstatut') || "Brigade Du Net |";
            const custom = client.db.get('type') || "STREAMING";
            const presence = client.db.get('presence') || 'dnd';

            // Détermine le type d'activité à partir des données
            let activityType;
            let url = null;

            if (custom === "STREAMING") {
                activityType = ActivityType.Streaming;
                url = "https://twitch.tv/inoxtag"; // Remplace par une URL valide de stream actif
            } else if (custom === "WATCHING") {
                activityType = ActivityType.Watching;
            } else if (custom === "PLAYING") {
                activityType = ActivityType.Playing;
            } else if (custom === "LISTENING") {
                activityType = ActivityType.Listening;
            }

            // Options de présence
            const presenceOptions = {
                status: presence,  // 'online', 'idle', 'dnd', etc.
                activities: [{
                    name: status,
                    type: activityType,
                    url: url // Ajoute l'URL uniquement pour le type STREAMING
                }]
            };

            // Met à jour la présence du bot
            client.user.setPresence(presenceOptions);
        
        }, 5000); // Met à jour toutes les 5 secondes
    }
};
