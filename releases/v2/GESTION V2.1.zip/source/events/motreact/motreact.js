const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

// Assurez-vous que ce code se trouve dans un fichier approprié, comme 'messageCreate.js'.
module.exports = {
    name: 'messageCreate',
    run: async (client, message) => {
        // Ignorer les messages du bot lui-même
        if (message.author.bot) return;

        // Récupérer la liste des mots et des émojis pour le serveur actuel
        const currentWords = getWordList(client, message.guild.id);

        // Vérifier chaque mot et émoji dans la liste
        for (const { word, emoji } of currentWords) {
            // Vérifier si le message contient le mot
            if (message.content.toLowerCase().includes(word.toLowerCase())) {
                try {
                    // Réagir au message avec l'émoji correspondant
                    await message.react(emoji);
                } catch (error) {
                    console.error(`Erreur lors de la réaction avec l'émoji ${emoji}:`, error);
                }
            }
        }
    }
};

// Fonction pour obtenir la liste des mots et des émojis
const getWordList = (client, guildId) => {
    return client.db.get(`reactmot_words.${guildId}`) || [];
};
