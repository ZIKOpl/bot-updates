const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'interactionCreate',
    /**
     * @param {Astroia} client
     * @param {Discord.Interaction} interaction
     */
    run: async (client, interaction) => {
        // Vérifier si l'interaction est un menu contextuel pour signaler un message
        if (interaction.isMessageContextMenuCommand() && interaction.commandName === 'report') {
            const reportedMessage = interaction.targetMessage; // Le message signalé
            const reportingUser = interaction.user; // L'utilisateur qui a signalé
            const reportTime = new Date(); // Heure du report
            const reportedMessageLink = `https://discord.com/channels/${interaction.guild.id}/${reportedMessage.channelId}/${reportedMessage.id}`; // Lien du message

            // Récupérer la configuration du système de report depuis la base de données
            const db = client.db.get(`report_${interaction.guild.id}`);
            if (!db || db.status !== true || !db.channel) {
                await interaction.reply({ content: 'La fonctionnalité de signalement n\'est pas configurée sur ce serveur.', ephemeral: true });
                return;
            }

            // Vérifier si l'utilisateur a les rôles nécessaires pour reporter
            const requiredRoles = db.role;
            if (requiredRoles && requiredRoles.length > 0) {
                const member = interaction.guild.members.cache.get(interaction.user.id);
                const hasRequiredRole = requiredRoles.some((roleId) => member.roles.cache.has(roleId));

                if (!hasRequiredRole) {
                    await interaction.reply({ content: 'Vous n\'avez pas le rôle requis pour effectuer un signalement.', ephemeral: true });
                    return;
                }
            }

            // Couleur pour l'embed
            const color = client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;

            // Canal où le report doit être envoyé
            const reportChannel = interaction.guild.channels.cache.get(db.channel);
            if (!reportChannel) {
                await interaction.reply({ content: 'Le canal de report est introuvable ou mal configuré.', ephemeral: true });
                return;
            }

            // Utilisateur dont le message est signalé
            const reportedUser = reportedMessage.author;

            // Création de l'embed de report
            const embed = new EmbedBuilder()
                .setColor(color)
                .setTitle(`Signalement de ${reportingUser.username}`)
                .addFields(
                    { name: 'Contenu du message :', value: `\`\`\`yml\n${reportedMessage.content || "Message avec embed ou image"}\`\`\`` },
                    { name: 'Signalé par', value: `\`\`\`yml\n${reportingUser.tag} - (${reportingUser.id})\`\`\`` },
                    { name: 'Personne concernée :', value: `\`\`\`yml\n${reportedUser.username} - (${reportedUser.id})\`\`\`` },
                    { name: 'Bot :', value: `\`\`\`yml\n${reportedUser.bot ? '✅' : '❌'}\`\`\`` },
                    { name: 'Lien du message', value: `[[Clique ici]](${reportedMessageLink})` },
                    { name: 'Date', value: `<t:${Math.floor(reportTime / 1000)}:D> à <t:${Math.floor(reportTime / 1000)}:T> (<t:${Math.floor(reportTime / 1000)}:R>)` }
                )
                .setFooter(client.footer);

            // Envoyer l'embed de report dans le canal configuré
            await reportChannel.send({ embeds: [embed] });

            // Répondre à l'utilisateur pour confirmer la prise en compte du report
            await interaction.reply({ content: 'Votre signalement a bien été pris en compte !', ephemeral: true });
        }
    },
};
