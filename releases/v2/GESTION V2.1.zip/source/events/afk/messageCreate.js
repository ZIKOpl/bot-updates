const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageCreate', // The event to listen for when a new message is created
    run: async (client, message) => {
        // Ignore messages from bots
        if (message.author.bot) return;

        // Check if the message mentions someone
        const mentionedUsers = message.mentions.users;
        mentionedUsers.forEach(async (user) => {
            // Check if the mentioned user is AFK
            const reason = client.db.get(`afk_${user.id}`);
            if (reason) {
                // Create an embed to inform that the user is AFK
                const embed = new EmbedBuilder()
                    .setTitle('Utilisateur AFK')
                    .setDescription(`<@${user.id}> est actuellement AFK.`) // Pinge le user
                    .addFields({ name: 'Raison', value: reason || 'Non spécifiée' })
                    .setColor(client.color); // Or use client.color

                // Send the embed in the channel where the mention happened
                await message.channel.send({ embeds: [embed] });
            }
        });

        // Optionally, check if the message author is AFK and remove their status if they send a message
        const afkReason = client.db.get(`afk_${message.author.id}`);
        if (afkReason) {
            // Remove AFK status from the user
            client.db.delete(`afk_${message.author.id}`);
            // Send a message to inform the user that they are no longer AFK
            const embed = new EmbedBuilder()
                .setTitle('Vous n\'êtes plus AFK')
                .setDescription(`Vous avez été retiré du mode AFK.`)
                .setColor(client.color); // Or use client.color

            await message.channel.send({ embeds: [embed] });
        }
    }
};
