const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberUpdate',
    /**
     * @param {GuildMember} oldMember
     * @param {GuildMember} newMember
     */
    async execute(oldMember, newMember) {
        // Récupérer le rôle de Nitro Booster
        const boostRole = newMember.guild.roles.premiumSubscriberRole;

        // Récupérer le statut de boost et le salon configuré dans la base de données
        const boostStatus = await newMember.guild.client.db.get(`boost_status_${newMember.guild.id}`);
        const boostChannelId = await newMember.guild.client.db.get(`boost_channel_${newMember.guild.id}`);

        // Log retrieved values
        console.log(`Boost Status: ${boostStatus}, Boost Channel ID: ${boostChannelId}`);

        // Vérifier si le salon est défini
        const boostChannel = boostChannelId ? newMember.guild.channels.cache.get(boostChannelId) : null;

        // Check if channel exists and if the bot has permissions
        if (boostChannel && !boostChannel.permissionsFor(newMember.guild.me).has(['SEND_MESSAGES', 'EMBED_LINKS'])) {
            console.error('Bot does not have permission to send messages in the boost channel.');
            return;
        }

        // Log old and new roles
        console.log('Old Roles:', oldMember.roles.cache.map(role => role.name));
        console.log('New Roles:', newMember.roles.cache.map(role => role.name));

        // Vérifier si le membre vient de booster
        if (!oldMember.roles.cache.has(boostRole?.id) && newMember.roles.cache.has(boostRole?.id)) {
            if (boostStatus === 'Activé' && boostChannel) { // Only send if enabled and channel exists
                // Le membre a commencé à booster
                const boostEmbed = new EmbedBuilder()
                    .setTitle(`🎉 ${newMember.user.username} vient de booster le serveur !`)
                    .setDescription(`<@${newMember.id}> est un nouveau booster sur le serveur ! :boost~4:`)
                    .setColor('#FF73FA') // Couleur rose pour le boost
                    .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: `Boosté le ${new Date().toLocaleDateString()}` });

                await boostChannel.send({ embeds: [boostEmbed] });
            }
        }

        // Vérifier si le membre a arrêté de booster
        if (oldMember.roles.cache.has(boostRole?.id) && !newMember.roles.cache.has(boostRole?.id)) {
            if (boostStatus === 'Activé' && boostChannel) { // Only send if enabled and channel exists
                // Le membre a arrêté de booster
                const unboostEmbed = new EmbedBuilder()
                    .setTitle(`😢 ${newMember.user.username} a arrêté de booster le serveur`)
                    .setDescription(`Merci à <@${newMember.id}> pour le boost, votre soutien nous manque déjà.`)
                    .setColor('#FF0000') // Couleur rouge pour signaler un départ
                    .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: `Boost retiré le ${new Date().toLocaleDateString()}` });

                await boostChannel.send({ embeds: [unboostEmbed] });
            }
        }
    },
};
