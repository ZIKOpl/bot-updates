const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'webhooksUpdate',
    run: async (client, oldWebhooks, newWebhooks) => {
        console.log('WebhooksUpdate event triggered'); // Debug log

        const guild = oldWebhooks.guild;
        const antiwebhook = client.db.get(`antiwebhook_${guild.id}`);
        if (!antiwebhook || antiwebhook.status === 'off') {
            console.log('Antiwebhook is not active or turned off.');
            return;
        }

        console.log('Antiwebhook is active'); // Debug log

        let webhookUpdater = null;
        let webhookId = null;

        try {
            const auditLogs = await guild.fetchAuditLogs({
                type: 15, // WEBHOOK_UPDATE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                webhookUpdater = entry.executor;
                webhookId = entry.target.id; // Get the webhook ID from the audit log
                console.log(`Webhook updated by: ${webhookUpdater.tag}`);
                console.log(`Webhook ID from audit logs: ${webhookId}`);
            } else {
                console.log('No audit log entry found for webhook update.');
                return;
            }
        } catch (error) {
            console.error('Error fetching audit logs:', error);
            return;
        }

        if (webhookUpdater.id === client.user.id || webhookUpdater.id === guild.ownerId) {
            console.log('Updater is the bot or the guild owner. Skipping sanction.');
            return;
        }

        const whitelisted = client.db.get(`wl.${guild.id}`) || [];
        if (whitelisted.includes(webhookUpdater.id)) {
            console.log(`User ${webhookUpdater.tag} is whitelisted and will not be sanctioned.`);
            return;
        }

        // Adding a short delay to ensure the webhook is synced
        await new Promise(resolve => setTimeout(resolve, 2000));

        // Attempt to delete the webhook multiple times with a short delay between attempts
        for (let attempt = 0; attempt < 3; attempt++) {
            try {
                const webhooks = await guild.fetchWebhooks();
                console.log(`Fetched ${webhooks.size} webhooks.`);
                const webhook = webhooks.find(w => w.id === webhookId);
                if (webhook) {
                    await webhook.delete('Deleted due to antiwebhook rule');
                    console.log(`Webhook ${webhookId} deleted.`);
                    break; // Exit loop if deletion is successful
                } else {
                    console.error('Webhook not found for ID:', webhookId);
                }
            } catch (error) {
                console.error(`Error fetching or deleting webhook (attempt ${attempt + 1}): ${error}`);
            }
            await new Promise(resolve => setTimeout(resolve, 2000)); // Wait before retrying
        }

        // Determine the sanction based on the configuration
        const sanction = antiwebhook.updateSanction || 'none';
        console.log(`Sanction determined: ${sanction}`);

        // Apply the sanction
        try {
            const member = guild.members.resolve(webhookUpdater.id);
            if (!member) {
                console.error('Member not found for updater ID:', webhookUpdater.id);
                return;
            }

            if (sanction === 'derank') {
                const rolesToRemove = member.roles.cache.map(role => role.id);
                await member.roles.remove(rolesToRemove);
                console.log(`All roles removed from ${member.user.tag}.`);

                const everyoneRole = guild.roles.everyone;
                if (everyoneRole && !member.roles.cache.has(everyoneRole.id)) {
                    await member.roles.add(everyoneRole.id);
                    console.log(`@everyone role added to ${member.user.tag}.`);
                }
            } else if (sanction === 'kick') {
                await member.kick('Antiwebhook - webhook update');
                console.log(`User ${member.user.tag} kicked for webhook update.`);
            } else if (sanction === 'ban') {
                await guild.bans.create(member.id, { reason: 'Antiwebhook - webhook update' });
                console.log(`User ${member.user.tag} banned for webhook update.`);
            } else {
                console.error(`Unrecognized sanction: ${sanction}`);
            }
        } catch (error) {
            console.error(`Error applying sanction: ${error}`);
        }

        // Log the action if logging is enabled
        const logChannelId = client.db.get(`raidlogs_${guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Webhook Updated')
                    .setDescription(`Un webhook a été mis à jour sur le serveur par <@${webhookUpdater.id}>. L'utilisateur a été ${sanction}.`)
                    .setColor(client.color || '#5a65ff')
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] });
            } else {
                console.error('Log channel not found for ID:', logChannelId);
            }
        } else {
            console.error('Log channel ID not configured.');
        }
    }
};
