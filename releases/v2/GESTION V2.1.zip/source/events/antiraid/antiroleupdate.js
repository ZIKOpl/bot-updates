const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'roleUpdate',
    run: async (client, oldRole, newRole) => {
        // Vérifiez si la mise à jour de rôle est surveillée
        const antirole = client.db.get(`antirole_${newRole.guild.id}`);
        if (!antirole || antirole.status === 'off') return;

        // Fetch the audit logs to determine who updated the role
        let roleUpdater = null;
        try {
            const auditLogs = await newRole.guild.fetchAuditLogs({
                type: 31, // ROLE_UPDATE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                roleUpdater = entry.executor;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the updater is the bot or the guild owner
        if (!roleUpdater || roleUpdater.id === client.user.id || roleUpdater.id === newRole.guild.ownerId) return;

        // Check if the updater is whitelisted
        const whitelisted = client.db.get(`wl.${newRole.guild.id}`) || [];
        if (whitelisted.includes(roleUpdater.id)) {
            console.log(`L'utilisateur ${roleUpdater.tag} est en whitelist et ne sera pas sanctionné.`);
            return;
        }

        // Vérifiez les différences importantes avant de loguer
        const significantChanges = [];

        // Comparaison des permissions
        if (!oldRole.permissions.equals(newRole.permissions)) {
            significantChanges.push('permissions');
        }

        // Comparaison des couleurs
        if (oldRole.color !== newRole.color) {
            significantChanges.push('color');
        }

        // Comparaison de la mention
        if (oldRole.mentionable !== newRole.mentionable) {
            significantChanges.push('mentionable');
        }

        // Comparaison de la position
        if (oldRole.position !== newRole.position) {
            significantChanges.push('position');
        }

        // Si aucune différence significative n'est trouvée, ne pas loguer
        if (significantChanges.length === 0) {
            return console.log('Aucune modification significative détectée dans le rôle.');
        }

        // Determine the sanction based on the configuration
        const sanction = antirole.updateSanction || 'none'; // Default to 'none' if not set

        if (sanction === 'derank') {
            const member = newRole.guild.members.resolve(roleUpdater.id);
            if (member) {
                try {
                    // Retirer tous les rôles du membre
                    const rolesToRemove = member.roles.cache.map(role => role.id);
                    await member.roles.remove(rolesToRemove);
                    console.log(`Tous les rôles ont été retirés pour ${member.user.tag}.`);
        
                    // Ajouter le rôle @everyone (si nécessaire)
                    const everyoneRole = newRole.guild.roles.everyone;

                    if (everyoneRole) {
                        try {
                            if (!member.roles.cache.has(everyoneRole.id)) {
                                await member.roles.add(everyoneRole.id);
                                console.log(`Le rôle @everyone a été ajouté pour ${member.user.tag}.`);
                            }
                        } catch (error) {
                            console.error('Erreur lors de l\'ajout du rôle @everyone :', error);
                        }
                    } else {
                        console.error('Le rôle @everyone n\'est pas trouvé sur le serveur.');
                    }
                    
                } catch (error) {
                    console.error('Erreur lors du retrait des rôles du membre :', error);
                }

                // Restore the role to its previous state
                try {
                    await oldRole.edit({
                        permissions: oldRole.permissions // Reapply the old permissions
                    });
                    console.log(`Les permissions du rôle ${oldRole.name} ont été restaurées.`);
                } catch (error) {
                    console.error('Erreur lors de la restauration des permissions du rôle :', error);
                }
            } else {
                console.error('Membre non trouvé pour le créateur ID:', roleUpdater.id);
            }
        } else if (sanction === 'kick') {
            try {
                await newRole.guild.members.kick(roleUpdater.id, 'Antirole - mise à jour de rôle');
                console.log(`L'utilisateur ${roleUpdater.tag} a été expulsé pour la mise à jour de rôle.`);
            } catch (error) {
                console.error('Erreur lors de l\'expulsion du membre :', error);
            }
        } else if (sanction === 'ban') {
            try {
                await newRole.guild.bans.create(roleUpdater.id, { reason: 'Antirole - mise à jour de rôle' });
                console.log(`L'utilisateur ${roleUpdater.tag} a été banni pour la mise à jour de rôle.`);
            } catch (error) {
                console.error('Erreur lors du bannissement du membre :', error);
            }
        } else {
            console.error(`Sanction non reconnue : ${sanction}`);
        }

        // Log the action if logging is enabled and there are significant changes
        const logChannelId = client.db.get(`raidlogs_${newRole.guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Rôle Mis à Jour')
                    .setDescription(`Le rôle **${oldRole.name}** a été mis à jour par <@${roleUpdater.id}>. Changement(s) détecté(s): **${significantChanges.join(', ')}**. Sanction appliquée: **${sanction}**.`)
                    .setColor(client.color || '#5a65ff')
                    .setTimestamp()
                    .setFooter(client.footer || 'Log Antirole' ); // Assurez-vous que `client.footer` est bien défini

                logChannel.send({ embeds: [embed] });
            }
        }
    }
};
