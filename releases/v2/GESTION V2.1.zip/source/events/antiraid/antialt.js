const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberAdd',
    run: async (client, member) => {
        // Vérifiez si l'anti-alt est activé
        const antialtData = client.db.get(`antialt_${member.guild.id}`) || { status: 'off', duration: '0d' };
        if (antialtData.status === 'off') return;

        const duration = antialtData.duration;
        const now = Date.now();
        let threshold = now;

        // Convertir la durée en millisecondes
        let durationInMs = 0;
        if (duration.endsWith('d')) durationInMs = parseInt(duration) * 24 * 60 * 60 * 1000;
        else if (duration.endsWith('h')) durationInMs = parseInt(duration) * 60 * 60 * 1000;
        else if (duration.endsWith('w')) durationInMs = parseInt(duration) * 7 * 24 * 60 * 60 * 1000;
        else if (duration.endsWith('m')) durationInMs = parseInt(duration) * 30 * 24 * 60 * 60 * 1000;
        else if (duration.endsWith('y')) durationInMs = parseInt(duration) * 365 * 24 * 60 * 60 * 1000;

        threshold -= durationInMs;

        // Vérifier l'âge du compte
        if (member.user.createdTimestamp > threshold) {
            try {
                await member.kick('Compte trop jeune pour rejoindre le serveur.');

                const logChannelId = client.db.get(`raidlogs_${member.guild.id}`);
                if (logChannelId) {
                    const logChannel = client.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const embed = new EmbedBuilder()
                            .setColor(client.color || '#5a65ff')
                            .setTitle('Action : Kick')
                            .setDescription(`**Utilisateur :** ${member.user.tag} (${member.user.id})\n**Raison :** Compte trop jeune (créé le ${new Date(member.user.createdTimestamp).toLocaleDateString()})\n**Durée minimum requise :** ${duration}`)
                            .setTimestamp()
                            .setFooter(client.footer);

                        await logChannel.send({ embeds: [embed] });
                        console.log(`Log envoyé pour le kick de ${member.user.tag}.`);
                    } else {
                        console.error(`Le canal de log avec l'ID ${logChannelId} est introuvable.`);
                    }
                } else {
                    console.error(`L'ID du canal de log est introuvable dans la base de données.`);
                }

                console.log(`Utilisateur ${member.user.tag} kické pour avoir un compte trop jeune.`);
            } catch (error) {
                console.error(`Erreur lors du kick de ${member.user.tag}:`, error);

                const errorEmbed = new EmbedBuilder()
                    .setColor(client.color || '#5a65ff')
                    .setTitle('Erreur de Kick')
                    .setDescription(`**Utilisateur :** ${member.user.tag} (${member.user.id})\n**Erreur :** ${error.message}`)
                    .setTimestamp()
                    .setFooter(client.footer);

                const logChannelId = client.db.get(`logChannel_${member.guild.id}`);
                if (logChannelId) {
                    const logChannel = client.channels.cache.get(logChannelId);
                    if (logChannel) {
                        await logChannel.send({ embeds: [errorEmbed] });
                    } else {
                        console.error(`Le canal de log avec l'ID ${logChannelId} est introuvable.`);
                    }
                } else {
                    console.error(`L'ID du canal de log est introuvable dans la base de données.`);
                }
            }
        }
    }
};
