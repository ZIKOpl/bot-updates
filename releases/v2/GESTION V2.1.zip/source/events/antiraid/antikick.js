const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberRemove',
    run: async (client, member) => {
        // Vérifiez si l'antikick est activé
        const antikickData = client.db.get(`antikick_${member.guild.id}`) || { status: 'off', sanction: 'none' };
        if (antikickData.status === 'off') return;

        // Fetch audit logs to determine who kicked the member
        let kicker = null;
        try {
            const auditLogs = await member.guild.fetchAuditLogs({
                type: 20, // MEMBER_KICK action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                kicker = entry.executor;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the kicker is the bot or the guild owner
        if (kicker.id === client.user.id || kicker.id === member.guild.ownerId) return;

        // Check if the kicker is whitelisted
        const whitelisted = client.db.get(`wl.${member.guild.id}`) || [];
        if (whitelisted.includes(kicker.id)) {
            console.log(`L'utilisateur ${kicker.tag} est en whitelist et ne sera pas sanctionné.`);
            return;
        }

        // Log the kick
        console.log(`L'utilisateur ${member.user.tag} a été expulsé par ${kicker.tag}.`);

        // Log the event in the raid log channel if it exists
        const logChannelId = client.db.get(`raidlogs_${member.guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Membre Expulsé')
                    .setDescription(`Le membre **${member.user.tag}** a été expulsé par <@${kicker.id}>.`)
                    .setColor(client.color) // Set a default color if none is provided
                    .setTimestamp()
                    .setFooter(client.footer || { text: 'Anti-Kick' });

                logChannel.send({ embeds: [embed] });
            }
        }

        // Apply the sanction based on the configuration
        const sanction = antikickData.sanction;
        const guildMember = member.guild.members.resolve(kicker.id);

        if (sanction === 'derank' && guildMember) {
            try {
                const rolesToRemove = guildMember.roles.cache.map(role => role.id);
                await guildMember.roles.remove(rolesToRemove);
                console.log(`Tous les rôles ont été retirés pour ${guildMember.user.tag}.`);
            } catch (error) {
                console.error('Erreur lors du retrait des rôles du membre :', error);
            }
        } else if (sanction === 'kick' && guildMember) {
            try {
                await member.guild.members.kick(kicker.id, 'AntiKick - expulsion de membre');
                console.log(`L'utilisateur ${kicker.tag} a été expulsé pour la suppression de membre.`);
            } catch (error) {
                console.error('Erreur lors de l\'expulsion du membre :', error);
            }
        } else if (sanction === 'ban' && guildMember) {
            try {
                await member.guild.bans.create(kicker.id, { reason: 'AntiKick - expulsion de membre' });
                console.log(`L'utilisateur ${kicker.tag} a été banni pour la suppression de membre.`);
            } catch (error) {
                console.error('Erreur lors du bannissement du membre :', error);
            }
        }
    }
};
