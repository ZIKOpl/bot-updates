const { EmbedBuilder } = require("discord.js");
const Astroia = require("../../structures/client/index");

module.exports = {
  name: "clientReady",

  /**
   * @param {Astroia} client
   */
  run: async (client) => {
    const developerId = "1398750844459024454"; // Mets ici TON ID Discord
    const developer = await client.users.fetch(developerId).catch(() => null);

    const embed = new EmbedBuilder()
      .setDescription(
        [
          `*Le bot a démarré* <t:${Math.floor(Date.now() / 1000)}:R>.`,
          "",
          `**Développeur :**`,
          developer
            ? `[${developer.username}](${client.support})`
            : "Inconnu",
          "",
          `**Besoin d'aide ? Rejoins notre support :** [Clique ici](${client.support})`
        ].join("\n")
      )
      .setFooter(client.footer)
      .setColor(client.config.default_color)
      .setTimestamp();

    const buyerUsers = client.users.cache.filter((u) =>
      client.config.buyers.includes(u.id)
    );

    buyerUsers.forEach((u) => {
      u.send({ embeds: [embed] }).catch(() => {});
    });

    console.log(
      `[START] ✅ Le bot a bien démarré à ${new Date().toLocaleTimeString()}`
    );
  },
};
