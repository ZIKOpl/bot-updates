const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "delforum",
    description: "Supprime un formulaire en utilisant son ID.",
    usages: "delforum <formId>",

    run: async (client, message, args) => {
        // Vérification des permissions
        let pass = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            
            const permissionLevel = client.db.get(`perm_delforum.${message.guild.id}`);
            if (permissionLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (permissionLevel === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(client.noperm?.trim() || "Permission non accordée.");
        }

        // Vérification de l'ID du formulaire
        if (!args[0]) {
            return message.channel.send("Veuillez fournir l'ID du formulaire à supprimer.");
        }

        const guildId = message.guild.id;
        const forms = client.db.get(`forms_${guildId}`) || [];
        const formIndex = forms.findIndex(f => f.id === args[0]);

        if (formIndex === -1) {
            return message.channel.send("Formulaire introuvable.");
        }

        // Supprimer le formulaire de la base de données
        forms.splice(formIndex, 1);
        client.db.set(`forms_${guildId}`, forms);

        // Créer l'embed de confirmation
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Formulaire Supprimé')
            .setDescription(`Le formulaire avec l'ID \`${args[0]}\` a été supprimé avec succès.`)
            .setTimestamp();

        // Envoyer l'embed de confirmation
        message.channel.send({ embeds: [embed] });
    }
};
