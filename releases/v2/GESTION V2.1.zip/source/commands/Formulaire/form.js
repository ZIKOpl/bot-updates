const { ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {
    name: "formulaire",
    description: "Crée un formulaire avec plusieurs étapes.",
    usages: "formulaire",

    run: async (client, message, args) => {
        // Vérification des permissions
        let pass = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            
            const permissionLevel = client.db.get(`perm_formulaire.${message.guild.id}`);
            if (permissionLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(client.noperm?.trim() || "Permission non accordée.");
        }

        const filter = m => m.author.id === message.author.id;

        // Créer un nouvel objet de formulaire
        const newForm = {
            id: `form-${Date.now()}`, // Génération simple d'un identifiant unique basé sur le timestamp
            title: '',
            postChannelId: '',
            formMessage: '',
            logChannelId: '',
            buttonText: '',
            buttonColor: '',
            options: []
        };

        // Étape 1 : Demander le titre du formulaire
        await message.channel.send("Quel est le titre du formulaire ? (Exemple : 'AstroBot')");
        const titleResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        newForm.title = titleResponse.first().content;

        // Étape 2 : Demander dans quel salon le formulaire sera posté
        await message.channel.send("Dans quel salon le formulaire sera-t-il posté ? (Indiquez son ID)");
        const channelResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        newForm.postChannelId = channelResponse.first().content;

        // Étape 3 : Demander le message du formulaire
        await message.channel.send("Quel est le message du formulaire ?");
        const messageResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        newForm.formMessage = messageResponse.first().content;

        // Étape 4 : Demander l'ID du salon pour les logs
        await message.channel.send("Dans quel salon les logs doivent-ils être envoyés ?");
        const logChannelResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        newForm.logChannelId = logChannelResponse.first().content;

        // Étape 5 : Demander le texte du bouton
        await message.channel.send("Quel est le texte du bouton ?");
        const buttonTextResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        newForm.buttonText = buttonTextResponse.first().content;

        // Étape 6 : Demander la couleur du bouton
        let buttonColor;
        const validColors = ['Primary', 'Secondary', 'Success', 'Danger', 'Link'];

        while (!validColors.includes(buttonColor)) {
            await message.channel.send("Quelle est la couleur du bouton ? (Options : 'Primary', 'Secondary', 'Success', 'Danger', 'Link')");
            const buttonColorResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
            buttonColor = buttonColorResponse.first().content.charAt(0).toUpperCase() + buttonColorResponse.first().content.slice(1).toLowerCase();

            if (!validColors.includes(buttonColor)) {
                await message.channel.send("Couleur invalide. Veuillez choisir parmi les options suivantes : " + validColors.join(', '));
            }
        }
        newForm.buttonColor = buttonColor;

        // Étape 7 : Demander le nombre d'options
        await message.channel.send("Combien d'options voulez-vous ajouter au formulaire ? (Veuillez entrer un nombre entre 1 et 5)");
        const optionsCountResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        const optionsCount = parseInt(optionsCountResponse.first().content);

        if (optionsCount < 1 || optionsCount > 5) {
            return message.channel.send("Le nombre d'options doit être entre 1 et 5.");
        }

        // Étape 8 : Entrer les options une par une
        for (let i = 0; i < optionsCount; i++) {
            await message.channel.send(`Entrez l'option ${i + 1} :`);
            const optionResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
            newForm.options.push(optionResponse.first().content);
        }

        // Récupérer la liste actuelle des formulaires ou initialiser un tableau vide
        const existingForms = client.db.get(`forms_${message.guild.id}`) || [];
        existingForms.push(newForm); // Ajouter le nouveau formulaire à la liste
        client.db.set(`forms_${message.guild.id}`, existingForms); // Mettre à jour la base de données

        // Préparer l'envoi du formulaire
        const postChannel = message.guild.channels.cache.get(newForm.postChannelId);
        if (!postChannel) {
            return message.channel.send("Le salon pour le formulaire est introuvable.");
        }

        const logChannel = message.guild.channels.cache.get(newForm.logChannelId);
        if (!logChannel) {
            return message.channel.send("Le salon pour les logs est introuvable.");
        }

        // Créer le bouton
        const button = new ButtonBuilder()
            .setCustomId('form_button')
            .setLabel(newForm.buttonText)
            .setStyle(newForm.buttonColor);

        const row = new ActionRowBuilder().addComponents(button);

        // Envoyer le formulaire
        await postChannel.send(`**Titre du Formulaire :** ${newForm.title}\n**Message :** ${newForm.formMessage}\n**Options :** ${newForm.options.join(', ')}\n**ID du Formulaire :** ${newForm.id}`, { components: [row] });

        message.channel.send("Le formulaire a été créé et envoyé ! Vous pouvez l'envoyer à nouveau avec l'ID : " + newForm.id);
    }
};
