const Discord = require('discord.js');
const Valory = require('../../structures/client/index');
const ms = require('ms');

module.exports = {
    name: 'ticket',
    aliases: ["tickets"],
    description: 'Permet de créer/configurer le système de ticket.',
    /**
     * @param {Valory} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        // Vérification des permissions
        let pass = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        const msg = await message.channel.send({ content: 'Chargement...' });

        async function updatefirst() {
            const db = await client?.db.get(`ticket_${message.guild.id}`) || {
                option: [],
                salon: null,
                messageidoption: null,
                type: "select",
                Suppauto: true,
                messageid: null,
                maxticket: 1,
                leaveclose: false,
                claimbutton: true,
                buttonclose: true,
                transcript: false,
                rolerequis: null,
                roleinterdit: null,
            };

            let modules = '';
            switch (db.type) {
                case 'select':
                    modules = "Sélecteur";
                    break;
                case "button":
                    modules = "Boutons";
                    break;
            }
            const embed = new Discord.EmbedBuilder()
                .setTitle("Paramètres des tickets")
                .setColor(client.color)
                .setFooter(client.footer)
                .addFields({ name: "Salon", value: `${client.channels.cache.get(db.salon) || "Aucun"}`, inline: true })
                .addFields({ name: "Message", value: `${db.messageidoption || "Aucun"}`, inline: true })
                .addFields({ name: "Type", value: `${modules}`, inline: true })
                .addFields({ name: "Claim", value: `${db.claimbutton ? "✅" : "❌"}`, inline: true })
                .addFields({ name: "Nombre maximum de ticket par personne", value: `${db.maxticket}`, inline: true })
                .addFields({ name: "Fermer automatiquement les tickets des membres quittant le serveur", value: `${db.leaveclose ? "✅" : "❌"}`, inline: true })
                .addFields({ name: "Bouton claim", value: `${db.claimbutton ? "✅" : "❌"}`, inline: true })
                .addFields({ name: "Bouton close", value: `${db.buttonclose ? "✅" : "❌"}`, inline: true })
                .addFields({ name: "Transcript MP", value: `${db.transcript ? "✅" : "❌"}`, inline: true })
                .addFields({ name: "Options", value: db.option.map(option => option.text).join('\n') || "Aucune", inline: true });

            const optionselect = db.option.map(options => ({
                label: options.text,
                description: options.description || "Aucune",
                value: options.value
            }));




            const selectoption = new Discord.StringSelectMenuBuilder()
                .setCustomId('selectoption')
                .setPlaceholder('Gérer les options')
                .addOptions([...optionselect, {
                    label: 'Ajouter une option...',
                    emoji: "➕",
                    value: 'addoption'
                }]);

            const buttons = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('activer')
                    .setLabel('✅ Valider et activer')
                    .setStyle(3)
            )
            const selectMenu = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.StringSelectMenuBuilder()
                        .setCustomId('selectconfigticket')
                        .setPlaceholder('Configuration des tickets')
                        .addOptions([
                            {
                                label: 'Modifier le salon',
                                emoji: '🏷',
                                value: 'salon'
                            },
                            {
                                label: 'ID du Message',
                                emoji: '🆔',
                                value: 'messageidoption'
                            },
                            {
                                label: 'Type button/selecteur',
                                emoji: '⏺',
                                value: 'type'
                            },
                            {
                                label: 'Claim',
                                emoji: "🛡",
                                value: 'claim'
                            },
                            {
                                label: 'Transcript MP',
                                emoji: "📚",
                                value: 'transcript'
                            },
                            {
                                label: 'Max tickets',
                                emoji: "♻",
                                value: 'maxticket'
                            },
                            {
                                label: 'Fermeture au leave',
                                emoji: '🔒',
                                value: 'fermetureleave'
                            }
                        ])
                );

            const row = new Discord.ActionRowBuilder().addComponents(selectoption)
            msg.edit({
                embeds: [embed], content: null, components: [row, selectMenu, buttons]
            })
        }
        updatefirst()

        const collector = msg.createMessageComponentCollector()
        collector.on('collect', async i => {
            if (i.user.id !== message.author.id) return i.reply({ content: "Tu n'es pas autorisé à interagir avec cette interaction !", flags: 64 })
            const dbone = await client?.db.get(`ticket_${message.guild.id}`) || {
                option: [],
                salon: null,
                messageidoption: null,
                type: "select",
                Suppauto: true,
                maxticket: 1,
                leaveclose: false,
                claimbutton: true,
                buttonclose: true,
                transcript: false,
                rolerequis: [],
                roleinterdit: [],
            }

            if (i.customId === 'retourmenu') {
                updatefirst()
                i.deferUpdate()
                return;
            }

            if (i.customId === 'activer') {
                // Vérifie que le système de tickets est configuré
                if (!dbone || !dbone.option || dbone.option.length === 0) {
                    return i.reply({ content: "Le système de tickets (les options) n'est pas configuré.", flags: 64 });
                }
                if (!dbone.salon) {
                    return i.reply({ content: "Le système de tickets (le salon) n'est pas configuré.", flags: 64 });
                }
            
                // Crée les composants (boutons ou sélecteurs) basés sur les options
                const rows = [];
            
                if (dbone.type === 'button') {
                    // Création des boutons
                    const buttons = dbone.option.map(option => {
                        const button = new Discord.ButtonBuilder()
                            .setCustomId(`ticket_${option.value}`)
                            .setLabel(option.text)
                            .setStyle(2); // Type de bouton
            
                        // Ajoute l'emoji si nécessaire
                        const regex = /<:(.*):(\d+)>/;
                        if (option.emoji) {
                            const match = option.emoji.match(regex);
                            if (match) {
                                const emojiid = match[2];
                                const emojibot = client.emojis.cache.get(emojiid);
                                if (emojibot) {
                                    button.setEmoji(emojiid);
                                }
                            }
                        }
                        return button;
                    });
            
                    // Crée une ligne d'ActionRow pour les boutons
                    const row = new Discord.ActionRowBuilder().addComponents(buttons);
                    rows.push(row);
            
                } else if (dbone.type === 'select') {
                    // Création du sélecteur
                    const options = dbone.option.map(option => {
                        const regex = /<:(.*):(\d+)>/;
                        let emoji = undefined;
            
                        if (option.emoji) {
                            const match = option.emoji.match(regex);
                            if (match) {
                                const emojiid = match[2];
                                const emojibot = client.emojis.cache.get(emojiid);
                                if (emojibot) {
                                    emoji = emojiid;
                                }
                            }
                        }
            
                        return {
                            label: option.text,
                            description: option.description || '',
                            value: `ticket_${option.value}`,
                            emoji: emoji ? emoji : undefined
                        };
                    });
            
                    // Crée une ligne d'ActionRow pour le sélecteur
                    const row = new Discord.ActionRowBuilder().addComponents(
                        new Discord.StringSelectMenuBuilder()
                            .setCustomId('ticket')
                            .addOptions(options)
                    );
                    rows.push(row);
                }
            
                // Trouve le salon et le message à mettre à jour
                const channel = i.guild.channels.cache.get(dbone.salon);
                if (!channel) {
                    return i.reply({ content: "Le salon de tickets configuré n'existe pas.", flags: 64 });
                }
            
                try {
                    const message = await channel.messages.fetch(dbone.messageidoption);
                    if (!message) {
                        return i.reply({ content: "Aucun message trouvé pour mettre à jour.", flags: 64 });
                    }
            
                    // Met à jour le message existant en ajoutant les composants (boutons ou sélecteur)
                    await message.edit({ components: rows });
                    await i.reply({ content: "Les composants de tickets ont été ajoutés avec succès au message existant.", ephemeral: true });
                } catch (error) {
                    console.error(error);
                    await i.reply({ content: "Une erreur est survenue lors de la mise à jour du message.", ephemeral: true });
                }
            }
                       

            if (i.customId.startsWith('suppoption_')) {
                const optionId = i.customId.split('_')[1];
                const index = dbone.option.findIndex(option => option.value === optionId);
                if (index !== -1) {
                    dbone.option.splice(index, 1);
                    await client.db.set(`ticket_${i.guild.id}`, dbone);
                    i.deferUpdate()
                    return updatefirst();
                }
            }

            if (i.values[0] === 'type') {
                const currentType = dbone.type;
                const newType = currentType === 'button' ? 'select' : 'button';
                dbone.type = newType;
                await client.db.set(`ticket_${i.guild.id}`, dbone);
                await i.deferUpdate();
                await updatefirst();
            }

            if (i.values[0] === 'claim') {
                dbone.claimbutton = !dbone.claimbutton;
                await client.db.set(`ticket_${i.guild.id}`, dbone);
                await i.deferUpdate();
                await updatefirst();
            }

            if (i.values[0] === 'fermetureleave') {
                dbone.leaveclose = !dbone.leaveclose;
                await client.db.set(`ticket_${i.guild.id}`, dbone);
                await i.deferUpdate();
                await updatefirst();
            }

            if (i.values[0] === 'transcript') {
                dbone.transcript = !dbone.transcript;
                await client.db.set(`ticket_${i.guild.id}`, dbone);
                await i.deferUpdate();
                await updatefirst();
            }

            if (i.values[0] === 'maxticket') {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply("Veuillez indiquer le nouveau nombre maximum de tickets par personne.");

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                    const newMaxTickets = parseInt(collected.first().content.trim());

                    if (!isNaN(newMaxTickets) && newMaxTickets > 0) {
                        dbone.maxticket = newMaxTickets;
                        await client.db.set(`ticket_${i.guild.id}`, dbone);
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updatefirst();
                    } else {
                        message.channel.send("Veuillez entrer un nombre entier positif.");
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updatefirst();
                    }
                } catch (error) {
                    console.error(error);
                    sentMessage.delete();
                    await updatefirst();
                    message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite : " + error.message);
                }
            }

            if (i.values[0] === 'salon') {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply("Quel est le **salon **du menu de ticket ?");
                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                    const msgcollect = collected.first().content.trim();
                    const channelID = msgcollect.replace(/[<#>]/g, '') || msgcollect;
                    const channel = message.guild.channels.cache.get(channelID);
                    if (!channel) {
                        message.channel.send('Aucun channel trouvé.');
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updatefirst();
                    } else {
                        dbone.salon = channel.id
                        await client.db.set(`ticket_${i.guild.id}`, dbone);
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updatefirst();
                    }
                } catch (error) {
                    console.error(error);
                    sentMessage.delete();
                    await updatefirst();
                    message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.")
                }
            }

            if (i.values[0] === 'messageidoption') {
                // Récupère les données du salon depuis la base de données
                const dbone = await client.db.get(`ticket_${i.guild.id}`) || {};
            
                // Vérifie si le salon est configuré
                if (!dbone.salon) {
                    await i.reply({ content: 'Le salon de tickets n\'est pas configuré. Veuillez d\'abord configurer le salon avant de configurer l\'ID du message.', ephemeral: true });
                    return;
                }
            
                const filter = response => response.author.id === i.user.id;
                const sentMessage = await i.reply({ content: "Quel est l'identifiant du **message** pour le système de ticket ?", ephemeral: true });
            
                try {
                    const collected = await i.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                    const msgcollect = collected.first().content.trim();
                    const messageID = msgcollect;
            
                    // Trouve le salon en utilisant l'ID
                    const channel = i.guild.channels.cache.get(dbone.salon);
                    if (!channel) {
                        await i.followUp({ content: 'Le salon de tickets configuré n\'existe pas.', ephemeral: true });
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updatefirst();
                        return;
                    }
            
                    try {
                        // Vérifie si le message existe dans le salon
                        const messageToUse = await channel.messages.fetch(messageID);
                        // Mettez à jour la base de données avec l'identifiant du message
                        dbone.messageidoption = messageID;
                        await client.db.set(`ticket_${i.guild.id}`, dbone);
            
                        await i.followUp({ content: `L'identifiant du message a été mis à jour avec succès : ${messageID}`, ephemeral: true });
                    } catch (fetchError) {
                        await i.followUp({ content: 'Aucun message trouvé avec cet ID.', ephemeral: true });
                    } finally {
                        await sentMessage.delete();
                        await collected.first().delete();
                        await updatefirst();
                    }
                } catch (error) {
                    console.error(error);
                    await sentMessage.delete();
                    await updatefirst();
                    await i.followUp({ content: "Le temps de réponse a expiré ou une erreur s'est produite.", ephemeral: true });
                }
            }
            


            const db = await client?.db.get(`ticket_${i.guild.id}`) || {
                option: [],
                salon: null,
                messageidoption: null,
                type: "select",
                Suppauto: true,
                maxticket: 1,
                leaveclose: false,
                claimbutton: true,
                buttonclose: true,
                transcript: false,
                rolerequis: [],
                roleinterdit: [],
            }


            if (i.values[0] === 'addoption') {
                if (db.option.length >= 10) {
                    return msg.edit({ content: 'Vous ne pouvez configurer que 10 options pour les tickets', embeds: [], components: [] });
                } else {
                    db.option.push({
                        categorie: null,
                        emoji: null,
                        text: 'Ouvrir un ticket',
                        value: code(10),
                        description: "Aucune description",
                        message: "Merci d'avoir contacté le support\nDécrivez votre problème puis attendez de recevoir une réponse",
                        logs: null,
                        mention: null,
                        acess: null
                    })
                    await client.db.set(`ticket_${i.guild.id}`, db)
                    updatefirst()
                }
            }


            if (i.values[0].startsWith('categorieoption_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);

                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez indiquer une catégorie.");

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const msgcollect = collected.first().content.trim();
                        const channels = await message.guild.channels.cache.get(msgcollect);
                        if (channels.type !== 4) {
                            message.channel.send('La catégorie indiquée est invalide.');
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        } else {
                            valideoption.categorie = msgcollect;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.")
                    }
                }
            }

            if (i.values[0].startsWith('textoption_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);

                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez indiquer la text de l'option.");

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const msgcollect = collected.first().content.trim();
                        const text = msgcollect

                        if (!text) {
                            message.channel.send('Le text de l\'option indiquée est invalide.');
                        } else {
                            valideoption.text = msgcollect;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.")
                    }
                }
            }

            if (i.values[0].startsWith('roleoption_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);

                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez mentionner le rôle.");

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const mentionedRoles = collected.first().mentions.roles;

                        if (mentionedRoles.size === 0) {
                            message.channel.send('Aucun rôle mentionné ou le rôle mentionné est invalide.');
                        } else {
                            const roleId = mentionedRoles.first().id;
                            valideoption.mention = roleId;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await optionupdate(id);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.");
                    }
                }
            }

            if (i.values[0].startsWith('salonoption_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);
            
                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez mentionner le salon des logs.");
            
                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const msgcollect = collected.first().content.trim();
            
                        // Utilisez une expression régulière pour extraire les mentions de salon
                        const channelMentionRegex = /<#(\d+)>/;
                        const match = msgcollect.match(channelMentionRegex);
            
                        if (!match) {
                            message.channel.send('Aucune mention de salon valide trouvée.');
                            await sentMessage.delete();
                            await collected.first().delete();
                            return;
                        }
            
                        const channelId = match[1];
                        const channel = client.channels.cache.get(channelId);
            
                        if (!channel) {
                            message.channel.send('Le salon mentionné est invalide.');
                        } else {
                            valideoption.logs = channelId;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.");
                    }
                }
            }
            
            
            if (i.values[0].startsWith('emojioption_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);

                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez indiquer un emoji.");

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const emoji = collected.first().content.trim();
                        const customEmoji = emojiget(emoji) || emoji;

                        if (!valide(customEmoji)) {
                            message.channel.send('L\'émoji indiqué est invalide.');
                        } else {
                            valideoption.emoji = emoji;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await optionupdate(id);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.")

                    }
                }
            }

            if (i.values[0].startsWith('ouvertoption_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);

                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez indiquer le texte d'ouverture du ticket.");

                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const text = collected.first().content.trim();

                        if (text.length === 0) {
                            message.channel.send('Le texte d\'ouverture indiqué est invalide.');
                        } else {
                            valideoption.message = text;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await optionupdate(id);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.");
                    }
                }
            }
            if (i.values[0].startsWith('descriptionoption_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);

                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez indiquer la description du select menu.");
                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const text = collected.first().content.trim();

                        if (text.length === 0) {
                            message.channel.send('La description indiqué est invalide.');
                        }  else if (text.length > 100) {
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                            await i.channel.send('La description doit contenir moins de 100 caractères.');
    
                        } else {
                            valideoption.description = text;
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await optionupdate(id);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.");
                    }
                }
            }

            if (i.values[0].startsWith('roleacess_')) {
                const id = i.values[0].split('_')[1];
                const valideoption = db.option.find(option => option.value === id);
            
                if (valideoption) {
                    const filter = response => response.author.id === message.author.id;
                    const sentMessage = await i.reply("Veuillez mentionner les rôles (vous pouvez en mentionner plusieurs).");
            
                    try {
                        const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                        const mentionedRoles = collected.first().mentions.roles;
            
                        if (mentionedRoles.size === 0) {
                            message.channel.send('Aucun rôle mentionné ou les rôles mentionnés sont invalides.');
                        } else {
                            // Créer une liste des ID des rôles mentionnés
                            const roleIds = mentionedRoles.map(role => role.id);
            
                            // Assurez-vous que vous utilisez correctement la base de données pour enregistrer les rôles
                            valideoption.acess = roleIds;
            
                            await client.db.set(`ticket_${i.guild.id}`, db);
                            await sentMessage.delete();
                            await collected.first().delete();
                            await optionupdate(id);
                        }
                    } catch (error) {
                        console.error(error);
                        await optionupdate(id);
                        sentMessage.delete();
                        message.channel.send("Le temps de réponse a expiré ou une erreur s'est produite.");
                    }
                }
            }
            
            
            if (i.customId === 'selectoption') {
                i.deferUpdate();
                optionupdate(i.values[0]);
            }
            
            async function optionupdate(module) {
                const db = await client?.db.get(`ticket_${message.guild.id}`) || {};
                const selectedOption = db.option.find(option => option.value === module);
            
                if (selectedOption) {
                    const categorie = client.channels.cache.get(selectedOption.categorie);
                    const channlog = client.channels.cache.get(selectedOption.logs);
            
                    const role = message.guild.roles.cache.get(selectedOption.mention);

            
                    const rolesAcces = Array.isArray(selectedOption.acess)
                        ? selectedOption.acess.map(roleId => `<@&${roleId}>`).join(', ')
                        : 'Aucun';
            
                        const optionFields = [
                            { name: 'Catégorie', value: categorie ? `#${categorie.name}` : 'Aucune', inline: true },
                            { name: 'Emoji', value: selectedOption.emoji || 'None', inline: true },
                            { name: 'Texte', value: selectedOption.text || 'Aucun texte', inline: true },
                            { name: 'Description (Sélecteur seulement)', value: selectedOption.description || 'Aucune description', inline: true },
                            { name: 'Salon de logs', value: channlog ? `#${channlog.name}` : 'Aucun', inline: true },
                            { name: 'Rôles mentionnés', value: role?.name || 'Aucun', inline: true },
                            { name: 'Message d\'ouverture de ticket', value: selectedOption.message || 'Aucun message', inline: true },
                            { name: 'Rôles ayant accès', value: rolesAcces || 'Aucun', inline: true }
                        ];
                        

            
                    const button = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId('retourmenu')
                                .setStyle(2)
                                .setEmoji("↩")
                                .setLabel('Retour'),
                            new Discord.ButtonBuilder()
                                .setCustomId('suppoption_' + selectedOption.value)
                                .setStyle(4)
                                .setLabel('❌ Supprimer l\'option')
                        );
            
                    const selectMenu = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.StringSelectMenuBuilder()
                                .setCustomId('configmenu')
                                .setPlaceholder('Sélectionnez un champ à configurer...')
                                .addOptions([
                                    {
                                        label: 'Catégorie',
                                        emoji: '📮',
                                        value: 'categorieoption_' + selectedOption.value
                                    },
                                    {
                                        label: 'Emoji',
                                        emoji: '🌐',
                                        value: 'emojioption_' + selectedOption.value
                                    },
                                    {
                                        label: 'Texte de button/selecteur',
                                        emoji: '✏',
                                        value: 'textoption_' + selectedOption.value
                                    },
                                    {
                                        label: 'Description (Sélecteur seulement)',
                                        emoji: "🗨",
                                        value: 'descriptionoption_' + selectedOption.value
                                    },
                                    {
                                        label: 'Salon des logs/transcript',
                                        emoji: "📜",
                                        value: 'salonoption_' + selectedOption.value
                                    },
                                    {
                                        label: 'Rôle mentionné',
                                        emoji: '🔔',
                                        value: 'roleoption_' + selectedOption.value
                                    },
                                    {
                                        label: 'Message d\'ouverture de ticket',
                                        emoji: '📋',
                                        value: 'ouvertoption_' + selectedOption.value
                                    },
                                    {
                                        label: 'Rôles ayant accès',
                                        emoji: '🔑',
                                        value: 'roleacess_' + selectedOption.value
                                    }
                                ])
                        );
            
                    const optionEmbed = new Discord.EmbedBuilder()
                        .setTitle(`Paramètres de l'option`)
                        .setColor(client.color)
                        .addFields(optionFields);
            
                    msg.edit({ embeds: [optionEmbed], components: [selectMenu, button] });
                }
            }
            
            
            function emojiget(emoji) {
                const regex = /<a?:\w+:(\d+)>/;
                const match = emoji.match(regex);
                return match ? match[1] : null;
            }
            
            function valide(emoji) {
                return client.emojis.cache.has(emoji);
            }


            function code(length) {
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                let code = '';
                for (let i = 0; i < length; i++) {
                    const randomIndex = Math.floor(Math.random() * characters.length);
                    code += characters.charAt(randomIndex);
                }
                return code;
            }
        }
    )}
}
            