const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');

module.exports = {
    name: "close",
    description: "Ferme le ticket actuel",
    category: "ticket",
    usage: "close",
    /**
     * @param {Valory} client
     * @param {Discord.Message} message
     * @param {Array} args
     */
    run: async (client, message, args) => {
        let pass = false;
        const staff = client.staff;
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permLevel = client.db.get(`perm_close.${message.guild.id}`);
            if (permLevel) {
                const permRoles = client.db.get(`perm${permLevel}.${message.guild.id}`);
                if (permRoles && message.member.roles.cache.some(r => permRoles.includes(r.id))) {
                    pass = true;
                }
            }
            if (client.db.get(`perm_close.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(client.noperm || 'Vous n\'avez pas la permission de fermer les tickets.');
        }

        const ticketId = message.channel.id;
        const tickets = await client.db.get(`ticket_user_${message.guild.id}`);
        const ticket = tickets.find(t => t.salon === ticketId);

        if (!ticket) {
            return message.channel.send('Aucun ticket trouvé avec cet ID.');
        }

        const dbserveur = await client.db.get(`ticket_${message.guild.id}`);
        const dboption = dbserveur?.option?.find(option => option.value === ticket.option);

        if (!dboption || !dboption.logs) {
            return message.channel.send("Le canal de logs pour ce ticket n'est pas configuré.");
        }

        const channel = message.guild.channels.cache.get(dboption.logs);

        if (!channel) {
            return message.channel.send("Le canal de logs spécifié n'existe pas ou n'est pas accessible.");
        }

        const channelticket = message.channel;
        const transcript = await discordTranscripts.createTranscript(channelticket);

        if (channel) {
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setFooter(client.footer)
                .setAuthor({ name: `${message.author.username} (${message.author.id})`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp()
                .setTitle('Ticket fermé par ' + message.author.username);

            channel.send({
                files: [transcript],
                embeds: [embed]
            }).catch(console.error);
        }

        const user = await client.users.fetch(ticket.author);
        if (user) {
            user.send({
                content: `Votre ticket sur le serveur ${message.guild.name} a été fermé. Voici un transcript du ticket :`,
                files: [transcript]
            }).catch(console.error);
        }

        const updatedTickets = tickets.filter(t => t.id !== ticket.id);
        await client.db.set(`ticket_user_${message.guild.id}`, updatedTickets);

        channelticket.delete().catch(console.error);
    }
}
