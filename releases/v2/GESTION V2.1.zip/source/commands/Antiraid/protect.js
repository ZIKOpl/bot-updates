const Discord = require('discord.js');
const { bot } = require('../../structures/client');
const fs = require('fs');
const Astroia = require('../../structures/client');

module.exports = {
    name: "protect",
    aliases: ["secur", "security", "sec", "protections", "protection"],
    description: "Affiche/Configure la sécurité",
    usage: "protect",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     */
    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;

        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permLevel = client.db.get(`perm_${commandName}.${message.guild.id}`);
            const rolePermissions = client.db.get(`perm${permLevel}.${message.guild.id}`) || [];
            if (rolePermissions.some(roleId => message.member.roles.cache.has(roleId))) {
                pass = true;
            }
            if (permLevel === "public") pass = true;
        } else pass = true;

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Fetching data from the database
        const antispamData = client.db.get(`antispam_${message.guild.id}`) || { message: 4, temps: 5000, status: 'off' };
        const antilinkData = client.db.get(`antilink_${message.guild.id}`) || { sanction: ['delete', 'mute', 'message'], ignore: [], lien: 'all', status: 'off' };
        const antibot = client.db.get(`antibot_${message.guild.id}`) || { status: 'off' };
        const antichannelData = client.db.get(`antichannel_${message.guild.id}`) || { status: 'off', sanction: 'aucune' };
        const antirole = client.db.get(`antirole_${message.guild.id}`) || { status: 'off', sanction: 'aucune' };
        const antiwebhookData = client.db.get(`antiwebhook_${message.guild.id}`) || { status: 'off', sanction: 'aucune' };
        const antiban = client.db.get(`antiban_${message.guild.id}`) || { status: 'off', sanction: 'aucune' };
        const antikick = client.db.get(`antikick_${message.guild.id}`) || { status: 'off', sanction: 'aucune' };
        const antialt = client.db.get(`antialt_${message.guild.id}`) || { status: 'off', duree: 'aucune' };

        // Extracting status and values for the embed
        const statuses = {
            antispam: getStatus(antispamData.status, `${antispamData.message}/${formatInterval(antispamData.temps)}`),
            antilink: getStatus(antilinkData.status, antilinkData.lien),
            antibot: getStatus(antibot.status),
            antichannel: getStatus(antichannelData.status, `Sanction: ${antichannelData.sanction || 'aucune'}`),
            antirole: getStatus(antirole.status, `Sanction: ${antirole.sanction || 'aucune'}`),
            antiwebhook: getStatus(antiwebhookData.status, `Sanction: ${antiwebhookData.sanction || 'aucune'}`),
            antiban: getStatus(antiban.status, `Sanction: ${antiban.sanction || 'aucune'}`),
            antikick: getStatus(antikick.status, `Sanction: ${antikick.sanction || 'aucune'}`),
            antialt: getStatus(antialt.status, `Durée: ${antialt.duree || 'aucune'}`)
        };

        const [setting] = args;

        if (setting) {
            const newSetting = setting.toLowerCase();
            if (['on', 'off', 'max'].includes(newSetting)) {
                antispamData.status = newSetting;
                antilinkData.status = newSetting;
                antibot.status = newSetting;
                antichannelData.status = newSetting;
                antirole.status = newSetting;
                antiwebhookData.status = newSetting;
                antiban.status = newSetting;
                antikick.status = newSetting;
                antialt.status = newSetting;

                try {
                    await client.db.set(`antispam_${message.guild.id}`, antispamData);
                    await client.db.set(`antilink_${message.guild.id}`, antilinkData);
                    await client.db.set(`antibot_${message.guild.id}`, antibot);
                    await client.db.set(`antichannel_${message.guild.id}`, antichannelData);
                    await client.db.set(`antirole_${message.guild.id}`, antirole);
                    await client.db.set(`antiwebhook_${message.guild.id}`, antiwebhookData);
                    await client.db.set(`antiban_${message.guild.id}`, antiban);
                    await client.db.set(`antikick_${message.guild.id}`, antikick);
                    await client.db.set(`antialt_${message.guild.id}`, antialt);
                    return message.reply(`Toutes les protections sont maintenant sur \`${newSetting}\`.`);
                } catch (error) {
                    console.error(error);
                    return message.reply("Une erreur s'est produite lors de la mise à jour des paramètres.");
                }
            } else {
                return sendEmbed(message, client, statuses);
            }
        } else {
            return sendEmbed(message, client, statuses);
        }
    }
};

function getStatus(status, detail = '') {
    // Modify this function to return "activer" or "non"
    const statusText = status === 'on' ? 'activer' : 'non';
    return `${statusText}${detail ? ` (${detail})` : ''}`;
}

function formatInterval(milliseconds) {
    if (isNaN(milliseconds) || milliseconds <= 0) return "Invalid";

    const intervals = [
        { unit: 'w', divisor: 604800000 },
        { unit: 'd', divisor: 86400000 },
        { unit: 'h', divisor: 3600000 },
        { unit: 'm', divisor: 60000 },
        { unit: 's', divisor: 1000 }
    ];

    for (const interval of intervals) {
        const value = Math.floor(milliseconds / interval.divisor);
        if (value >= 1) {
            return `${value}${interval.unit}`;
        }
    }

    return "0s";
}

function sendEmbed(message, client, statuses) {
    const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setTitle(`Configuration de la Protection`)
        .setDescription(`
**AntiSpam :** \`${statuses.antispam}\`
**AntiLink :** \`${statuses.antilink}\`
**AntiBot  :** \`${statuses.antibot}\`
**AntiChannel  :** \`${statuses.antichannel}\`
**AntiRole  :** \`${statuses.antirole}\`
**AntiWebhook :** \`${statuses.antiwebhook}\`
**AntiBan  :** \`${statuses.antiban}\`
**AntiKick :** \`${statuses.antikick}\`
**AntiAlt :** \`${statuses.antialt}\`
        `)
        .setTimestamp();
    return message.channel.send({ embeds: [embed] });
}
