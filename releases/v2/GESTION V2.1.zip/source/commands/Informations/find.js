const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'find',
    description: 'Trouve le salon vocal où un utilisateur est et affiche le temps passé dans ce salon.',
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        if(!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permissionLevel = client.db.get(`perm_find.${message.guild.id}`);
            if (permissionLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (permissionLevel === "public") pass = true;   
        } else {
            pass = true;
        }
        
        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        const userId = args[0]?.replace(/[<@!>]/g, '');
        const user = message.guild.members.cache.get(userId);

        if (!user) {
            return message.reply("Utilisateur non trouvé. Veuillez mentionner un utilisateur ou fournir un ID valide.");
        }

        const voiceChannel = user.voice.channel;
        if (!voiceChannel) {
            return message.reply("L'utilisateur n'est pas dans un salon vocal.");
        }

        if (!client.voiceJoinTimes) {
            client.voiceJoinTimes = new Map();
        }

        const joinTime = client.voiceJoinTimes.get(userId) || Date.now();
        client.voiceJoinTimes.set(userId, joinTime);

        const currentTime = Date.now();
        const timeInChannel = currentTime - joinTime;

        const seconds = Math.floor((timeInChannel / 1000) % 60);
        const minutes = Math.floor((timeInChannel / (1000 * 60)) % 60);
        const hours = Math.floor((timeInChannel / (1000 * 60 * 60)) % 24);
        const days = Math.floor(timeInChannel / (1000 * 60 * 60 * 24));

        const timeFormatted = `${days} jours, ${hours} heures, ${minutes} minutes, ${seconds} secondes`;

        const embed = new EmbedBuilder()
            .setTitle(`Informations sur l'utilisateur ${user.user.tag}`)
            .setColor(client.color)
            .addFields(
                { name: 'Salon Vocal', value: `<#${voiceChannel.id}>` },
                { name: 'Temps passé', value: timeFormatted }
            );

        return message.reply({ embeds: [embed] });
    }
};
