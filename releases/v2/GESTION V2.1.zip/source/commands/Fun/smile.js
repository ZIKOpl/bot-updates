const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'smile',
    description: "Fais sourire un utilisateur.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        // Vérification si un utilisateur est mentionné
        const user = message.mentions.users.first();
        if (!user) {
            return message.reply("Tu dois mentionner un utilisateur à qui faire un sourire.");
        }

        // Créer un embed avec le titre et l'image
        const embed = new EmbedBuilder()
            .setDescription(`😄 ${message.author} fait un sourire à ${user}`) // Utilisation des "template literals"
            .setImage('https://images-ext-1.discordapp.net/external/Qj9mj2E1YDcVTespi0Vfig-RiaAc7N0uy88Q0IahBng/https/cdn.weeb.sh/images/rkH84ytPZ.gif?width=625&height=351')
            .setColor(client.color); // Couleur dorée

        // Envoyer l'embed
        const msg = await message.channel.send({ embeds: [embed] });

        // Créer un bouton grisé avec un emoji
        const button = new ButtonBuilder()
            .setCustomId('smile_button')
            .setLabel('😄')
            .setStyle(ButtonStyle.Secondary) // Style gris
            .setDisabled(true); // Désactiver le bouton

        // Créer un Action Row pour contenir le bouton
        const row = new ActionRowBuilder()
            .addComponents(button);

        // Ajouter le bouton à l'embed
        await msg.edit({ embeds: [embed], components: [row] });
    }
};
