const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'gay',
    description: "Affiche le pourcentage gay d'un utilisateur.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        const staff = client.staff;

        // Vérification des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permLevel = client.db.get(`perm_gay.${message.guild.id}`); // Check the permission level for the 'gay' command
            if (permLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
        } else {
            pass = true;
        }

        // Si l'utilisateur n'a pas les permissions nécessaires
        if (!pass) {
            return message.reply(client.noperm || 'Vous n\'avez pas la permission d\'exécuter cette commande.');
        }

        // Vérification si un utilisateur est mentionné
        const user = message.mentions.users.first();
        if (!user) {
            return message.reply("Tu dois mentionner un utilisateur.");
        }

        // Si l'utilisateur est celui avec l'ID spécifique, il n'est pas gay
        let gayPercent;
        if (user.id === '1257279089010675778') {
            gayPercent = 0;
        } else {
            // Générer un pourcentage aléatoire entre 0 et 100
            gayPercent = Math.floor(Math.random() * 101);
        }

        let gayPercent1;
        if (user.id === '745473383017480243') {
            gayPercent = 1000000;
        } else {
            // Générer un pourcentage aléatoire entre 0 et 100
            gayPercent = Math.floor(Math.random() * 101);
        }

        // Créer un embed avec le résultat
        const embed = new EmbedBuilder()
            .setTitle('🌈 Test de gayness')
            .setDescription(`💫 ${user} est gay à **${gayPercent}%** !`)
            .setColor(client.color) // Couleur aléatoire si le pourcentage est supérieur à 50, sinon bleu.
            .setThumbnail(); // Une image amusante de drapeau LGBTQ+.

        // Envoyer l'embed
        const msg = await message.channel.send({ embeds: [embed] });

        // Créer un bouton désactivé avec un emoji arc-en-ciel
        const button = new ButtonBuilder()
            .setCustomId('gay_button')
            .setLabel('🌈')
            .setStyle(ButtonStyle.Secondary) // Style gris
            .setDisabled(true); // Désactiver le bouton

        // Créer un Action Row pour contenir le bouton
        const row = new ActionRowBuilder()
            .addComponents(button);

        // Ajouter le bouton à l'embed
        await msg.edit({ embeds: [embed], components: [row] });
    }
};
