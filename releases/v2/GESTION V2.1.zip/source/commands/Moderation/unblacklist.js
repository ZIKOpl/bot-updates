const { EmbedBuilder } = require('discord.js');
const Astroia = require('../../structures/client/index.js');

module.exports = {
    name: 'unblacklist',
    usage: "unbl <mention/id> Retirer un utilisateur de la blacklist",
    aliases: ['unbl'],
    description: "Retirer un utilisateur de la blacklist",

    /**
     * 
     * @param {Astroia} client 
     * @param {*} message 
     * @param {*} args 
     * @returns 
     */
    run: async (client, message, args) => {
        // Vérification des permissions
        let pass = false;
        let staff = client.staff;

        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            
            const commandName = 'unblacklist'; // Nom de la commande

            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && 
                message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && 
                message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && 
                message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && 
                message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && 
                message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(await client.lang(`perm`));
        }

        // Récupération de la liste des utilisateurs blacklistés
        const blacklist = await client.db.get(`blacklist`) || [];
        let user = message.mentions.users.first();
        let memberId = args[0];

        if (!user && memberId) {
            try {
                user = await client.users.fetch(memberId);
            } catch (error) {
                console.error(error);
            }
        }

        if (!user && !memberId) {
            return message.reply(`Veuillez mentionner un utilisateur ou fournir un ID valide.`);
        }

        const entryIndex = blacklist.findIndex(entry => entry.userId === (memberId || user.id));

        if (entryIndex === -1) {
            return message.reply(`${user ? user.username : memberId} n'est pas dans la blacklist.`);
        }

        const member = user;

        const messages = await message.channel.send(`Début de l'unblacklist pour ${member.username}...`);
        let unbansSuccess = 0;
        let unbansFailed = 0;

        await Promise.all(client.guilds.cache.map(async (guild) => {
            try {
                await guild.members.unban(member.id, `UNBLACKLIST | by ${message.author.tag}`);
                unbansSuccess++;
                await new Promise(resolve => setTimeout(resolve, 800)); 
            } catch (error) {
                console.error(`Impossible de débannir ${member.username} de ${guild.name}`);
                unbansFailed++;
            }
        }));

        messages.edit(`${messages.content}\n${member.username} a été unblacklisté de \`${unbansSuccess}\` serveurs avec succès et a échoué sur \`${unbansFailed}\` serveurs.`);

        // Suppression de l'utilisateur de la blacklist
        blacklist.splice(entryIndex, 1);
        await client.db.set(`blacklist`, blacklist);
    }
};
