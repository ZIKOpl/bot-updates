const { EmbedBuilder } = require('discord.js');
const Astroia = require("../../structures/client");

module.exports = {
    name: "warnlist",
    description: "Affiche la liste des avertissements d'un membre du serveur.",
    usages: "warnlist <@user/ID> Affiche la liste des avertissements d'un membre du serveur",
    /**
     * @param {Astroia} client
     * @param {Astroia} message
     * @param {Astroia} args
     * @returns
     */
    run: async (client, message, args) => {
        try {
            // Check if the user provided is valid
            let user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);

            if (!user) {
                return message.channel.send("Utilisation incorrecte : warnlist <membre>");
            }

            // Fetch the user's warning data from the database
            const warnings = await client.db.get(`sanction_${message.guild.id}`) || [];
            const userWarnings = warnings.filter(warn => warn.userId === user.id);

            if (userWarnings.length === 0) {
                return message.channel.send(`> \`✅\` <@${user.id}> n'a aucun avertissement.`);
            }

            // Create an embed to display the warnings
            const warnEmbed = new EmbedBuilder()
                .setTitle(`Avertissements pour ${user.tag}`)
                .setColor(client.color)
                .setFooter(client.footer)
                .setTimestamp();

            // Add each warning to the embed
            userWarnings.forEach((warn, index) => {
                warnEmbed.addFields({ 
                    name: `Avertissement ${index + 1}`,
                    value: `**Code:** ${warn.code}\n**Raison:** ${warn.reason}\n**Date:** <t:${Math.floor(warn.date / 1000)}:F>`,
                    inline: false
                });
            });

            // Send the embed
            await message.channel.send({ embeds: [warnEmbed] });

        } catch (err) {
            console.error('Erreur:', err);
            message.reply("Une erreur vient de se produire...");
        }
    }
};

