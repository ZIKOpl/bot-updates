const { EmbedBuilder } = require('discord.js');
const Astroia = require("../../structures/client");

module.exports = {
    name: "sanction",
    description: "Affiche les sanctions d'un membre du serveur.",
    usages: "sanction <@user/ID>",
    /**
     * @param {Astroia} client
     * @param {Astroia} message
     * @param {Astroia} args
     * @returns
     */
    run: async (client, message, args) => {
        console.log("Command 'sanction' initiated.");

        try {
            // Vérification des permissions
            let pass = false;
            let staff = client.staff;

            if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
                console.log("Checking permissions.");
                if (client.db.get(`perm_sanction.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_sanction.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_sanction.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_sanction.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_sanction.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_sanction.${message.guild.id}`) === "public") pass = true;
            } else {
                pass = true;
            }

            if (!pass) {
                if (client.noperm && client.noperm.trim() !== '') {
                    return message.channel.send(client.noperm);
                } else {
                    return;
                }
            }

            // Vérification des arguments
            if (args.length < 1) {
                return message.channel.send("Utilisation incorrecte : `sanction <@user/ID>`");
            }

            // Récupérer l'utilisateur
            let user = message.mentions.users.first();
            let memberId = args[0];

            if (!user && memberId) {
                user = await client.users.fetch(memberId).catch(() => null);
            }

            if (!user) {
                return message.channel.send("Utilisateur non trouvé. Utilisation correcte : `sanction <@user/ID>`");
            }

            // Récupérer les sanctions
            const db = await client.db.get(`sanction_${message.guild.id}`) || [];
            const sanctions = db.filter(s => s.userId === user.id);

            if (sanctions.length === 0) {
                return message.channel.send(`Aucune sanction trouvée pour <@${user.id}>.`);
            }

            // Créer un embed pour afficher les sanctions
            const sanctionEmbed = new EmbedBuilder()
                .setTitle(`Sanctions pour ${user.tag}`)
                .setColor(client.color)
                .setFooter(client.footer)
                .setTimestamp();

            sanctions.forEach((sanction, index) => {
                sanctionEmbed.addFields({
                    name: `Sanction ${index + 1}`,
                    value: `**Code :** ${sanction.code}\n**Raison :** ${sanction.reason}\n**Date :** <t:${Math.floor(sanction.date / 1000)}:F>`,
                });
            });

            await message.channel.send({ embeds: [sanctionEmbed] });

        } catch (err) {
            console.error('Erreur:', err);
            message.reply("Une erreur est survenue...");
        }
    }
};
