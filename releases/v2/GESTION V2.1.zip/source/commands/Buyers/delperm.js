const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "delperm",
    description: "Retirer un rôle d'une permission spécifique",
    usage: "delperm <perm1/2/3/4/5> <@role>",
    run: async(client, message, args, commandName) => {

        if (!client.config.buyers.includes(message.author.id)) {
            return message.channel.send(await client.lang(`delperm.perm`));
        }

        // Définir les permissions valides
        let valid_perms = ["perm1", "perm2", "perm3", "perm4", "perm5"];
        let perm_to_edit = args[0];
        let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);

        if (!valid_perms.includes(perm_to_edit)) {
            return message.channel.send(await client.lang(`delperm.invalide-perm`));
        }

        if (!role) {
            return message.channel.send(await client.lang(`delperm.invalide-role`));
        }

        // Récupérer la liste des rôles pour la permission donnée
        let current_perms = client.db.get(`${perm_to_edit}.${message.guild.id}`);
        if (!Array.isArray(current_perms)) current_perms = [];

        if (!current_perms.includes(role.id)) {
            return message.channel.send(await client.lang(`delperm.role`) + ` \`\`${role.name}\`\` ` + await client.lang(`delperm.perm-role-erreur`));
        }

        // Retirer le rôle de la permission
        client.db.set(`${perm_to_edit}.${message.guild.id}`, current_perms.filter(r => r !== role.id));
        return message.channel.send(await client.lang(`delperm.role`) + ` \`\`${role.name}\`\` ` + await client.lang(`delperm.perm-remove`));
    }
};
