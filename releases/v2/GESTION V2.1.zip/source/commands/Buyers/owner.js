const Discord = require('discord.js');
const { Astroia } = require('../../structures/client');

module.exports = {
    name: "owner",
    description: "Permet de gérer les owners",
    usages: "owner",
    /**
     * 
     * @param {Astroia} client 
     * @param {Astroia} message 
     * @returns 
     */
    run: async (client, message) => {
        if (!client.config.buyers.includes(message.author.id)) {
            return message.channel.send("Vous n'avez pas la permission d'utiliser cette commande.");
        }

        const addButton = new Discord.ButtonBuilder()
            .setCustomId('owner_add')
            .setLabel('Ajouter')
            .setStyle(Discord.ButtonStyle.Primary);

        const removeButton = new Discord.ButtonBuilder()
            .setCustomId('owner_remove')
            .setLabel('Supprimer')
            .setStyle(Discord.ButtonStyle.Danger);

        const clearButton = new Discord.ButtonBuilder()
            .setCustomId('owner_clear')
            .setLabel('Effacer')
            .setStyle(Discord.ButtonStyle.Secondary);

        const row = new Discord.ActionRowBuilder()
            .addComponents(addButton, removeButton, clearButton);

        const updateEmbed = async () => {
            let data = await client.db.all();
            let ownerList = data.filter(data => data.ID.startsWith(`owner_`)).length > 0 
                ? data.filter(data => data.ID.startsWith(`owner_`)).map(entry => `<@${entry.ID.split('_')[1]}>`).join("\n") 
                : "Aucun";

            let embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setTitle("Liste des owners")
                .setDescription(ownerList)
                .setFooter(client.footer);

            return embed;
        };

        let embed = await updateEmbed();
        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        const filter = (interaction) => interaction.isButton() && interaction.user.id === message.author.id;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'owner_add') {
                // On demande à l'utilisateur de mentionner un membre
                const memberMentionPrompt = await interaction.reply({ 
                    content: "Veuillez mentionner un utilisateur à ajouter comme owner.",
                    ephemeral: true 
                });

                const userFilter = (msg) => msg.author.id === interaction.user.id && msg.channel.id === interaction.channel.id;
                const userCollector = message.channel.createMessageCollector({ filter: userFilter, time: 60000 });

                userCollector.on('collect', async (msg) => {
                    const member = msg.mentions.members.first() || msg.guild.members.cache.get(msg.content);

                    if (!member) {
                        return msg.reply("Utilisateur non valide. Veuillez réessayer.");
                    }

                    if (client.db.get(`owner_${member.id}`)) {
                        return msg.reply(`${member.user.username} est déjà un owner.`);
                    }

                    // On ajoute le membre à la liste des owners
                    client.db.set(`owner_${member.id}`, true);
                    msg.reply(`${member.user.username} a été ajouté à la liste des owners.`);

                    // Met à jour l'embed après l'ajout
                    embed = await updateEmbed();
                    await sentMessage.edit({ embeds: [embed] });

                    // Désactiver les boutons après l'ajout
                    row.components.forEach(button => button.setDisabled(true));
                    await sentMessage.edit({ components: [row] });

                    userCollector.stop();
                });

                userCollector.on('end', () => {
                    // Supprime le message de prompt après la collecte
                    memberMentionPrompt.delete();
                });

            } else if (interaction.customId === 'owner_remove') {
                // Demander à l'utilisateur de mentionner un membre à retirer
                const memberRemovePrompt = await interaction.reply({ 
                    content: "Veuillez mentionner un utilisateur à supprimer de la liste des owners.",
                    ephemeral: true 
                });

                const userFilter = (msg) => msg.author.id === interaction.user.id && msg.channel.id === interaction.channel.id;
                const userCollector = message.channel.createMessageCollector({ filter: userFilter, time: 60000 });

                userCollector.on('collect', async (msg) => {
                    const member = msg.mentions.members.first() || msg.guild.members.cache.get(msg.content);

                    if (!member) {
                        return msg.reply("Utilisateur non valide. Veuillez réessayer.");
                    }

                    if (!client.db.get(`owner_${member.id}`)) {
                        return msg.reply(`${member.user.username} n'est pas dans la liste des owners.`);
                    }

                    // On retire le membre de la liste des owners
                    client.db.delete(`owner_${member.id}`);
                    msg.reply(`${member.user.username} a été retiré de la liste des owners.`);

                    // Met à jour l'embed après la suppression
                    embed = await updateEmbed();
                    await sentMessage.edit({ embeds: [embed] });

                    // Désactiver les boutons après la suppression
                    row.components.forEach(button => button.setDisabled(true));
                    await sentMessage.edit({ components: [row] });

                    userCollector.stop();
                });

                userCollector.on('end', () => {
                    // Supprime le message de prompt après la collecte
                    memberRemovePrompt.delete();
                });

            } else if (interaction.customId === 'owner_clear') {
                const ownerData = await client.db.all().filter(data => data.ID.startsWith(`owner_`));
                ownerData.forEach(entry => client.db.delete(entry.ID));

                interaction.reply({ content: `${ownerData.length} ${ownerData.length > 1 ? 'personnes ont été retirées' : 'personne a été retirée'} de la liste des owners.`, ephemeral: true });

                // Met à jour l'embed après le clear
                embed = await updateEmbed();
                await sentMessage.edit({ embeds: [embed] });

                // Désactiver les boutons après le clear
                row.components.forEach(button => button.setDisabled(true));
                await sentMessage.edit({ components: [row] });
            }
        });

        collector.on('end', () => {
            row.components.forEach(button => button.setDisabled(true));
            sentMessage.edit({ components: [row] });
        });
    }
};
