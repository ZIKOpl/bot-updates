const { ChannelType, CategoryChannel, VoiceChannel } = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "tempvoc",
    description: "Crée un salon vocal temporaire pour chaque utilisateur qui rejoint le salon spécifié.",
    usages: "tempvoc <id_categorie> <id_salon>",

    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;

        // Système de permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Vérification des arguments
        if (args.length < 2) {
            return message.channel.send("Utilisation incorrecte : tempvoc <id_categorie> <id_salon>");
        }

        const categoryId = args[0];
        const targetChannelId = args[1];

        const category = message.guild.channels.cache.get(categoryId);
        if (!(category && category instanceof CategoryChannel)) {
            return message.channel.send("Catégorie introuvable ou invalide.");
        }

        const targetChannel = message.guild.channels.cache.get(targetChannelId);
        if (!(targetChannel && targetChannel instanceof VoiceChannel)) {
            return message.channel.send("Salon vocal introuvable ou invalide.");
        }

        // Enregistrez les IDs dans la base de données
        client.db.set(`tempvoc_${message.guild.id}_categoryId`, categoryId);
        client.db.set(`tempvoc_${message.guild.id}_targetChannelId`, targetChannelId);

        // Événement lorsqu'un utilisateur rejoint le salon cible
        client.on('voiceStateUpdate', async (oldState, newState) => {
            // Vérifiez les données enregistrées dans la base de données
            const storedTargetChannelId = client.db.get(`tempvoc_${newState.guild.id}_targetChannelId`);
            const storedCategoryId = client.db.get(`tempvoc_${newState.guild.id}_categoryId`);

            if (!storedTargetChannelId || !storedCategoryId) return;

            const storedTargetChannel = newState.guild.channels.cache.get(storedTargetChannelId);
            const storedCategory = newState.guild.channels.cache.get(storedCategoryId);

            if (!(storedTargetChannel && storedTargetChannel instanceof VoiceChannel)) return;
            if (!(storedCategory && storedCategory instanceof CategoryChannel)) return;

            if (newState.channelId === storedTargetChannel.id && !oldState.channel) {
                const member = newState.member;

                // Créer un salon vocal temporaire pour le membre
                const privateChannel = await newState.guild.channels.create({
                    name: `🔊・${member.user.username}`,
                    type: ChannelType.GuildVoice,
                    parent: storedCategory,
                    permissionOverwrites: [
                        {
                            id: newState.guild.id,
                            deny: ['ViewChannel'],
                        },
                        {
                            id: member.id,
                            allow: ['ViewChannel', 'Connect', 'Speak'],
                        },
                    ],
                }).catch(err => {
                    console.error(err);
                    newState.guild.channels.cache.get(message.channel.id).send("Une erreur est survenue lors de la création du salon vocal temporaire.");
                });

                if (!privateChannel) return;

                // Déplacer le membre dans le salon vocal privé
                await member.voice.setChannel(privateChannel);

                // Supprimer le salon vocal privé lorsque le membre le quitte
                const handleChannelDeletion = (oldState, newState) => {
                    if (newState.channel && newState.channel.id === privateChannel.id && !newState.channel.members.size) {
                        privateChannel.delete().catch(err => console.error(err));
                        client.off('voiceStateUpdate', handleChannelDeletion);
                    }
                };

                client.on('voiceStateUpdate', handleChannelDeletion);
            }
        });

        await message.channel.send(`La commande tempvoc a été configurée pour le salon : ${targetChannel}.`);
    }
};
