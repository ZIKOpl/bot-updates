const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "vocmanager",
    description: "Gérer votre salon vocal temporaire avec différents boutons.",
    usage: "vocmanager",
    
    /**
     * @param {Astroia} client
     * @param {Discord.Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Système de permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_vocmanager.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_vocmanager.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_vocmanager.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_vocmanager.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_vocmanager.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_vocmanager.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Vérification si l'utilisateur est dans un salon vocal
        const member = message.member;
        const voiceChannel = member.voice.channel;

        if (!voiceChannel || !client.db.get(`tempvoc_${message.guild.id}_categoryId`)) {
            return message.channel.send("Vous devez être dans un salon vocal temporaire pour utiliser cette commande.");
        }

        // Vérifier si le bot a les permissions de gérer le salon vocal
        if (!voiceChannel.guild || !voiceChannel.guild.members.me || !voiceChannel.guild.members.me.permissionsIn(voiceChannel).has(PermissionsBitField.Flags.ManageChannels)) {
            return message.channel.send("Je n'ai pas les permissions nécessaires pour gérer ce salon.");
        }

        // Créer les boutons
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('lock')
                    .setLabel('🔒 Lock')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('unlock')
                    .setLabel('🔓 Unlock')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('hide')
                    .setLabel('👁️ Hide')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('unhide')
                    .setLabel('👁️ Unhide')
                    .setStyle(ButtonStyle.Secondary),
            );
        
        const row2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('mute')
                    .setLabel('🔇 Mute')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('unmute')
                    .setLabel('🔊 Unmute')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('limit')
                    .setLabel('👤 Limit')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('disconnect')
                    .setLabel('🚪 Disconnect')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('delete')
                    .setLabel('❌ Delete')
                    .setStyle(ButtonStyle.Danger),
            );

        // Envoyer les boutons
        await message.channel.send({
            content: 'Utilisez ces boutons pour gérer votre salon vocal :',
            components: [row, row2]
        });

        // Gestion des interactions avec les boutons
        const filter = i => i.user.id === message.author.id;

        const collector = message.channel.createMessageComponentCollector({
            filter,
            time: 60000 // 60 secondes
        });

        collector.on('collect', async interaction => {
            if (!voiceChannel) return;

            switch (interaction.customId) {
                case 'lock':
                    await voiceChannel.permissionOverwrites.edit(message.guild.id, {
                        Connect: false
                    });
                    await interaction.reply({ content: 'Le salon vocal a été fermé (🔒).', ephemeral: true });
                    break;

                case 'unlock':
                    await voiceChannel.permissionOverwrites.edit(message.guild.id, {
                        Connect: true
                    });
                    await interaction.reply({ content: 'Le salon vocal a été ouvert (🔓).', ephemeral: true });
                    break;

                case 'hide':
                    await voiceChannel.permissionOverwrites.edit(message.guild.id, {
                        ViewChannel: false
                    });
                    await interaction.reply({ content: 'Le salon vocal est maintenant caché (👁️).', ephemeral: true });
                    break;

                case 'unhide':
                    await voiceChannel.permissionOverwrites.edit(message.guild.id, {
                        ViewChannel: true
                    });
                    await interaction.reply({ content: 'Le salon vocal est maintenant visible (👁️).', ephemeral: true });
                    break;

                case 'mute':
                    voiceChannel.members.forEach(member => {
                        member.voice.setMute(true);
                    });
                    await interaction.reply({ content: 'Tous les membres du salon vocal ont été mutés (🔇).', ephemeral: true });
                    break;

                case 'unmute':
                    voiceChannel.members.forEach(member => {
                        member.voice.setMute(false);
                    });
                    await interaction.reply({ content: 'Tous les membres du salon vocal ont été démutés (🔊).', ephemeral: true });
                    break;

                case 'limit':
                    await interaction.reply({ content: 'Entrez la limite de membres (nombre) :', ephemeral: true });
                    const limitFilter = m => m.author.id === message.author.id;
                    const limitCollector = message.channel.createMessageCollector({ limitFilter, max: 1, time: 15000 });

                    limitCollector.on('collect', async (m) => {
                        const limit = parseInt(m.content);
                        if (isNaN(limit) || limit < 1 || limit > 99) {
                            return interaction.followUp({ content: "Veuillez entrer un nombre valide entre 1 et 99.", ephemeral: true });
                        }
                        await voiceChannel.setUserLimit(limit);
                        await interaction.followUp({ content: `Limite de membres fixée à ${limit} (👤).`, ephemeral: true });
                    });
                    break;

                case 'disconnect':
                    voiceChannel.members.forEach(member => {
                        member.voice.disconnect();
                    });
                    await interaction.reply({ content: 'Tous les membres ont été déconnectés du salon vocal (🚪).', ephemeral: true });
                    break;

                case 'delete':
                    await voiceChannel.delete();
                    await interaction.reply({ content: 'Votre salon vocal a été supprimé (❌).', ephemeral: true });
                    break;

                default:
                    break;
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                message.channel.send('Gestion du salon vocal expirée. Réessayez.');
            }
        });
    }
};
