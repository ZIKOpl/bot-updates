const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'sync',
    description: 'Synchronise les salons textuels avec leur catégorie.',
    usage: "sync <channelid/all>",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Vérification des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permissionLevel = client.db.get(`perm_sync.${message.guild.id}`);
            if (permissionLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (permissionLevel === "public") pass = true;   
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        // Détermine les salons à synchroniser
        const syncChannel = message.mentions.channels.first();
        const syncAll = args.includes('all');

        // Récupération des salons à synchroniser
        const channelsToSync = syncAll ? message.guild.channels.cache.filter(c => c.type === 0) : [syncChannel]; // Utilisez 0 pour les salons textuels

        if (!syncChannel && !syncAll) {
            return message.reply("Vous devez mentionner un salon ou utiliser `all` pour synchroniser tous les salons.");
        }

        let syncedChannels = [];

        for (const channel of channelsToSync) {
            if (channel.type !== 0) continue; // Utilisez 0 pour les salons textuels

            const category = channel.parent;
            if (category) {
                const permissions = category.permissionsFor(message.guild.roles.everyone).serialize();
                await channel.permissionOverwrites.edit(message.guild.roles.everyone.id, {
                    ViewChannel: permissions.ViewChannel // Utilisez PermissionsBitField.Flags.ViewChannel pour Discord.js v14+
                });
                syncedChannels.push(channel);
            }
        }

        // Création d'un embed de réponse
        const embed = new EmbedBuilder()
            .setTitle('Synchronisation des Salons')
            .setColor(client.color)
            .setDescription(syncedChannels.length > 0 ? 
                `Les salons suivants ont été synchronisés avec leur catégorie :\n${syncedChannels.map(c => `<#${c.id}>`).join('\n')}` : 
                "Aucun salon n'a été synchronisé.");

        return message.reply({ embeds: [embed] });
    }
};
