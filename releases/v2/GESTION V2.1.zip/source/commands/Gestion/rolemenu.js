const Discord = require('discord.js');

module.exports = {
    name: "rolemenu",
    description: "Permet de crée un rolemenu.",
    run: async (client, message, args, commandName) => {
        let ii = 1;
        let pass = false;
        let staff = client.staff;
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        const mainembed = msg => {
            const embed = new Discord.EmbedBuilder()
                .setTitle("Configuration du Rolemenu")
                .setColor(client.color)
                .setFooter(client.footer)
                .setDescription(`
                \`Type\` - **${client.db.get(`menu_${message.guild.id}`) ? "Menu" : "Boutons"}**
                \`Message\` - ${message.guild.channels.cache.get(client.db.get(`buttonrolec_${message.guild.id}`)) ?? "Aucun salon"}
                \`${client.db.get(`buttoncolor1_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname1_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole1_${message.guild.id}`)) ?? "Pas de rôle"})
                \`${client.db.get(`buttoncolor2_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname2_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole2_${message.guild.id}`)) ?? "Pas de rôle"})
                \`${client.db.get(`buttoncolor3_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname3_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole3_${message.guild.id}`)) ?? "Pas de rôle"})
                \`${client.db.get(`buttoncolor4_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname4_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole4_${message.guild.id}`)) ?? "Pas de rôle"})`.replaceAll('                ', ''))
                
            const row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
            .setCustomId(`button-${message.id}`)
            .setMaxValues(1)
            .setMinValues(1)
            .addOptions([
                {
                    label: "Modifier le 1er bouton",
                    value: "button1",
                    emoji: client.db.get(`buttoncolor1_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le 2eme bouton",
                    value: "button2",
                    emoji: client.db.get(`buttoncolor2_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le 3eme bouton",
                    value: "button3",
                    emoji: client.db.get(`buttoncolor3_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le 4eme bouton",
                    value: "button4",
                    emoji: client.db.get(`buttoncolor4_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le type",
                    value: "type",
                    emoji: "💎"
                },
                {
                    label: "Modifier le message",
                    value: "msg",
                    emoji: "💬"
                },
                {
                    label: "Envoyer les boutons",
                    value: "send",
                    emoji: "✅"
                }
            ])
            )

            msg?.edit({embeds: [embed], components: [row]})
        }

        const editbutton = (msg, i) => {
            const embed = new Discord.EmbedBuilder()
            .setTitle(`Configuartion du bouton ${i}`)
            .setColor(client.color)
            .setFooter(client.footer)
            .addFields(
                {name: "Couleur du bouton", value: `\`${client.db.get(`buttoncolor${i}_${message.guild.id}`) ?? "⚫"}\``, inline: true},
                {name: "Text du bouton", value: `${client.db.get(`buttonname${i}_${message.guild.id}`) ?? "**Pas de nom**"}`, inline: true},
                {name: "Rôle donné", value: `${message.guild.roles.cache.get(client.db.get(`buttonrole${i}_${message.guild.id}`)) ?? "Pas de rôle"}`}
            )

            const row = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder()
                .setCustomId(`button`)
                .setMaxValues(1)
                .setMinValues(1)
                .addOptions([
                {
                    label: "Modifier la couleur",
                    value: "color"
                },
                {
                    label: "Modifier le texte",
                    value: "text",
                },
                {
                    label: "Modifier le rôle",
                    value: "role",
                },
                {
                    label: "Retour",
                    value: "retour"
                }
                ])
            )

            msg.edit({embeds: [embed], components: [row]})
        }




        const embed = new Discord.EmbedBuilder()
            .setTitle("Configuration du Rolemenu")
            .setColor(client.color)
            .setFooter(client.footer)
            .setDescription(`
                \`Type\` - **${client.db.get(`menu_${message.guild.id}`) ? "Menu" : "Boutons"}**
                \`Message\` - ${message.guild.channels.cache.get(client.db.get(`buttonrolec_${message.guild.id}`)) ?? "Aucun salon"}
                \`${client.db.get(`buttoncolor1_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname1_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole1_${message.guild.id}`)) ?? "Pas de rôle"})
                \`${client.db.get(`buttoncolor2_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname2_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole2_${message.guild.id}`)) ?? "Pas de rôle"})
                \`${client.db.get(`buttoncolor3_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname3_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole3_${message.guild.id}`)) ?? "Pas de rôle"})
                \`${client.db.get(`buttoncolor4_${message.guild.id}`) ?? "⚫"}\` - **${client.db.get(`buttonname4_${message.guild.id}`) ?? "Pas de nom"}** (${message.guild.roles.cache.get(client.db.get(`buttonrole4_${message.guild.id}`)) ?? "Pas de rôle"})`.replaceAll('                ', ''))
                
            const row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
            .setCustomId(`button-${message.id}`)
            .setMaxValues(1)
            .setMinValues(1)
            .addOptions([
                {
                    label: "Modifier le 1er bouton",
                    value: "button1",
                    emoji: client.db.get(`buttoncolor1_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le 2eme bouton",
                    value: "button2",
                    emoji: client.db.get(`buttoncolor2_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le 3eme bouton",
                    value: "button3",
                    emoji: client.db.get(`buttoncolor3_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le 4eme bouton",
                    value: "button4",
                    emoji: client.db.get(`buttoncolor4_${message.guild.id}`) ?? "⚫"
                },
                {
                    label: "Modifier le type",
                    value: "type",
                    emoji: "💎"
                },
                {
                    label: "Supprimer les boutons",
                    value: "delete",
                    emoji: "🗑️"
                },
                {
                    label: "Modifier le message",
                    value: "msg",
                    emoji: "💬"
                },
                {
                    label: "Envoyer les boutons",
                    value: "send",
                    emoji: "✅"
                }
            ])
            )

        const msg = await message.channel.send({embeds: [embed], components: [row]})
        const filter = (m) => m.author.id === message.author.id
        const collector = message.channel.createMessageComponentCollector({ time: 1000 * 60 * 10 });
        
        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) return interaction.reply({content: "Vous ne pouvez pas utiliser ce menu", ephemeral: true});
            interaction.deferUpdate().catch(() => false)
            if (!interaction.isStringSelectMenu()) return;

            if (interaction.values[0].startsWith('button') && !interaction.values[0].includes('_')){
                ii = interaction.values[0].split('button')[1]
            
                const embed = new Discord.EmbedBuilder()
                    .setTitle(`Configuation du bouton ${ii}`)
                    .setColor(client.color)
                    .setFooter(client.footer)
                    .addFields(
                        {name: "Couleur du bouton", value: `\`${client.db.get(`buttoncolor${ii}_${message.guild.id}`) ??  "⚫"}\``, inline: true},
                        {name: "Text du bouton", value: `**${client.db.get(`buttoname${ii}_${message.guild.id}`) ?? "Pas de nom"}**`, inline: true},
                        {name: "Rôle donné", value: `${message.guild.roles.cache.get(client.db.get(`buttonrole${ii}_${message.guild.id}`)) ?? "Pas de rôle"}`}
                    )

                const row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.StringSelectMenuBuilder()
                    .setCustomId(`button${message.id}`)
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions([
                    {
                        label: "Modifier la couleur",
                        value: "color"
                    },
                    {
                        label: "Modifier le texte",
                        value: "text",
                    },
                    {
                        label: "Modifier le rôle",
                        value: "role",
                    },
                    {
                        label: "Retour",
                        value: "retour"
                    }
                    ])
                )
        
                msg.edit({embeds: [embed], components: [row]})
            }

            if (interaction.values[0] == "delete"){
                for (let i = 1; i < 4; i++){
                    client.db.delete(`buttoncolor${i}_${message.guild.id}`)
                    client.db.delete(`buttonname${i}_${message.guild.id}`)
                    client.db.delete(`buttonrole${i}_${message.guild.id}`)    
                }
                
                mainembed(msg)
            }

            if (interaction.values[0] === "type"){
                if ( client.db.get(`menu_${message.guild.id}`) == true) client.db.delete(`menu_${message.guild.id}`)
                else client.db.set(`menu_${message.guild.id}`, true)
                mainembed(msg);
            }

            if (interaction.values[0] === "retour") return mainembed(msg)
            if (interaction.values[0] === "text"){
                msg.edit({components: [new Discord.ActionRowBuilder().addComponents(new Discord.StringSelectMenuBuilder().setCustomId(`button${message.id}`).setMaxValues(1).setMinValues(1).setDisabled(true).addOptions([{label: "Modifier la couleur", value: "color"}, {label: "Modifier le texte", value: "text",}, {label: "Modifier le rôle", value: "role",}, {label: "Retour", value: "retour"}]))]})
                const msg2 = await message.channel.send("Quel est le nouveau texte du bouton")
    
                let collected = await message.channel.awaitMessages({ filter: filter, max: 1 })
                if (!collected || collected.size === 0) return;

                msg2.delete().catch(() => false)
                collected.first().delete().catch(() => false)
            
                client.db.set(`buttonname${ii}_${message.guild.id}`, collected.first().content)
                editbutton(msg, ii)
            }

            if (interaction.values[0] === "role"){
                msg.edit({components: [new Discord.ActionRowBuilder().addComponents(new Discord.StringSelectMenuBuilder().setCustomId(`button${message.id}`).setMaxValues(1).setMinValues(1).setDisabled(true).addOptions([{label: "Modifier la couleur", value: "color"}, {label: "Modifier le texte", value: "text",}, {label: "Modifier le rôle", value: "role",}, {label: "Retour", value: "retour"}]))]})
                const msg2 = await message.channel.send("Quel est le rôle à donner")
                
                let collected = await message.channel.awaitMessages({ filter: filter, max: 1 })
                if (!collected || collected.size === 0) return;

                msg2.delete().catch(() => false)
                collected.first().delete().catch(() => false)
                
                const role = collected.first().mentions.roles.first() || message.guild.roles.cache.get(collected.first().content)
                if (!role) {
                    message.channel.send(`Aucun rôle de trouvé pour \`${collected.first().content || "rien"}\``).then(m => setTimeout(() => m.delete().catch(() => false), 3000))
                    return msg.edit({components: [new Discord.ActionRowBuilder().addComponents(new Discord.StringSelectMenuBuilder().setCustomId(`button${message.id}`).setMaxValues(1).setMinValues(1).setDisabled(false).addOptions([{label: "Modifier la couleur", value: "color"}, {label: "Modifier le texte", value: "text",}, {label: "Modifier le rôle", value: "role",}, {label: "Retour", value: "retour"}]))]})
                }

                client.db.set(`buttonrole${ii}_${message.guild.id}`, role.id)
                editbutton(msg, ii)
            }
                
            if (interaction.values[0] === "color"){
                const embed = new Discord.EmbedBuilder()
                    .setTitle("Modifier la couleur")
                    .setDescription(`Veuillez choisir une couleur`)
                    .setColor(client.color)
                    .setFooter(client.footer)

                const row = new Discord.ActionRowBuilder().addComponents(
                    new Discord.StringSelectMenuBuilder()
                    .setCustomId("couleur")
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions([
                    {
                        label: "Rouge",
                        value: "rouge",
                        emoji: "🔴"
                    },
                    {
                        label: "Vert",
                        value: "vert",
                        emoji: "🟢"
                    },
                    {
                        label: "Bleu",
                        value: "bleu",
                        emoji: "🔵"
                    },
                    {
                        label: "Gris",
                        value: "gris",
                        emoji: "⚫"
                    },
                    ])
                )

                msg.edit({embeds: [embed], components: [row]})
                
            }
        
            if (interaction.values[0] === "rouge"){
                client.db.set(`buttoncolor${ii}_${message.guild.id}`, "🔴")
                interaction.channel.send({content: "La couleur du bouton est **rouge**"}).then(m => setTimeout(() => m.delete().catch(() => false), 2000))
                editbutton(msg, ii)
            }
            if (interaction.values[0] === "vert"){
                client.db.set(`buttoncolor${ii}_${message.guild.id}`, "🟢")
                interaction.channel.send({content: "La couleur du bouton est **vert**"}).then(m => setTimeout(() => m.delete().catch(() => false), 2000))
                editbutton(msg, ii)
            }
            if (interaction.values[0] === "bleu"){
                client.db.set(`buttoncolor${ii}_${message.guild.id}`, "🔵")
                interaction.channel.send({content: "La couleur du bouton est **bleu**"}).then(m => setTimeout(() => m.delete().catch(() => false), 2000))
                editbutton(msg, ii)
            }
            if (interaction.values[0] === "gris"){
                client.db.set(`buttoncolor${ii}_${message.guild.id}`, "⚫")
                interaction.channel.send({content: "La couleur du bouton est **gris**"}).then(m => setTimeout(() => m.delete().catch(() => false), 2000))
                editbutton(msg, ii)
            }

            if (interaction.values[0] === "msg"){                
                const msg1 = await message.channel.send("Dans quel salon se trouve le meessage ?")
                
                let collected = await message.channel.awaitMessages({ filter: filter, max: 1 })
                if (!collected || collected.size === 0) return;

                msg1.delete().catch(() => false)
                collected.first().delete().catch(() => false)

                const channel = collected.first().mentions.channels.first() || message.guild.channels.cache.get(collected.first().content)
                if (!channel) return message.channel.send(`Aucun salon de trouvé pour \`${collected.first().content || "rien"}\``)

                const msg2 = await message.channel.send("Quel est l'ID du message ?")
                let collected2 = await message.channel.awaitMessages({ filter: filter, max: 1 })
                if (!collected2 || collected2.size === 0) return;
                
                msg2.delete().catch(() => false)
                collected2.first().delete().catch(() => false)

                const messages = await channel.messages.fetch(collected2.first().content).catch(() => false)
                if (!messages) return message.channel.send(`Aucun message de trouvé avec comme ID \`${collected2.first().content || "rien"}\``).then(m => setTimeout(() => m.delete().catch(() => false), 3000))
                if (messages.author.id !== client.user.id) return message.channel.send("Je ne suis pas l'autheur de ce message.").then(m => setTimeout(() => m.delete().catch(() => false), 3000))
                client.db.set(`buttonrolec_${message.guild.id}`, channel.id)
                client.db.set(`buttonrolem_${message.guild.id}`, messages.id)
            }

                if (interaction.values[0] === "send"){
                if (!client.db.get(`buttonrolem_${message.guild.id}`)) return interaction.reply({content: "Vous devez définir un message", ephemeral: true})
                
                const channel = message.guild.channels.cache.get(client.db.get(`buttonrolec_${message.guild.id}`))
                if (!channel) return message.channel.send(`Aucun salon de trouvé. Veuillez en désigner un.`).then((m) => setTimtout(() => m.delete().catch(() => false, 5000)));

                const messages = await channel.messages.fetch(client.db.get(`buttonrolem_${message.guild.id}`))
                if (!messages) return message.channel.send('Veuillez entrer un ID de message valide.').then((m) => setTimtout(() => m.delete().catch(() => false, 5000)));
                if (messages.author.id !== client.user.id) return message.channel.send("Je dois être l'auteur du message pour pouvoir mettre des boutons").then((m) => setTimtout(() => m.delete().catch(() => false, 5000)));
                const row = new Discord.ActionRowBuilder()
                
                const role1 = message.guild.roles.cache.get(client.db.get(`buttonrole1_${message.guild.id}`))
                const role2 = message.guild.roles.cache.get(client.db.get(`buttonrole2_${message.guild.id}`))
                const role3 = message.guild.roles.cache.get(client.db.get(`buttonrole3_${message.guild.id}`))
                const role4 = message.guild.roles.cache.get(client.db.get(`buttonrole4_${message.guild.id}`))
                
                if ((!client.db.get(`buttonname1_${message.guild.id}`) && !role1) &&
                    (!client.db.get(`buttonname2_${message.guild.id}`) && !role2) &&
                    (!client.db.get(`buttonname3_${message.guild.id}`) && !role3) &&
                    (!client.db.get(`buttonname4_${message.guild.id}`) && !role4)) return message.channel.send("Veuillez crée au moins un bouton/menu").then(m => setTimeout(() =>  m.delete().catch(() => false), 5000));
                if (client.db.get(`menu_${message.guild.id}`)){
                    const menu = new Discord.StringSelectMenuBuilder()
                        .setCustomId(`button-${message.id}`)
                        .setMinValues(1)

                    if (client.db.get(`buttonname1_${message.guild.id}`) && role1) menu.addOptions([{ label: client.db.get(`buttonname1_${message.guild.id}`), value: `buttonrole1_${role1.id}` }])
                    if (client.db.get(`buttonname2_${message.guild.id}`) && role2) menu.addOptions([{ label: client.db.get(`buttonname2_${message.guild.id}`), value: `buttonrole2_${role2.id}` }])
                    if (client.db.get(`buttonname3_${message.guild.id}`) && role3) menu.addOptions([{ label: client.db.get(`buttonname3_${message.guild.id}`), value: `buttonrole3_${role3.id}` }])
                    if (client.db.get(`buttonname4_${message.guild.id}`) && role4) menu.addOptions([{ label: client.db.get(`buttonname4_${message.guild.id}`), value: `buttonrole4_${role4.id}` }])
                    menu.setMaxValues(menu.options.length)
                    
                    row.addComponents(menu);

                    messages.edit({components: [row]})
                }
                else {
                    if (client.db.get(`buttonname1_${message.guild.id}`) && role1) row.addComponents(new Discord.ButtonBuilder().setCustomId(`buttonrole1_${role1.id}`).setLabel(client.db.get(`buttonname1_${message.guild.id}`)).setStyle(buttoncolor(client.db.get(`buttoncolor1_${message.guild.id}`) ?? "⚫")))
                    if (client.db.get(`buttonname2_${message.guild.id}`) && role2) row.addComponents(new Discord.ButtonBuilder().setCustomId(`buttonrole2_${role2.id}`).setLabel(client.db.get(`buttonname2_${message.guild.id}`)).setStyle(buttoncolor(client.db.get(`buttoncolor2_${message.guild.id}`) ?? "⚫")))
                    if (client.db.get(`buttonname3_${message.guild.id}`) && role3) row.addComponents(new Discord.ButtonBuilder().setCustomId(`buttonrole3_${role3.id}`).setLabel(client.db.get(`buttonname3_${message.guild.id}`)).setStyle(buttoncolor(client.db.get(`buttoncolor3_${message.guild.id}`) ?? "⚫")))
                    if (client.db.get(`buttonname4_${message.guild.id}`) && role4) row.addComponents(new Discord.ButtonBuilder().setCustomId(`buttonrole4_${role4.id}`).setLabel(client.db.get(`buttonname4_${message.guild.id}`)).setStyle(buttoncolor(client.db.get(`buttoncolor4_${message.guild.id}`) ?? "⚫")))
        
                    if (messages.components && messages.components.length > 0) messages.edit({components: [messages.components[0], row]})
                    else messages.edit({components: [row]})
                }
            }
        })
    }
}

const buttoncolor = emoji => {
    switch(emoji){
    case "🟢": return Discord.ButtonStyle.Success
    case "🔴": return Discord.ButtonStyle.Danger
    case "⚫": return Discord.ButtonStyle.Secondary
    case "🔵": return Discord.ButtonStyle.Primary
    }
}
