const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: "massrole",
    description: "Ajoute ou retire un rôle à tous les membres du serveur.",
    usage: "massrole",

    run: async (client, message, args) => {
        let staff = client.staff;
        let pass = false;

        // Vérification des permissions du membre
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            for (let i = 1; i <= 5; i++) {
                const permRoles = client.db.get(`perm${i}.${message.guild.id}`);
                if (permRoles && client.db.get(`perm_massrole.${message.guild.id}`) === `${i}` && 
                    message.member.roles.cache.some(r => permRoles.includes(r.id))) {
                    pass = true;
                    break;
                }
            }
            if (client.db.get(`perm_massrole.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        // Créer un embed initial pour choisir l'action
        const initialEmbed = new EmbedBuilder()
            .setTitle('Gestion de Rôle Massif')
            .setDescription('Choisissez une action pour le rôle.')
            .setColor(client.color)
            .setFooter(client.footer)
            .setTimestamp();

        // Créer un sélecteur pour ajouter/retirer des rôles
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('role_action')
            .setPlaceholder('Choisissez une action')
            .addOptions([
                {
                    label: 'Ajouter un rôle',
                    value: 'add_role',
                },
                {
                    label: 'Retirer un rôle',
                    value: 'remove_role',
                }
            ]);

        // Créer une ligne pour le sélecteur
        const row = new ActionRowBuilder().addComponents(selectMenu);

        // Envoyer le message initial avec l'embed et les composants
        await message.channel.send({ embeds: [initialEmbed], components: [row] });

        // Créer un collecteur pour gérer les interactions
        const filter = i => i.user.id === message.author.id;
        const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async i => {
            // Si l'utilisateur sélectionne une action
            if (i.customId === 'role_action') {
                // Vérifier si les valeurs sont définies
                if (!i.values || !i.values[0]) {
                    return i.reply({ content: 'Une erreur s\'est produite lors de la sélection.', ephemeral: true });
                }
                const selectedValue = i.values[0];

                // Mettre à jour l'embed en fonction de l'action sélectionnée
                const actionMessage = selectedValue === 'add_role' ? 'Vous avez sélectionné: Ajouter' : 'Vous avez sélectionné: Retirer';
                
                await i.update({ embeds: [initialEmbed.setDescription(actionMessage)], components: [] });

                // Demander le rôle à ajouter/retirer
                await i.followUp({ content: 'Veuillez mentionner le rôle à ajouter ou retirer.', ephemeral: true });

                // Filtre pour le message du rôle
                const filterMessage = m => m.author.id === message.author.id;
                const collectorMessage = message.channel.createMessageCollector({ filter: filterMessage, time: 30000 });

                collectorMessage.on('collect', async msg => {
                    const roleMentioned = msg.mentions.roles.first();
                    if (!roleMentioned) {
                        await msg.reply({ content: "Rôle introuvable. Veuillez mentionner un rôle valide.", ephemeral: true });
                        return;
                    }

                    const role = roleMentioned;
                    const roleAction = selectedValue; // Action choisie (add_role ou remove_role)

                    // Démarrer le processus d'ajout/retrait du rôle
                    await msg.reply({ content: `Début de l'ajout/retrait du rôle <@&${role.id}>. Veuillez patienter...`, ephemeral: true });

                    // Récupérer tous les membres du serveur
                    let members = await message.guild.members.fetch();

                    // Créer l'embed de progression avec le message approprié
                    const progressEmbed = new EmbedBuilder()
                        .setTitle('Processus en Cours')
                        .setDescription(`${roleAction === 'add_role' ? 'Ajout' : 'Retrait'} <@&${role.id}> à ${members.size} membres...`)
                        .setColor(client.color)
                        .setFooter(client.footer)
                        .setTimestamp();

                    const progressMessage = await msg.channel.send({ embeds: [progressEmbed] });

                    let success = [];
                    let failure = [];

                    for (const [id, member] of members) {
                        try {
                            if (roleAction === 'add_role') {
                                await member.roles.add(role);
                            } else {
                                await member.roles.remove(role);
                            }
                            success.push(member.user.tag);
                        } catch (error) {
                            failure.push(member.user.tag);
                        }

                        const currentProgressEmbed = new EmbedBuilder()
                            .setTitle('Processus en Cours')
                            .setDescription(`${roleAction === 'add_role' ? 'Ajout' : 'Retrait'} <@&${role.id}> à ${members.size} membres...\n> Succès: ${success.length}\n> Échecs: ${failure.length}`)
                            .setColor(client.color)
                            .setFooter(client.footer)
                            .setTimestamp();

                        await progressMessage.edit({ embeds: [currentProgressEmbed] });
                    }

                    const finalEmbed = new EmbedBuilder()
                        .setTitle('Résultat du Processus')
                        .setColor(client.color)
                        .addFields([
                            { name: 'Succès', value: success.length > 0 ? success.join('\n') : 'Aucun', inline: true },
                            { name: 'Échecs', value: failure.length > 0 ? failure.join('\n') : 'Aucun', inline: true }
                        ])
                        .setFooter(client.footer);

                    await progressMessage.edit({ embeds: [finalEmbed] });
                    collectorMessage.stop();
                });

                collectorMessage.on('end', collected => {
                    if (collected.size === 0) {
                        i.followUp({ content: 'Temps écoulé! Aucune action effectuée.', ephemeral: true });
                    }
                });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                message.channel.send({ content: 'Temps écoulé! Aucune action effectuée.', ephemeral: true });
            }
        });
    }
};
