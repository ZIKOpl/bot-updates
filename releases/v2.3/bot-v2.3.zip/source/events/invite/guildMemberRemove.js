const { Events } = require("discord.js");

module.exports = {
    name: Events.GuildMemberRemove,
    run: async (client, member) => {
        try {
            // Fetch the full member object if it's partial
            if (member.partial) member = await member.fetch();

            const guildId = member.guild.id;
            const userId = member.user.id;

            // Fetch leave settings from the database
            const db = client.db.get(`leavesettings_${guildId}`);
            if (!db || !db.status) return;

            const goodbyeChannel = client.channels.cache.get(db.channel);

            // Handle case when the user is a bot
            if (member.user.bot && goodbyeChannel) {
                return goodbyeChannel.send(`Le bot ${member.toString()} a quitté le serveur.`).catch(err => console.error(err));
            }

            // Fetch the inviter's ID from the database
            const inviterId = await client.db.get(`invitedby_${guildId}_${userId}`);
            if (!inviterId) return;

            // Fetch invite details associated with the inviter
            const invitesOfUser = await client.db.get(`invites_${inviterId}_${guildId}`);
            if (!invitesOfUser) return;

            const inviter = member.guild.members.cache.get(inviterId);
            if (!inviter) return;

            // Format the goodbye message using placeholders
            const goodbyeMessage = db.message
                .replaceAll('{user.id}', userId)
                .replaceAll('{user.tag}', member.user.tag)
                .replaceAll('{user.username}', member.user.username)
                .replaceAll('{user}', member.user.toString())
                .replaceAll('{inviter.id}', inviter.user.id)
                .replaceAll('{inviter.username}', inviter.user.username)
                .replaceAll('{inviter.tag}', inviter.user.tag)
                .replaceAll('{inviter.total}', invitesOfUser.total)
                .replaceAll('{inviter.valid}', invitesOfUser.valid)
                .replaceAll('{inviter.invalide}', invitesOfUser.left)
                .replaceAll('{inviter.bonus}', invitesOfUser.bonus)
                .replaceAll('{guild.name}', member.guild.name)
                .replaceAll('{guild.id}', guildId)
                .replaceAll('{guild.count}', member.guild.memberCount);

            // Send the formatted goodbye message to the configured channel
            if (goodbyeChannel) {
                goodbyeChannel.send(goodbyeMessage).catch(err => console.error(err));
            }
        } catch (error) {
            console.error('Error handling guildMemberRemove event:', error);
        }
    }
};
