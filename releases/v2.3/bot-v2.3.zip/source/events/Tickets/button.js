const { ActionRowBuilder, StringSelectMenuBuilder, PermissionFlagsBits, ButtonBuilder, EmbedBuilder } = require('discord.js');
const Valory = require('../../structures/client');
const Discord = require('discord.js');

module.exports = {
    name: "interactionCreate",
    /**
     * @param {Valory} client
     * @param {Valory} interaction
     */
    run: async (client, interaction) => {
        try {
            if (!interaction.isButton()) return;
            if (interaction.customId.startsWith('ticket_')) {
                await interaction.deferReply({ ephemeral: true });

                const color = await client.db.get(`color_${interaction.guild.id}`) || client.config.default_color;
                const id = interaction.customId.split('_')[1];
                const db = await client?.db.get(`ticket_${interaction.guild.id}`);
                if (!db) return;

                const option = db.option.find(option => option.value === id);
                if (!option) return;

                const tickeruser = await client.db.get(`ticket_user_${interaction.guild.id}`) || [];
                const resul = tickeruser.find(ticket => ticket.author === interaction.user.id);

                if (resul && tickeruser.length >= db?.maxticket) {
                    return await interaction.editReply({ content: `Vous avez déjà atteint le nombre maximal de tickets ouverts !`, ephemeral: true });
                }

                // Build the permission overwrites
                let permissionOverwrites = [
                    {
                        id: interaction.guild.roles.everyone.id, // Ensure this is a valid role ID
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id, // Use user ID here
                        allow: [
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.AddReactions
                        ]
                    }
                ];

                // Add all configured roles to the permissions
                if (option.acess && Array.isArray(option.acess)) {
                    option.acess.forEach(roleId => {
                        const role = interaction.guild.roles.cache.get(roleId);
                        if (role) {
                            permissionOverwrites.push({
                                id: role.id,
                                allow: [
                                    PermissionFlagsBits.SendMessages,
                                    PermissionFlagsBits.ViewChannel,
                                    PermissionFlagsBits.AttachFiles,
                                    PermissionFlagsBits.AddReactions
                                ]
                            });
                        } else {
                            console.error(`Role with ID ${roleId} not found`);
                        }
                    });
                }

                const channel = await interaction.guild.channels.create({
                    parent: client.channels.cache.get(option.categorie) ? option.categorie : null,
                    name: option.text + '-' + interaction.user.username,
                    type: 0,
                    permissionOverwrites: permissionOverwrites,
                });

                if (channel) {
                    await interaction.editReply({ content: `Ticket ouvert <#${channel.id}>` });

                    const embed = new EmbedBuilder()
                        .setColor(color)
                        .setFooter(client.footer)
                        .setDescription(option.message)
                        .setTitle('Ticket ouvert par ' + interaction.user.username);

                    const idunique = code(15);
                    const button = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel('Fermer le ticket')
                            .setStyle(4)
                            .setEmoji('🔒')
                            .setCustomId("close_" + idunique)
                    );

                    if (db.claimbutton) {
                        button.addComponents(
                            new ButtonBuilder()
                                .setLabel('Récupère le ticket')
                                .setStyle(2)
                                .setEmoji('🔐')
                                .setCustomId("claim_" + idunique)
                        );
                    }

                    channel.send({
                        embeds: [embed],
                        content: option.mention ? `<@&${option.mention}>` : null,
                        components: [button]
                    });

                    tickeruser.push({
                        salon: channel.id,
                        author: interaction.user.id,
                        date: Date.now(),
                        id: idunique,
                        option: option.value,
                        claim: null,
                    });

                    await client.db.set(`ticket_user_${interaction.guild.id}`, tickeruser);
                } else {
                    await interaction.editReply({ content: 'Erreur lors de la création du ticket.', ephemeral: true });
                }
            }
        } catch (error) {
            console.error(error);
            if (interaction.replied || interaction.deferred) {
                await interaction.editReply({ content: 'Une erreur est survenue.', flags: 64 });
            } else {
                await interaction.reply({ content: 'Une erreur est survenue.', ephemeral: true });
            }
        }
    }
};

function code(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        code += characters.charAt(randomIndex);
    }
    return code;
}
