const { VoiceChannel, CategoryChannel, ChannelType } = require('discord.js');

module.exports = {
    name: "voiceStateUpdate",
    run: async (client, oldState, newState) => {
        // Assurez-vous que les IDs sont définis
        const guildID = newState.guild.id;
        const targetChannelId = client.db.get(`tempvoc_${guildID}_targetChannelId`);
        const categoryId = client.db.get(`tempvoc_${guildID}_categoryId`);

        if (!targetChannelId || !categoryId) return;

        const targetChannel = newState.guild.channels.cache.get(targetChannelId);
        const category = newState.guild.channels.cache.get(categoryId);

        if (!(targetChannel && targetChannel instanceof VoiceChannel)) return;
        if (!(category && category instanceof CategoryChannel)) return;

        // Vérifie si l'utilisateur a rejoint le salon cible
        if (newState.channelId === targetChannel.id && !oldState.channel) {
            const member = newState.member;

            try {
                // Crée un salon vocal temporaire pour le membre
                const privateChannel = await newState.guild.channels.create({
                    name: `🔊・${member.user.username}`, // Assurez-vous que le nom est défini
                    type: ChannelType.GuildVoice, // Utilisez ChannelType.GuildVoice pour Discord.js v14
                    parent: category.id, // Utilisez l'ID de la catégorie ici
                    permissionOverwrites: [
                        {
                            id: newState.guild.id,
                            deny: ['ViewChannel'],
                        },
                        {
                            id: member.id,
                            allow: ['ViewChannel', 'Connect', 'Speak'],
                        },
                    ],
                });

                // Déplace le membre dans le salon vocal privé
                await member.voice.setChannel(privateChannel);

                // Détecte le départ du membre du salon
                const handleMemberLeave = (oldState, newState) => {
                    if (oldState.channel && oldState.channel.id === privateChannel.id && !oldState.channel.members.size) {
                        privateChannel.delete().catch(err => console.error(err));
                        client.off('voiceStateUpdate', handleMemberLeave); // Arrête d'écouter l'événement après suppression
                    }
                };

                client.on('voiceStateUpdate', handleMemberLeave);

            } catch (err) {
                console.error(err);
                // Vous pouvez aussi envisager d'ajouter une notification ici si besoin
            }
        }
    }
};
