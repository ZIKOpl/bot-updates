const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'webhookCreate',
    run: async (client, webhook) => {
        console.log('WebhookCreate event triggered'); // Debug log

        // Vérifiez si la création de webhooks est surveillée
        const antiwebhook = client.db.get(`antiwebhook_${webhook.guild.id}`);
        if (!antiwebhook || antiwebhook.status === 'off') return;

        console.log('Antiwebhook is active'); // Debug log

        // Fetch the audit logs to determine who created the webhook
        let webhookCreator = null;
        try {
            const auditLogs = await webhook.guild.fetchAuditLogs({
                type: 14, // WEBHOOK_CREATE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                webhookCreator = entry.executor;
                console.log(`Webhook created by: ${webhookCreator.tag}`); // Debug log
            }
        } catch (error) {
            console.error('Error fetching audit logs:', error);
            return;
        }

        // Skip if the creator is the bot or the guild owner
        if (webhookCreator.id === client.user.id || webhookCreator.id === webhook.guild.ownerId) return;

        // Check if the creator is whitelisted
        const whitelisted = client.db.get(`wl.${webhook.guild.id}`) || [];
        if (whitelisted.includes(webhookCreator.id)) {
            console.log(`User ${webhookCreator.tag} is whitelisted and will not be sanctioned.`);
            return;
        }

        // Determine the sanction based on the configuration
        const sanction = antiwebhook.createSanction || 'none'; // Default to 'none' if not set
        console.log(`Sanction determined: ${sanction}`); // Debug log

        // Apply the sanction
        try {
            if (sanction === 'derank') {
                const member = webhook.guild.members.resolve(webhookCreator.id);
                if (member) {
                    // Remove all roles
                    const rolesToRemove = member.roles.cache.map(role => role.id);
                    await member.roles.remove(rolesToRemove);
                    console.log(`All roles removed from ${member.user.tag}.`);

                    // Add @everyone role if necessary
                    const everyoneRole = webhook.guild.roles.everyone;
                    if (everyoneRole && !member.roles.cache.has(everyoneRole.id)) {
                        await member.roles.add(everyoneRole.id);
                        console.log(`@everyone role added to ${member.user.tag}.`);
                    }
                } else {
                    console.error('Member not found for creator ID:', webhookCreator.id);
                }
            } else if (sanction === 'kick') {
                await webhook.guild.members.kick(webhookCreator.id, 'Antiwebhook - webhook creation');
                console.log(`User ${webhookCreator.tag} kicked for webhook creation.`);
            } else if (sanction === 'ban') {
                await webhook.guild.bans.create(webhookCreator.id, { reason: 'Antiwebhook - webhook creation' });
                console.log(`User ${webhookCreator.tag} banned for webhook creation.`);
            } else {
                console.error(`Unrecognized sanction: ${sanction}`);
            }
        } catch (error) {
            console.error(`Error applying sanction: ${error}`);
        }

        // Log the action if logging is enabled
        const logChannelId = client.db.get(`raidlogs_${webhook.guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Webhook Created')
                    .setDescription(`A webhook was created in the server by <@${webhookCreator.id}>. The user has been ${sanction}.`)
                    .setColor(client.color) // Ensure the color is valid
                    .setTimestamp()
                    .setFooter(client.footer);

                logChannel.send({ embeds: [embed] });
            } else {
                console.error('Log channel not found for ID:', logChannelId);
            }
        } else {
            console.error('Log channel ID not configured.');
        }
    }
};
