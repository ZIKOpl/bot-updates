const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'roleCreate',
    run: async (client, role) => {
        // Vérifiez si la création de rôle est surveillée
        const antirole = client.db.get(`antirole_${role.guild.id}`);
        if (!antirole || antirole.status === 'off') return;

        // Fetch the audit logs to determine who created the role
        let roleCreator = null;
        try {
            const auditLogs = await role.guild.fetchAuditLogs({
                type: 30, // ROLE_CREATE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                roleCreator = entry.executor;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the creator is the bot or the guild owner
        if (roleCreator.id === client.user.id || roleCreator.id === role.guild.ownerId) return;

        // Check if the creator is whitelisted
        const whitelisted = client.db.get(`wl.${role.guild.id}`) || [];
        if (whitelisted.includes(roleCreator.id)) {
            console.log(`L'utilisateur ${roleCreator.tag} est en whitelist et ne sera pas sanctionné.`);
            return;
        }

        // Determine the sanction based on the configuration
        const sanction = antirole.createSanction || 'none'; // Default to 'none' if not set

        // Apply the sanction
        if (sanction === 'derank') {
            const member = role.guild.members.resolve(roleCreator.id);
            if (member) {
                try {
                    // Retirer tous les rôles du membre
                    const rolesToRemove = member.roles.cache.map(role => role.id);
                    await member.roles.remove(rolesToRemove);
                    console.log(`Tous les rôles ont été retirés pour ${member.user.tag}.`);
        
                    // Ajouter le rôle @everyone (si nécessaire)
                    const everyoneRole = role.guild.roles.everyone;

                    if (everyoneRole) {
                        try {
                            // Vérifiez si le rôle est toujours dans la cache avant d'ajouter
                            if (!member.roles.cache.has(everyoneRole.id)) {
                                await member.roles.add(everyoneRole.id);
                                console.log(`Le rôle @everyone a été ajouté pour ${member.user.tag}.`);
                            }
                        } catch (error) {
                            console.error('Erreur lors de l\'ajout du rôle @everyone :', error);
                        }
                    } else {
                        console.error('Le rôle @everyone n\'est pas trouvé sur le serveur.');
                    }
                    
                } catch (error) {
                    console.error('Erreur lors du retrait des rôles du membre :', error);
                }
            } else {
                console.error('Membre non trouvé pour le créateur ID:', roleCreator.id);
            }
        } else if (sanction === 'kick') {
            try {
                await role.guild.members.kick(roleCreator.id, 'Antirole - création de rôle');
                console.log(`L'utilisateur ${roleCreator.tag} a été expulsé pour la création de rôle.`);
            } catch (error) {
                console.error('Erreur lors de l\'expulsion du membre :', error);
            }
        } else if (sanction === 'ban') {
            try {
                await role.guild.bans.create(roleCreator.id, { reason: 'Antirole - création de rôle' });
                console.log(`L'utilisateur ${roleCreator.tag} a été banni pour la création de rôle.`);
            } catch (error) {
                console.error('Erreur lors du bannissement du membre :', error);
            }
        } else {
            console.error(`Sanction non reconnue : ${sanction}`);
        }

        // Supprimer le rôle immédiatement après sa création
        try {
            await role.delete('Antirole - suppression de rôle après création');
            console.log(`Le rôle ${role.name} a été supprimé.`);
        } catch (error) {
            console.error('Erreur lors de la suppression du rôle :', error);
        }

        // Log the action if logging is enabled
        const logChannelId = client.db.get(`raidlogs_${role.guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Rôle Créé et Supprimé')
                    .setDescription(`Le rôle ${role.name} a été créé et immédiatement supprimé. Créateur : <@${roleCreator.id}>. L'utilisateur a été ${sanction}.`)
                    .setColor(client.color) // Valeur par défaut pour la couleur
                    .setTimestamp()
                    .setFooter(client.footer);

                logChannel.send({ embeds: [embed] });
            }
        }
    }
};
