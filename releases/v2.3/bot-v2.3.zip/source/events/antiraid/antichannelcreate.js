const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'channelCreate',
    run: async (client, channel) => {
        // Vérifiez si la création du salon est surveillée
        const antichannel = client.db.get(`antichannel_${channel.guild.id}`);
        if (!antichannel || antichannel.status === 'off') return;

        // Fetch the audit logs to determine who created the channel
        let channelCreator = null;
        try {
            const auditLogs = await channel.guild.fetchAuditLogs({
                type: 10, // CHANNEL_CREATE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                channelCreator = entry.executor;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the creator is the bot or the guild owner
        if (channelCreator.id === client.user.id || channelCreator.id === channel.guild.ownerId) return;

        // Check if the creator is whitelisted
        const whitelisted = client.db.get(`wl.${channel.guild.id}`) || [];
        if (whitelisted.includes(channelCreator.id)) {
            console.log(`L'utilisateur ${channelCreator.tag} est en whitelist et ne sera pas sanctionné.`);
            return;
        }

        // Determine the sanction based on the configuration
        const sanction = antichannel.sanction || 'none'; // Default to 'none' if not set

        // Apply the sanction
        if (sanction === 'derank') {
            const member = channel.guild.members.resolve(channelCreator.id);
            if (member) {
                try {
                    // Retirer tous les rôles du membre
                    const rolesToRemove = member.roles.cache.map(role => role.id);
                    await member.roles.remove(rolesToRemove);
                    console.log(`Tous les rôles ont été retirés pour ${member.user.tag}.`);
        
                    // Ajouter le rôle @everyone (si nécessaire)
                    const everyoneRole = channel.guild.roles.everyone;

                    if (everyoneRole) {
                        try {
                            // Vérifiez si le rôle est toujours dans la cache avant d'ajouter
                            if (!member.roles.cache.has(everyoneRole.id)) {
                                await member.roles.add(everyoneRole.id);
                                console.log(`Le rôle @everyone a été ajouté pour ${member.user.tag}.`);
                            }
                        } catch (error) {
                            console.error('Erreur lors de l\'ajout du rôle @everyone :', error);
                        }
                    } else {
                        console.error('Le rôle @everyone n\'est pas trouvé sur le serveur.');
                    }
                    
                } catch (error) {
                    console.error('Erreur lors du retrait des rôles du membre :', error);
                }
            } else {
                console.error('Membre non trouvé pour le créateur ID:', channelCreator.id);
            }
        } else if (sanction === 'kick') {
            try {
                await channel.guild.members.kick(channelCreator.id, 'Antichannel - création de salon');
                console.log(`L'utilisateur ${channelCreator.tag} a été expulsé pour la création de salon.`);
            } catch (error) {
                console.error('Erreur lors de l\'expulsion du membre :', error);
            }
        } else if (sanction === 'ban') {
            try {
                await channel.guild.bans.create(channelCreator.id, { reason: 'Antichannel - création de salon' });
                console.log(`L'utilisateur ${channelCreator.tag} a été banni pour la création de salon.`);
            } catch (error) {
                console.error('Erreur lors du bannissement du membre :', error);
            }
        } else {
            console.error(`Sanction non reconnue : ${sanction}`);
        }

        // Log the action if logging is enabled
        const logChannelId = client.db.get(`raidlogs_${channel.guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Salon Créé')
                    .setDescription(`Le salon ${channel.name} a été créé par <@${channelCreator.id}>. L'utilisateur a été ${sanction}.`)
                    .setColor(client.color) // Assurez-vous que la couleur est valide
                    .setTimestamp()
                    .setFooter(client.footer);

                logChannel.send({ embeds: [embed] });
            }
        }
    }
};
