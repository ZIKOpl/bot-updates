const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "guildMemberUpdate",
    run: async (client, oldMember, newMember) => {
        try {
            const color = client.db.get(`color_${newMember.guild.id}`) || client.config.default_color;
            const guild = newMember.guild;
            if (!guild) return;
            if (newMember.id === client.user.id) return;

            const channelId = client.db.get(`rolelog_${guild.id}`);
            if (!channelId) return;

            const logChannel = guild.channels.cache.get(channelId);
            if (!logChannel) return;

            const user = await client.users.fetch(newMember.id).catch(() => null);
            if (!user) return;

            const oldRoles = oldMember.roles.cache.map(r => r.id);
            const newRoles = newMember.roles.cache.map(r => r.id);

            const added = newRoles.filter(id => !oldRoles.includes(id));
            const removed = oldRoles.filter(id => !newRoles.includes(id));

            if (added.length === 0 && removed.length === 0) return;

            let desc = `**Utilisateur :** [\`${user.username}\`](https://discord.com/users/${user.id}) (\`${user.id}\`)\n`;

            if (added.length > 0) {
                desc += `🟢 **Rôles ajoutés :** ${added.map(r => `<@&${r}>`).join(", ")}\n`;
            }
            if (removed.length > 0) {
                desc += `🔴 **Rôles retirés :** ${removed.map(r => `<@&${r}>`).join(", ")}\n`;
            }

            const embed = new EmbedBuilder()
                .setColor(color)
                .setAuthor({ name: `${user.username}`, iconURL: user.displayAvatarURL() })
                .setDescription(desc)
                .setFooter(client.footer)
                .setTimestamp();

            await logChannel.send({ embeds: [embed] });

        } catch (err) {
            console.error(`[guildMemberUpdate] Erreur :`, err);
        }
    }
};
