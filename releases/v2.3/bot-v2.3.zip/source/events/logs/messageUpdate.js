const Discord = require('discord.js');
const fs = require('fs');

module.exports = {
    name: 'messageUpdate',
    run: async (client, oldMessage, newMessage) => {
        // Vérifier que l'auteur existe et n'est pas un bot
        if (!newMessage.author || newMessage.author.bot) return;
        if (!oldMessage.author || oldMessage.author.id === client.user.id) return;
        if (!oldMessage.guild) return;

        // Vérifier l'existence du channel de logs dans la base de données
        let channel = client.db.get(`msglogs_${oldMessage.guild.id}`);
        if (!channel) return;
        let chan = oldMessage.guild.channels.cache.get(channel);
        if (!chan) return;

        // Vérifier si le canal actuel doit être ignoré
        let ignored = client.db.get(`msglogs_allow_${oldMessage.channel.id}`);
        if (ignored === true) return;

        // Créer et envoyer l'embed de log de message mis à jour
        let Embed = new Discord.EmbedBuilder()
            .setColor(client.color)
            .setAuthor({
                name: await client.lang('msglog.message9') + (oldMessage.author ? oldMessage.author.username : "Unknown User"),
                iconURL: oldMessage.author ? oldMessage.author.displayAvatarURL() : client.user.displayAvatarURL() // Image par défaut si l'auteur est manquant
            })
            .setDescription(`
**${await client.lang('msglog.message13')} [\`${oldMessage.channel.name}\`](https://discord.com/channels/${oldMessage.guild.id}/${oldMessage.channel.id})**
**${await client.lang('msglog.message14')}:** \`\`\`yml\n${oldMessage.content || "Message indisponible"}\`\`\`
**${await client.lang('msglog.message15')}:** \`\`\`yml\n${newMessage.content || "Message indisponible"}\`\`\`
`)
            .setTimestamp();

        chan.send({ embeds: [Embed] });
    }
};
