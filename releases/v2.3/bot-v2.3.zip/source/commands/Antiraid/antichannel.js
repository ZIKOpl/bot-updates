const Discord = require('discord.js');

module.exports = {
    name: "antichannel",
    description: "Permet d'activer, désactiver l'anticanal et de définir une sanction pour toutes les actions.",
    category: "antiraid",
    usage: "antichannel <on/off> | antichannel sanction <derank/kick/ban/aucune>",

    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Vérifier les permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_antichannel.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antichannel.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antichannel.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antichannel.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antichannel.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antichannel.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Récupérer les données de l'anticanal depuis la base de données
        const antichannelData = client.db.get(`antichannel_${message.guild.id}`) || {
            status: 'off',
            sanction: 'aucune'
        };

        // Activer ou désactiver l'anticanal
        if (args[0] === "on") {
            antichannelData.status = "on";
            antichannelData.sanction = antichannelData.sanction === 'aucune' ? 'derank' : antichannelData.sanction;
            client.db.set(`antichannel_${message.guild.id}`, antichannelData);
            return message.channel.send(`L'anticanal est désormais activé avec la sanction par défaut : \`${antichannelData.sanction}\` pour la création, la modification et la suppression de salons.`);
        }

        if (args[0] === "off") {
            antichannelData.status = "off";
            client.db.set(`antichannel_${message.guild.id}`, antichannelData);
            return message.channel.send(`L'anticanal est désormais désactivé.`);
        }

        // Définir la sanction pour toutes les actions (création, modification, suppression)
        if (args[0] === "sanction") {
            const sanction = args[1].toLowerCase();
            if (["derank", "kick", "ban", "Aucune"].includes(sanction)) {
                antichannelData.sanction = sanction;
                client.db.set(`antichannel_${message.guild.id}`, antichannelData);
                return message.channel.send(`La sanction pour la création, la modification et la suppression de salons est désormais définie sur \`${sanction}\`.`);
            } else {
                return message.channel.send(`Sanction invalide. Les sanctions possibles sont : \`derank\`, \`kick\`, \`ban\`, \`Aucune\`.`);
            }
        }

        // Afficher l'utilisation correcte en cas d'erreur
        return message.channel.send(`Utilisation incorrecte, utilisez : \`${client.prefix}antichannel <on/off>\` ou \`${client.prefix}antichannel sanction <derank/kick/ban/Aucune>\``);
    }
};
