const Discord = require('discord.js');

module.exports = {
    name: "antialt",
    description: "Active ou désactive l'anticrate et configure la durée minimale du compte.",
    category: "antiraid",
    usage: "antialt <on/off> | antialt <durée> (ex: 1d, 2w, 3m)",

    run: async (client, message, args) => {
        // Vérifier si `client.db` est défini
        if (!client.db) {
            console.error('Base de données non initialisée.');
            return message.channel.send('Erreur interne du bot. Veuillez réessayer plus tard.');
        }

        let pass = false;
        let staff = client.staff;

        // Vérifier les permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_antialt.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antialt.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antialt.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antialt.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antialt.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antialt.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        if (!pass) {
            return message.channel.send(client.noperm || 'Vous n\'avez pas la permission d\'utiliser cette commande.');
        }

        // Récupérer les données d'anticrate depuis la base de données
        const antialtData = client.db.get(`antialt_${message.guild.id}`) || {
            status: 'off',
            duration: '0d'
        };

        // Traitement des arguments pour activer ou désactiver l'anticrate
        if (args[0] === "on") {
            antialtData.status = "on";
            await client.db.set(`antialt_${message.guild.id}`, antialtData);
            return message.channel.send(`L'anticrate est désormais activé.`);
        }

        if (args[0] === "off") {
            antialtData.status = "off";
            await client.db.set(`antialt_${message.guild.id}`, antialtData);
            return message.channel.send(`L'anticrate est désormais désactivé.`);
        }

        // Traitement des arguments pour configurer la durée minimale du compte
        const duration = args[0];
        if (/^\d+[dhwms]$/.test(duration)) {
            antialtData.duration = duration;
            await client.db.set(`antialt_${message.guild.id}`, antialtData);
            return message.channel.send(`Durée minimale du compte configurée sur \`${duration}\`.`);
        } else {
            return message.channel.send(`Durée invalide. La durée doit être spécifiée en jours (d), heures (h), semaines (w), mois (m) ou années (y).`);
        }
    }
};
