const Discord = require('discord.js');

module.exports = {
    name: "antiwebhook",
    description: "Permet d'activer ou de désactiver l'antiwebhook, et de définir une sanction unique pour toutes les actions.",
    category: "antiraid",
    usage: "antiwebhook <on/off> | antiwebhook sanction <derank/kick/ban>",

    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Vérifier les permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_antiwebhook.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antiwebhook.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antiwebhook.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antiwebhook.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antiwebhook.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antiwebhook.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Récupérer les données de l'antiwebhook depuis la base de données
        const antiwebhookData = client.db.get(`antiwebhook_${message.guild.id}`) || {
            status: 'off',
            sanction: 'none',
        };

        console.log(`Current antiwebhook status: ${antiwebhookData.status}`); // Log actuel du statut

        // Activer ou désactiver l'antiwebhook
        if (args[0] === "on") {
            antiwebhookData.status = "on";
            await client.db.set(`antiwebhook_${message.guild.id}`, antiwebhookData);
            console.log(`Antiwebhook status updated to: ${antiwebhookData.status}`); // Log mis à jour
            return message.channel.send(`L'antiwebhook est désormais activé.`);
        }

        if (args[0] === "off") {
            antiwebhookData.status = "off";
            await client.db.set(`antiwebhook_${message.guild.id}`, antiwebhookData);
            console.log(`Antiwebhook status updated to: ${antiwebhookData.status}`); // Log mis à jour
            return message.channel.send(`L'antiwebhook est désormais désactivé.`);
        }

        // Configurer la sanction unique pour toutes les actions (création, mise à jour, suppression)
        if (args[0] === "sanction") {
            const sanction = args[1];
            if (["derank", "kick", "ban"].includes(sanction)) {
                antiwebhookData.sanction = sanction;
                await client.db.set(`antiwebhook_${message.guild.id}`, antiwebhookData);
                console.log(`Sanction set to ${sanction}`); // Log sanction mis à jour
                return message.channel.send(`La sanction pour la création, la mise à jour et la suppression de webhooks est désormais définie sur \`${sanction}\`.`);
            } else {
                return message.channel.send(`Sanction invalide. Les sanctions possibles sont : \`derank\`, \`kick\`, \`ban\`.`);
            }
        }

        // Afficher l'utilisation correcte en cas d'erreur
        return message.channel.send(`Utilisation incorrecte, utilisez : \`${client.prefix}antiwebhook <on/off>\` ou \`${client.prefix}antiwebhook sanction <derank/kick/ban>\``);
    }
};
