module.exports = {
    name: "greroll",
    aliases: ["giveawayreroll"],
    run: async (client, message, args, commandName) => {
        let staff = client.staff;
        let pass = false;

        // Check permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permLevel = client.db.get(`perm_${commandName}.${message.guild.id}`);
            if (permLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "public") pass = true;
        } else pass = true;

        if (pass === false) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        const uniqueIdentifier = args[0];
        if (!uniqueIdentifier) {
            return message.reply("Utilisation incorrecte. Veuillez spécifier l'ID du giveaway.");
        }

        const giveawayKeys = client.db.all().filter(entry => entry.ID.startsWith(`giveaway`));
        let giveawayData = null;
        let gwkey = null;
        giveawayKeys.forEach(entry => {
            const data = JSON.parse(entry.data);
            if (data.messageid === uniqueIdentifier) {
                giveawayData = data;
                gwkey = entry.ID;
            }
        });

        if (!giveawayData) {
            return message.reply("Ce giveaway n'existe pas.");
        }

        if (!giveawayData.ended) {
            return message.reply("Ce giveaway n'est pas encore terminé. Vous ne pouvez pas le reroll.");
        }

        // Proceed with rerolling
        const newWinner = getRandomWinner(giveawayData); // You need to implement this function
        if (newWinner) {
            giveawayData.winners = [newWinner];
            client.db.set(`${gwkey}`, giveawayData);
            return message.channel.send(`Le giveaway (ID: ${uniqueIdentifier}) a été rerollé. Félicitations au nouveau gagnant: ${newWinner}!`);
        } else {
            return message.channel.send("Aucun gagnant trouvé pour ce giveaway.");
        }
    }
};

// Helper function to get a random winner
function getRandomWinner(giveawayData) {
    const participants = giveawayData.participants; // Assume participants is an array of user IDs
    if (!participants || participants.length === 0) {
        return null;
    }
    const randomIndex = Math.floor(Math.random() * participants.length);
    return participants[randomIndex];
}
