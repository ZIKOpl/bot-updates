const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'hide',
    description: 'Rend un salon textuel invisible pour le rôle @everyone.',
    usage: "hide",
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Vérification des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permissionLevel = client.db.get(`perm_hide.${message.guild.id}`);
            if (permissionLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (permissionLevel === "public") pass = true;   
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        // Détermine le salon à cacher
        const channel = message.mentions.channels.first() || message.channel;


        try {
            // Rend le salon invisible pour @everyone
            await channel.permissionOverwrites.edit(message.guild.id, {
                ViewChannel: false // Utilisez PermissionsBitField.FLAGS.VIEW_CHANNEL pour Discord.js v14+
            });

            const embed = new EmbedBuilder()
                .setTitle('Salon Caché')
                .setColor(client.color)
                .setDescription(`Le salon <#${channel.id}> est maintenant caché.`);

            return message.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            return message.reply("Une erreur s'est produite en essayant de cacher le salon.");
        }
    }
};
