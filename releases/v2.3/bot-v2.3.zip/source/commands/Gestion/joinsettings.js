const ms = require('ms');
const { 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    EmbedBuilder, 
    ChannelSelectMenuBuilder,
    ComponentType 
} = require('discord.js');

module.exports = {
    name: 'joinsettings',
    description: 'Permet de configurer le système de joins du bot et des DM.',
    usage: "joinsettings | joinsettingsdm",
    run: async (client, message, args, commandName) => {
        // Fonction pour vérifier les permissions
        const checkPermissions = () => {
            let pass = false;
            const staff = client.staff;
            if (!staff.includes(message.author.id) && 
                !client.config.buyers.includes(message.author.id) && 
                client.db.get(`owner_${message.author.id}`) !== true) {
                
                const perms = client.db.get(`perm_${commandName}.${message.guild.id}`);
                for (let i = 1; i <= 5; i++) {
                    if (perms === `${i}` && message.member.roles.cache.some(r => client.db.get(`perm${i}.${message.guild.id}`)?.includes(r.id))) pass = true;
                }
                if (perms === "public") pass = true;
            } else {
                pass = true;
            }
            return pass;
        };

        if (!checkPermissions()) {
            return message.channel.send(client.noperm || "Vous n'avez pas la permission d'utiliser cette commande.");
        }

        const originalmsg = await message.channel.send('Chargement en cours...');

        // Fonction pour mettre à jour l'embed principal
        async function updateEmbed() {
            // Utilisation correcte de set/get pour la base de données
            let dbJoin = client.db.get(`joinsettings_${message.guild.id}`);
            if (!dbJoin) {
                client.db.set(`joinsettings_${message.guild.id}`, { channel: null, message: null, status: false });
                dbJoin = { channel: null, message: null, status: false };
            }

            let dbDM = client.db.get(`joinsettingsdm_${message.guild.id}`);
            if (!dbDM) {
                client.db.set(`joinsettingsdm_${message.guild.id}`, { status: false, message: 'Salut {user}, bienvenue sur {guild.name}. Tu a été invité par {inviter} qui possède maintenant {inviter.total}, nous sommes maintenant {guild.count} sur le serveur' });
                dbDM = { status: false, message: 'Salut {user}, bienvenue sur {guild.name}. Tu a été invité par {inviter} qui possède maintenant {inviter.total}, nous sommes maintenant {guild.count} sur le serveur' };
            }

            const statusJoin = dbJoin?.status ? '✅ Activer' : '❌ Désactiver';
            const channel = message.guild.channels.cache.get(dbJoin.channel);
            const channels = channel ? `${channel.name} - ID ${dbJoin.channel || 'Inconnue'}` : 'Inconnue';
            const messages = dbJoin?.message || 'Aucun message';

            const statusDM = dbDM?.status ? '✅ Activer' : '❌ Désactiver';
            const messageDM = dbDM?.message || 'Aucun message';

            const embed = new EmbedBuilder()
                .setTitle('Panel Joins Settings')
                .setColor(client.color)
                .setFooter(client.footer)
                .addFields(
                    { name: 'Statut (Serveur) :', value: `\`\`\`yml\n${statusJoin}\`\`\`` },
                    { name: 'Salon :', value: `\`\`\`yml\n${channels}\`\`\`` },
                    { name: 'Message (Serveur) :', value: `\`\`\`yml\n${messages}\`\`\`` },
                    { name: 'Statut (DM) :', value: `\`\`\`yml\n${statusDM}\`\`\`` },
                    { name: 'Message (DM) :', value: `\`\`\`yml\n${messageDM}\`\`\`` }
                );

            const select = new StringSelectMenuBuilder()
                .setCustomId(`joins_setup_${message.id}`)
                .setMaxValues(1)
                .addOptions([
                    { label: 'Status Joins', value: `status_joins_${message.id}` },
                    { label: 'Salon Joins', value: `salon_joins_${message.id}` },
                    { label: 'Message Joins', value: `message_joins_${message.id}` },
                    { label: 'Status DM', value: `status_dm_${message.id}` },
                    { label: 'Message DM', value: `message_dm_${message.id}` }
                ]);

            const row = new ActionRowBuilder().addComponents(select);
            await originalmsg.edit({ content: null, components: [row], embeds: [embed] });
        }

        await updateEmbed();

        // Gestionnaire de sélection des composants
        const collector = message.channel.createMessageComponentCollector({ 
            filter: i => i.user.id === message.author.id, 
            componentType: ComponentType.StringSelect, 
            time: ms("2m") 
        });

        collector.on("collect", async (i) => {
            const dbJoin = client.db.get(`joinsettings_${message.guild.id}`);
            const dbDM = client.db.get(`joinsettingsdm_${message.guild.id}`);
            
            // Gestion des paramètres "joins"
            if (i.values[0] === `status_joins_${message.id}`) {
                const missingOptions = [];
                if (!dbJoin.channel) missingOptions.push("Le channel");
                if (!dbJoin.message) missingOptions.push("le message");

                if (missingOptions.length === 0) {
                    dbJoin.status = !dbJoin.status;
                    client.db.set(`joinsettings_${message.guild.id}`, dbJoin);
                    const status = dbJoin.status ? 'Le joinsettings a été activé avec succès' : 'Le joinsettings a été désactivé avec succès';
                    await i.deferUpdate();
                    await updateEmbed();
                } else {
                    i.reply({ content: `Le paramétrage du joinsettings n'est pas fini. Voici ce qu'il reste à configurer :\n${missingOptions.map(opt => `- \`${opt}\``).join('\n')}`, ephemeral: true });
                }
            } else if (i.values[0] === `salon_joins_${message.id}`) {
                const salonRow = new ActionRowBuilder().addComponents(
                    new ChannelSelectMenuBuilder().setChannelTypes(0).setMinValues(1).setCustomId(`joinsettings_setup_salon_${message.id}`)
                );
                await i.reply({ content: 'Merci de choisir votre channel !', components: [salonRow], ephemeral: true });
            } else if (i.values[0] === `message_joins_${message.id}`) {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply({ content: 'Quel sera le message de bienvenue ?', ephemeral: true });

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                    const msg = collected.first().content.trim();
                    dbJoin.message = msg;
                    client.db.set(`joinsettings_${message.guild.id}`, dbJoin);
                    await updateEmbed();
                    await sentMessage.delete();
                    await collected.first().delete();
                } catch (error) {
                    await sentMessage.delete();
                    console.error('Error collecting message or message collection timed out:', error);
                    message.channel.send("Temps de réponse expiré ou une erreur s'est produite.");
                }
            }

            // Gestion des paramètres "DM"
            else if (i.values[0] === `status_dm_${message.id}`) {
                dbDM.status = !dbDM.status;
                client.db.set(`joinsettingsdm_${message.guild.id}`, dbDM);
                const status = dbDM.status ? 'Le DM joinsettings a été activé avec succès' : 'Le DM joinsettings a été désactivé avec succès';
                await i.deferUpdate();
                await updateEmbed();
            } else if (i.values[0] === `message_dm_${message.id}`) {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply({ content: 'Quel sera le message de bienvenue DM ?', ephemeral: true });

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                    const msg = collected.first().content.trim();
                    dbDM.message = msg;
                    client.db.set(`joinsettingsdm_${message.guild.id}`, dbDM);
                    await updateEmbed();
                    await sentMessage.delete();
                    await collected.first().delete();
                } catch (error) {
                    await sentMessage.delete();
                    console.error('Error collecting message or message collection timed out:', error);
                    message.channel.send("Temps de réponse expiré ou une erreur s'est produite.");
                }
            }
        });

        // Gestion de l'interaction pour la sélection des salons
        client.on('interactionCreate', async (i) => {
            if (i.user.id === message.author.id && i.customId === `joinsettings_setup_salon_${message.id}`) {
                const dbJoin = client.db.get(`joinsettings_${message.guild.id}`);
                const salon = i.values[0];
                dbJoin.channel = salon;
                client.db.set(`joinsettings_${message.guild.id}`, dbJoin);
                await updateEmbed();

                await i.deferUpdate(); // Marque l'interaction comme traitée
            }
        });
    }
};
