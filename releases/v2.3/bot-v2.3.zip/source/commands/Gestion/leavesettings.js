const ms = require('ms');
const { 
    Client, 
    EmbedBuilder, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    ChannelSelectMenuBuilder, 
    ComponentType 
} = require('discord.js');

module.exports = {
    name: 'leavesettings',
    description: 'Permet de configurer le système de leave du bot',
    usage: "leavesettings",
    run: async (client, message, args, commandName) => {
        let isAuthorized = false;
        const { author, member, guild, channel } = message;
        const staff = client.staff;
        const db = client.db;
        const guildId = guild.id;

        if (staff.includes(author.id) || client.config.buyers.includes(author.id) || db.get(`owner_${author.id}`) === true) {
            isAuthorized = true;
        } else {
            const permLevel = db.get(`perm_${commandName}.${guildId}`);
            if (permLevel && permLevel !== "public") {
                const roleKey = `perm${permLevel}.${guildId}`;
                if (member.roles.cache.some(role => db.get(roleKey)?.includes(role.id))) {
                    isAuthorized = true;
                }
            } else if (permLevel === "public") {
                isAuthorized = true;
            }
        }

        if (!isAuthorized) {
            return client.noperm ? channel.send(client.noperm) : null;
        }

        const settings = db.get(`leavesettings_${guildId}`) || {
            channel: null,
            message: null,
            status: false,
        };

        const originalMsg = await channel.send('Chargement en cours...');

        const updateEmbed = async () => {
            const statusText = settings.status ? '✅ Activé' : '❌ Désactivé';
            const channelObj = guild.channels.cache.get(settings.channel);
            const channelName = channelObj ? channelObj.name : "Aucun channel";
            const channelId = settings.channel || "Aucun ID";
            const leaveMessage = settings.message || "Aucun message";

            const embed = new EmbedBuilder()
                .setTitle('Panel Leave Settings')
                .setColor(client.color)
                .setFooter(client.footer)
                .addFields(
                    { name: "Statut :", value: `\`\`\`yml\n${statusText}\`\`\`` },
                    { name: "Salon :", value: `\`\`\`yml\n${channelName} - ID ${channelId}\`\`\`` },
                    { name: "Message :", value: `\`\`\`yml\n${leaveMessage}\`\`\`` }
                );

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId(`leave_setup_${message.id}`)
                .setMaxValues(1)
                .addOptions([
                    { label: 'Statut', value: `status_${message.id}` },
                    { label: 'Salon', value: `salon_${message.id}` },
                    { label: 'Message', value: `message_${message.id}` },
                ]);

            const actionRow = new ActionRowBuilder().addComponents(selectMenu);

            await originalMsg.edit({ content: null, components: [actionRow], embeds: [embed] });
        };

        await updateEmbed();

        const collector = channel.createMessageComponentCollector({ 
            filter: i => i.user.id === author.id, 
            componentType: ComponentType.StringSelect || ComponentType.Button, 
            time: ms('2m') 
        });

        collector.on('collect', async (interaction) => {
            const [action, id] = interaction.values[0].split('_');
            
            if (action === 'status') {
                if (!settings.channel || !settings.message) {
                    const missingOptions = [];
                    if (!settings.channel) missingOptions.push('Le channel');
                    if (!settings.message) missingOptions.push('Le message');
                    
                    return interaction.reply({ 
                        content: `Le paramétrage du leave settings n'est pas fini. Voici ce qu'il reste à configurer :\n${missingOptions.join('\n')}`, 
                        ephemeral: true 
                    });
                }

                settings.status = !settings.status;
                db.set(`leavesettings_${guildId}`, settings);
                await interaction.reply({ content: settings.status ? 'Le leave settings a été activé avec succès' : 'Le leave settings a été désactivé avec succès', ephemeral: true });
                await updateEmbed();
                
            } else if (action === 'salon') {
                const channelMenu = new ChannelSelectMenuBuilder()
                    .setChannelTypes(0)
                    .setMinValues(1)
                    .setCustomId(`leave_setup_salon_${id}`);
                
                const salonRow = new ActionRowBuilder().addComponents(channelMenu);
                await interaction.reply({ content: 'Merci de choisir votre channel !', components: [salonRow], ephemeral: true });
                
            } else if (action === 'message') {
                await interaction.reply({ content: 'Quel sera le message de leave ? (Variable `${client.prefix}variable`)', ephemeral: true });

                const filter = response => response.author.id === author.id;
                try {
                    const collected = await channel.awaitMessages({ filter, max: 1, time: ms('1m'), errors: ['time'] });
                    const msgContent = collected.first().content.trim();

                    settings.message = msgContent;
                    db.set(`leavesettings_${guildId}`, settings);

                    await updateEmbed();
                    collected.first().delete();
                } catch (error) {
                    console.error(error);
                    channel.send("Temps de réponse expiré ou une erreur s'est produite.");
                }
            }
        });

        client.on('interactionCreate', async interaction => {
            if (interaction.user.id === author.id && interaction.customId === `leave_setup_salon_${message.id}`) {
                const selectedChannel = interaction.values[0];
                settings.channel = selectedChannel;
                db.set(`leavesettings_${guildId}`, settings);

                await updateEmbed();
                interaction.message.delete();
            }
        });
    }
};
