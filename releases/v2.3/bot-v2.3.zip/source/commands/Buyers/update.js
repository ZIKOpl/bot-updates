const { exec } = require("child_process");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "update",
  description: "Met à jour le bot vers la dernière version disponible",

  run: async (client, message) => {
    const API_URL = "https://bot-updates-zwi5.onrender.com/api/version";
    const localVersion = client.version || "v1";

    const embed = new EmbedBuilder()
      .setTitle("🚀 Mise à jour du bot")
      .setColor("#5865F2")
      .setFooter({ text: "Système de mise à jour automatique" })
      .setTimestamp();

    try {
      // 1️⃣ Vérification de la version
      embed.setDescription("🔍 Vérification de la dernière version...");
      const msg = await msg.edit({ embeds: [embed] });

      const response = await axios.get(API_URL);
      const remoteVersion = response.data.version;
      const download = response.data.download || response.data.url;

      if (!remoteVersion || !download) {
        embed
          .setColor("#FF0000")
          .setDescription("❌ Impossible de vérifier la version sur le serveur distant.");
        return msg.edit({ embeds: [embed] });
      }

      if (remoteVersion === localVersion) {
        embed
          .setColor("#00FF00")
          .setDescription(`✅ Ton bot est déjà à jour (**${localVersion}**) !`);
        return msg.edit({ embeds: [embed] });
      }

      // 2️⃣ Téléchargement avec progression
      const zipPath = path.join(process.cwd(), "update.zip");
      embed
        .setColor("#ffaa00")
        .setDescription(
          `📦 Nouvelle version disponible : **${remoteVersion}**\n\nTéléchargement en cours... (0 %)`
        );
      await msg.edit({ embeds: [embed] });

      const writer = fs.createWriteStream(zipPath);
      const { data, headers } = await axios.get(download, { responseType: "stream" });
      const totalLength = parseInt(headers["content-length"], 10);

      let downloaded = 0;
      let progressStep = 0;

      data.on("data", (chunk) => {
        downloaded += chunk.length;
        const progress = Math.floor((downloaded / totalLength) * 100);

        // Update tous les 20 %
        if (progress >= progressStep * 20) {
          embed.setDescription(
            `📦 Téléchargement en cours... **${Math.min(progress, 100)} %**`
          );
          msg.edit({ embeds: [embed] });
          progressStep++;
        }
      });

      await new Promise((resolve, reject) => {
        data.pipe(writer);
        writer.on("finish", resolve);
        writer.on("error", reject);
      });

      // 3️⃣ Extraction
      embed.setDescription("🧩 Extraction des fichiers...");
      await msg.edit({ embeds: [embed] });

      const zip = new AdmZip(zipPath);
      zip.extractAllTo(process.cwd(), true);
      fs.unlinkSync(zipPath);

      // 4️⃣ Mise à jour terminée
      embed
        .setColor("#00FF00")
        .setDescription(`✅ Mise à jour terminée vers **${remoteVersion}**.\n🔄 Redémarrage en cours...`);
      await msg.edit({ embeds: [embed] });

      // 5️⃣ Redémarrage
      if (process.platform === "win32") {
        exec(`node index.js`, () => process.exit());
      } else {
        exec(`pm2 restart ${client.user.id}`);
      }
    } catch (err) {
      console.error(err);
      embed
        .setColor("#FF0000")
        .setDescription("❌ Erreur pendant la mise à jour.\nVérifie l’API ou le lien du zip.");
      msg.edit({ embeds: [embed] });
    }
  },
};
