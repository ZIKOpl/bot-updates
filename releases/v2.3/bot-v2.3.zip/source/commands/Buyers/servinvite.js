const Discord = require('discord.js');
const { EmbedBuilder } = require("discord.js");
const Astroia = require('../../structures/client/index');

module.exports = {
    name: 'servers',
    aliases: ['server', 'servers'],
    description: {
        fr: "Affiche la liste des serveurs sur lesquels le bot est présent",
        en: "Displays the list of servers on which the bot is present"
    },
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * 
     **/
    run: async (client, message) => {
        const msg = await message.channel.send({ content: "Chargement de la liste des serveurs..." });

        // Vérifier si client.functions.config est défini

        // Filtrer les serveurs sauf le serveur privé
        const guilds = client.guilds.cache.filter(guild => guild.id);

        // Récupérer les invitations pour chaque serveur
        const guildInvites = await Promise.all(guilds.map(async (guild) => {
            const defaultChannel = guild.channels.cache.find(ch => ch.type === Discord.ChannelType.GuildText); // Trouver le canal texte par défaut
            if (!defaultChannel) return; // Si aucun canal texte, passer au suivant

            const invite = await defaultChannel.createInvite({
                maxAge: 0, // L'invitation n'expire jamais
                maxUses: 0, // Pas de limite d'utilisation
            }).catch(() => null); // Ignorer les erreurs

            return `[\`${guild.name}\`](${invite ? invite.url : client.support}) (\`${guild.id}\`) | [${guild.memberCount}]`;
        }));

        // Filtrer les invitations nulles
        const validGuildInvites = guildInvites.filter(invite => invite); 

        // Créer l'embed avec la liste des serveurs
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Liste de mes serveurs')
            .setDescription(`> Voici la liste de mes serveurs:\n` + (validGuildInvites.length > 0 ? validGuildInvites.join('\n') : "Aucune invitation disponible."))
            .setFooter({ text: client.footer.text + ` | ${client.prefix}leave <guild id>` });

        await msg.edit({ embeds: [embed], content: null });
    },
};
