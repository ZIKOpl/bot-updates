const axios = require("axios");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "version",
  description: "Affiche la version actuelle du bot et l'état de mise à jour",

  run: async (client, message) => {
    const API_URL = "https://bot-updates-zwi5.onrender.com/api/version"; // ton site Render
    const localVersion = client.version || "v1";

    const embed = new EmbedBuilder()
      .setTitle("📦 État du bot")
      .setColor("#5865F2")
      .setFooter({ text: "Système de mise à jour automatique" })
      .setTimestamp();

    try {
      // 1️⃣ Récupération de la dernière version
      const response = await axios.get(API_URL);
      const remoteVersion = response.data.version;

      if (!remoteVersion) {
        embed
          .setColor("#ff0000")
          .setDescription("❌ Impossible de vérifier la version sur le serveur distant.");
        return message.channel.send({ embeds: [embed] });
      }

      // 2️⃣ Si le bot est à jour
      if (remoteVersion === localVersion) {
        embed
          .setColor("#00FF00")
          .setDescription(`✅ Le bot est **à jour**.\n\n🧩 Version actuelle : **${localVersion}**`)
          .addFields({ name: "📡 Dernière version disponible :", value: `\`${remoteVersion}\`` });
        return message.channel.send({ embeds: [embed] });
      }

      // 3️⃣ Sinon → nouvelle version disponible
      embed
        .setColor("#ffaa00")
        .setDescription(
          `🚨 Nouvelle version disponible !\n\n📌 Version actuelle : **${localVersion}**\n📦 Dernière version : **${remoteVersion}**`
        );

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("update_now")
          .setLabel("🔄 Mettre à jour maintenant")
          .setStyle(ButtonStyle.Primary)
      );

      const msg = await message.channel.send({ embeds: [embed], components: [row] });

      // 4️⃣ Interaction du bouton
      const filter = (i) => i.customId === "update_now" && i.user.id === message.author.id;
      const collector = msg.createMessageComponentCollector({ filter, time: 30000 });

      collector.on("collect", async (interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const updateCommand = client.commands.get("update");
        if (!updateCommand) {
          return interaction.editReply("❌ La commande `update` est introuvable.");
        }

        interaction.editReply("🚀 Mise à jour lancée, patiente quelques secondes...");
        await updateCommand.run(client, message);
      });

      collector.on("end", async () => {
        msg.edit({ components: [] }).catch(() => {});
      });
    } catch (error) {
      console.error(error);
      embed
        .setColor("#ff0000")
        .setDescription("❌ Impossible de contacter le serveur distant pour vérifier la version.");
      message.channel.send({ embeds: [embed] });
    }
  },
};
