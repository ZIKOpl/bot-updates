const { EmbedBuilder } = require('discord.js');
const Astroia = require('../../structures/client/index.js');

module.exports = {
    name: 'blacklist',
    usage: "bl <mention/id> [raison] Ajouter un utilisateur dans la blacklist",
    aliases: ['bl'],
    description: "Affiche la liste des utilisateurs blacklistés",
  
    /**
     * 
     * @param {Astroia} client 
     * @param {*} message 
     * @param {*} args 
     * @returns 
     */
    run: async (client, message, args) => {
        // Vérification des permissions
        let pass = false;
        let staff = client.staff;

        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            
            const commandName = 'blacklist'; // Nom de la commande

            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && 
                message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && 
                message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && 
                message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && 
                message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && 
                message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(await client.lang(`perm`));
        }

        // Récupération de la liste des utilisateurs blacklistés
        const blacklist = await client.db.get(`blacklist`) || [];

        if (args[0] === 'clear') {
            await client.db.delete(`blacklist`);
            return message.reply(`La liste des utilisateurs blacklistés a été effacée.`);
        }

        let user = message.mentions.users.first();
        let memberId = args[0];

        if (!user && memberId) {
            try {
                user = await client.users.fetch(memberId);
            } catch (error) {
                console.error(error);
            }
        }
        
        if (!user && !memberId) {
            const blacklistEmbed = new EmbedBuilder()
                .setTitle("Blacklist")
                .setDescription(blacklist.map(entry => `<@${entry.userId}>`).join('\n') || "None")
                .setFooter(client.footer)
                .setColor(client.color);
    
            return message.channel.send({ embeds: [blacklistEmbed] });
        }

        if (blacklist.some(entry => entry.userId === (memberId || user.id))) {
           return message.reply({
            content: `${user.username} est déjà dans la blacklist`
           });
        }

        const reason = args.slice(1).join(' ') || null;
        const owner = await client.db.get(`owner`) || [];
        if (owner.includes(user.id) || client.config.buyers.includes(user.id)) {
            return message.channel.send(`Je ne peux pas blacklist un owner ou buyer bot`);
        }

        const member = user;
        const messages = await message.channel.send(`Début de la blacklist pour ${member.username}...`);
        let bansSuccess = 0;
        let bansFailed = 0;

        await Promise.all(client.guilds.cache.map(async (guild) => {
            try {
                await guild.members.ban(member.id, { reason: `BLACKLIST | by ${message.author.tag}` });
                bansSuccess++;
                await new Promise(resolve => setTimeout(resolve, 800)); 
            } catch (error) {
                console.error(`Impossible de bannir ${member.username} de ${guild.name}`);
                bansFailed++;
            }
        }));

        messages.edit(`${messages.content}\n${member.username} a été blacklisté de \`${bansSuccess}\` serveurs avec succès et a échoué sur \`${bansFailed}\` serveurs.\nRaison: \`${reason || "Aucune raison spécifiée"}\``);
        
        blacklist.push({ userId: member.id, raison: reason, date: Date.now(), author: message.author.id });
        await client.db.set(`blacklist`, blacklist);
    }
};
