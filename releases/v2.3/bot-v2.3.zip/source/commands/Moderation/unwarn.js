const { EmbedBuilder } = require('discord.js');
const Astroia = require("../../structures/client");

module.exports = {
    name: "unwarn",
    description: "Permet de retirer un avertissement d'un membre du serveur.",
    usages: "unwarn <@user/ID> <code> Retire un avertissement d'un membre du serveur.",
    /**
     * @param {Astroia} client
     * @param {Astroia} message
     * @param {Astroia} args
     * @returns
     */
    run: async (client, message, args) => {
        //console.log("Command 'unwarn' initiated.");

        try {
            // Vérification des permissions
            let pass = false;
            let staff = client.staff;

            if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
                console.log("Checking permissions.");
                if (client.db.get(`perm_warn.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "public") pass = true;
            } else {
                pass = true;
            }

            if (!pass) {
                if (client.noperm && client.noperm.trim() !== '') {
                    return message.channel.send(client.noperm);
                } else {
                    return;
                }
            }

            // Vérification des arguments
            if (args.length < 2) {
                return message.channel.send("Utilisation incorrecte : unwarn <membre> <code>");
            }

            // Récupérer l'utilisateur
            let user = message.mentions.users.first();
            let memberId = args[0];

            if (!user && memberId) {
                user = await client.users.fetch(memberId).catch(() => null);
            }

            if (!user) {
                return message.channel.send("Utilisateur non trouvé. Utilisation correcte : unwarn <@user/ID> <code>");
            }

            let code = args[1];

            // Récupération des sanctions
            let db = await client.db.get(`sanction_${message.guild.id}`) || [];

            // Recherche de l'avertissement à retirer
            const index = db.findIndex(warn => warn.userId === user.id && warn.code === code);

            if (index === -1) {
                return message.channel.send(`Aucun avertissement trouvé pour l'utilisateur avec le code \`${code}\`.`);
            }

            // Retirer l'avertissement
            db.splice(index, 1);

            await client.db.set(`sanction_${message.guild.id}`, db);

            // Envoi de l'embed de confirmation
            const successEmbed = new EmbedBuilder()
                .setTitle('Avertissement Retiré')
                .setDescription(`L'avertissement de <@${user.id}> avec le code \`${code}\` a été retiré.`)
                .setColor(client.color)
                .setFooter(client.footer)
                .setTimestamp();

            await message.channel.send({ embeds: [successEmbed] });

        } catch (err) {
            console.error('Erreur:', err);
            message.reply("Une erreur vient de se produire...");
        }
    }
};
