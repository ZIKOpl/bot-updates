const Discord = require('discord.js');

module.exports = {
    name: "counter",
    description: "Crée un compteur.",
    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        const counters = await client.db.get(`counters_${message.guild.id}`) || []

        const menu = new Discord.StringSelectMenuBuilder()
            .setCustomId('selectmenu')
            .setMaxValues(1)
            .setMinValues(1)
            .addOptions([
            {
                label: "Actualiser le selecteur",
                value: "selectRefresh",
                emoji: "🔄"
            },
            {
                label: "Ajouter une option...",
                value: "create",
                emoji: "✏️"
            },
        ])
        
        const embed = new Discord.EmbedBuilder()
            .setTitle("Paramètres des counters")
            .setDescription('**Les données sont rafraîchies toutes les 2 minutes**\n *Pour voir la liste des variables disponibles faites "+variables"*')
            .setColor(client.color)
            .setFooter(client.footer)        

        const data = []
        for (const counter of counters){
            const channel = message.guild.channels.cache.get(counter.id)
            if (!channel || data.includes(channel.id)) continue;

            data.push(channel.id)
            embed.addFields({ name: `${channel.name}`, value: `${counter.text}` })
            menu.addOptions([{ label: channel.name, value: channel.id, emoji: "🔊" }])
        }

        const msg = await message.channel.send({ embeds: [ embed ], components: [ new Discord.ActionRowBuilder().addComponents(menu) ] })
        const collector = await msg.createMessageComponentCollector({ time: 1000 * 60 * 10 });
        
        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) return interaction.reply({content: "Vous ne pouvez pas utiliser ce menu", ephemeral: true});
            
            if (interaction.values[0] == "selectRefresh") return interaction.deferUpdate().catch(() => false);
            if (interaction.values[0] == "create") {
                const titre = new Discord.ActionRowBuilder().addComponents(
                    new Discord.TextInputBuilder()
                        .setCustomId('channel')
                        .setLabel('ID du salon')
                        .setPlaceholder('Exemple: 1295106538448359446')
                        .setStyle(1)
                        .setRequired(true)
                )

                const description = new Discord.ActionRowBuilder().addComponents(
                    new Discord.TextInputBuilder()
                        .setCustomId('texte')
                        .setLabel('Texte')
                        .setPlaceholder('Exemple: ⭐・Membres: [server.memberCount]')
                        .setStyle(1)
                        .setRequired(true)
                )

                
                const modal = new Discord.ModalBuilder()
                    .setCustomId('counter')
                    .setTitle('Counter Builder')
                    .setComponents([titre, description])
            
                interaction.showModal(modal)

                const reponse = await interaction.awaitModalSubmit({ time: 1000 * 60 * 5}).catch(() => false);
                const channel = reponse.fields.getTextInputValue("channel");
                const texte   = reponse.fields.getTextInputValue("texte");
                
                const channelData = message.guild.channels.cache.get(channel)
                if (!channelData) return reponse.reply({ content: "Salon introuvable", ephemeral: true })
                if (counters.find(c => c.id == channelData.id)) return reponse.reply({ contenet: `Un counter existe déjà pour le salon ${channelData}`, ephemeral: true })

                client.db.push(`counters_${message.guild.id}`, { id: channelData.id, text: texte })
                reponse.reply({ content: "Counter créé avec succès", ephemeral: true })
            }
            else {
                let counters = await client.db.get(`counters_${message.guild.id}`) || [];
                client.db.set(`counters_${message.guild.id}`, counters.filter(c => c.id !== interaction.values[0]))
                counters = await client.db.get(`counters_${message.guild.id}`) || [];
                
                const menu = new Discord.StringSelectMenuBuilder()
                    .setCustomId('selectmenu')
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions([
                    {
                        label: "Actualiser le selecteur",
                        value: "selectRefresh",
                        emoji: "🔄"
                    },
                    {
                        label: "Ajouter une option...",
                        value: "create",
                        emoji: "✏️"
                    },
                ])
                
                const embed = new Discord.EmbedBuilder()
                    .setTitle("Paramètres des counters")
                    .setDescription('**Les données sont rafraîchies toutes les 2 minutes**\n *Pour voir la liste des variables disponibles faites "+variables"*')
                    .setColor(client.color)
                    .setFooter(client.footer)
                const data = []
                for (const counter of counters){
                    const channel = message.guild.channels.cache.get(counter.id)
                    if (!channel || data.includes(channel.id)) continue;

                    data.push(channel.id)        
                    embed.addFields({ name: `${channel.name}`, value: `${counter.text}` })
                    menu.addOptions([{ label: channel.name, value: channel.id, emoji: "🔊" }])
                }

                interaction.update({ embeds: [ embed ], components: [ new Discord.ActionRowBuilder().addComponents(menu) ] });
            }
        })
    }
}