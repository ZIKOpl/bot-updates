const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, ComponentType } = require('discord.js');

module.exports = {
    name: 'reactmot',
    description: 'Ajouter ou retirer des mots avec des émojis.',

    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;

        // Système de permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        const getWordList = (guildId) => {
            return client.db.get(`reactmot_words.${guildId}`) || [];
        };

        // Variable pour stocker le message envoyé
        let messageSent;

        const updateEmbed = async () => {
            const words = getWordList(message.guild.id);
            const embed = new EmbedBuilder()
                .setTitle('Gestion des mots avec émojis')
                .setDescription('Choisissez une option pour ajouter ou retirer un mot.')
                .setColor(client.color)
                .addFields(
                    { name: 'Mots et Émojis', value: words.length ? words.map(({ word, emoji }) => `${emoji} ${word}`).join('\n') : 'Aucun mot ajouté.' }
                );

            // Si le message est déjà envoyé, on l'édite, sinon on l'envoie
            if (messageSent) {
                await messageSent.edit({ embeds: [embed], components: [row] });
            } else {
                messageSent = await message.channel.send({ embeds: [embed], components: [row] });
            }
        };

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('add_word')
                .setLabel('Ajouter un mot')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('remove_word')
                .setLabel('Retirer un mot')
                .setStyle(ButtonStyle.Danger)
        );

        // Envoie initial de l'embed
        await updateEmbed();

        const collector = messageSent.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'add_word') {
                // Ouvrir le modal pour ajouter un mot
                const modal = new ModalBuilder()
                    .setCustomId('add_word_modal')
                    .setTitle('Ajouter un mot');

                const wordInput = new TextInputBuilder()
                    .setCustomId('wordInput')
                    .setLabel('Mot à ajouter')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const emojiInput = new TextInputBuilder()
                    .setCustomId('emojiInput')
                    .setLabel('Émoji à ajouter')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setPlaceholder('Ex: 😀');

                const wordRow = new ActionRowBuilder().addComponents(wordInput);
                const emojiRow = new ActionRowBuilder().addComponents(emojiInput);
                modal.addComponents(wordRow, emojiRow);

                try {
                    await interaction.showModal(modal);
                } catch (error) {
                    console.error(`Erreur lors de l'ouverture du modal: ${error}`);
                }
            }

            if (interaction.customId === 'remove_word') {
                // Ouvrir le modal pour retirer un mot
                const modal = new ModalBuilder()
                    .setCustomId('remove_word_modal')
                    .setTitle('Retirer un mot');

                const wordInput = new TextInputBuilder()
                    .setCustomId('removeWordInput')
                    .setLabel('Mot à retirer')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const wordRow = new ActionRowBuilder().addComponents(wordInput);
                modal.addComponents(wordRow);

                try {
                    await interaction.showModal(modal);
                } catch (error) {
                    console.error(`Erreur lors de l'ouverture du modal: ${error}`);
                }
            }
        });

        // Gestion des soumissions de modal
        client.on('interactionCreate', async (modalInteraction) => {
            if (!modalInteraction.isModalSubmit()) return;

            if (modalInteraction.customId === 'add_word_modal') {
                const word = modalInteraction.fields.getTextInputValue('wordInput');
                const emoji = modalInteraction.fields.getTextInputValue('emojiInput');

                const currentWords = getWordList(modalInteraction.guild.id);
                currentWords.push({ word, emoji });
                client.db.set(`reactmot_words.${modalInteraction.guild.id}`, currentWords);

                await modalInteraction.reply({ content: `Le mot **${word}** avec l'émoji ${emoji} a été ajouté.`, ephemeral: true });
                await updateEmbed(); // Mise à jour de l'embed après ajout
            }

            if (modalInteraction.customId === 'remove_word_modal') {
                const wordToRemove = modalInteraction.fields.getTextInputValue('removeWordInput');

                let currentWords = getWordList(modalInteraction.guild.id);
                currentWords = currentWords.filter(item => item.word.toLowerCase() !== wordToRemove.toLowerCase());
                client.db.set(`reactmot_words.${modalInteraction.guild.id}`, currentWords);

                await modalInteraction.reply({ content: `Le mot **${wordToRemove}** a été retiré.`, ephemeral: true });
                await updateEmbed(); // Mise à jour de l'embed après suppression
            }
        });

        collector.on('end', () => {
            if (messageSent && messageSent.editable) {
                messageSent.edit({ components: [] });
            }
        });
    }
};
