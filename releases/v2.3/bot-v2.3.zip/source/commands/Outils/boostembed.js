const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ChannelType, ComponentType } = require('discord.js');

module.exports = {
    name: 'boostembed',
    description: 'Configurer un message boost avec options activé/désactivé et choisir un salon pour l\'envoi.',

    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;

        // Système de permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Récupérer les informations actuelles dans la base de données
        const boostStatus = client.db.get(`boost_status_${message.guild.id}`) || 'Désactivé';
        const boostChannelId = client.db.get(`boost_channel_${message.guild.id}`) || 'Non défini';
        const boostChannelMention = boostChannelId !== 'Non défini' ? `<#${boostChannelId}>` : 'Non défini';

        // Création de l'embed principal
        const embed = new EmbedBuilder()
            .setTitle('Configuration du Boost')
            .setDescription('Sélectionnez une option pour activer ou désactiver les notifications de boost et choisissez un salon où les envoyer.')
            .setColor(client.color)
            .setFooter(client.footer)
            .addFields(
                { name: 'Statut de système de Boost', value: boostStatus, inline: true },
                { name: 'Salon de notification', value: boostChannelMention, inline: true }
            );

        // Création du sélecteur d'activation/désactivation
        const statusSelect = new StringSelectMenuBuilder()
            .setCustomId('boost_status')
            .setPlaceholder('Choisir un statut')
            .addOptions(
                {
                    label: 'Activé',
                    value: 'enabled',
                    description: 'Activer les notifications de boost.',
                },
                {
                    label: 'Désactivé',
                    value: 'disabled',
                    description: 'Désactiver les notifications de boost.',
                }
            );

        const actionRow = new ActionRowBuilder().addComponents(statusSelect);

        // Envoi initial du message avec l'embed et le sélecteur
        const messageSent = await message.channel.send({
            embeds: [embed],
            components: [actionRow],
        });

        const collector = messageSent.createMessageComponentCollector({
            componentType: ComponentType.StringSelect,
            time: 60000, // Collecteur actif pour 60 secondes
        });

        collector.on('collect', async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "Vous ne pouvez pas interagir avec cette commande.", ephemeral: true });
            }

            if (interaction.customId === 'boost_status') {
                const newStatus = interaction.values[0] === 'enabled' ? 'Activé' : 'Désactivé';
                embed.data.fields[0].value = newStatus;
                await messageSent.edit({ embeds: [embed] });
                await interaction.reply({ content: `Le boost est maintenant **${newStatus}**.`, ephemeral: true });

                // Sauvegarder le statut dans la base de données
                client.db.set(`boost_status_${message.guild.id}`, newStatus);

                if (interaction.values[0] === 'enabled') {
                    await interaction.followUp({
                        content: 'Veuillez mentionner le salon où vous souhaitez recevoir les notifications de boost.',
                        ephemeral: true
                    });

                    const filter = m => m.author.id === interaction.user.id;
                    const channelCollector = message.channel.createMessageCollector({ filter, time: 30000 });

                    channelCollector.on('collect', async (msg) => {
                        // Vérifie si le message contient une mention
                        const mentionedChannel = msg.mentions.channels.first();
                        if (!mentionedChannel) {
                            return msg.reply("Veuillez mentionner un salon valide.");
                        }

                        embed.data.fields[1].value = `<#${mentionedChannel.id}>`;
                        await messageSent.edit({ embeds: [embed] });
                        await msg.reply({ content: `Le salon de notification a été défini sur **${mentionedChannel.name}**.`, ephemeral: true });

                        // Sauvegarder le salon dans la base de données
                        client.db.set(`boost_channel_${message.guild.id}`, mentionedChannel.id);

                        channelCollector.stop();
                    });

                    channelCollector.on('end', () => {
                        if (channelCollector.collected.size === 0) {
                            interaction.followUp({ content: 'Temps écoulé pour choisir un salon.', ephemeral: true });
                        }
                    });
                }
            }
        });

        collector.on('end', () => {
            if (messageSent && messageSent.editable) {
                messageSent.edit({ components: [] });
            }
        });
    },
};
