const Discord = require('discord.js');

module.exports = {
    name: 'puissance4',
    description: "Commence une partie de Puissance 4.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        const staff = client.staff;

        // Vérification des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permLevel = client.db.get(`perm_puissance4.${message.guild.id}`);
            if (permLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
        } else {
            pass = true;
        }

        // Si l'utilisateur n'a pas les permissions
        if (!pass) {
            return message.reply(client.noperm || 'Vous n\'avez pas la permission d\'exécuter cette commande.');
        }

        // Paramètres de la partie
        const ROWS = 6;
        const COLUMNS = 7;
        const board = Array(ROWS).fill(null).map(() => Array(COLUMNS).fill('⚪')); // Création du plateau vide
        let currentPlayer = message.author; // Joueur initial
        let nextPlayer; // Le prochain joueur

        // Fonction pour afficher le plateau de jeu
        const printBoard = () => {
            return board.map(row => row.join(' ')).join('\n');
        };

        // Fonction pour vérifier si un joueur a gagné
        const checkWin = (board, playerDisc) => {
            // Vérification horizontale, verticale, diagonale
            const checkDirection = (row, col, rowDir, colDir) => {
                let count = 0;
                for (let i = 0; i < 4; i++) {
                    const r = row + i * rowDir;
                    const c = col + i * colDir;
                    if (r >= 0 && r < ROWS && c >= 0 && c < COLUMNS && board[r][c] === playerDisc) {
                        count++;
                    } else {
                        break;
                    }
                }
                return count === 4;
            };

            for (let row = 0; row < ROWS; row++) {
                for (let col = 0; col < COLUMNS; col++) {
                    if (board[row][col] === playerDisc) {
                        if (checkDirection(row, col, 0, 1) || // Horizontal
                            checkDirection(row, col, 1, 0) || // Vertical
                            checkDirection(row, col, 1, 1) || // Diagonale bas-droite
                            checkDirection(row, col, 1, -1)) { // Diagonale bas-gauche
                            return true;
                        }
                    }
                }
            }
            return false;
        };

        // Fonction pour faire jouer un joueur
        const playTurn = async (player, message) => {
            const filter = m => m.author.id === player.id && !isNaN(m.content) && m.content >= 1 && m.content <= COLUMNS;
            message.channel.send(`${player}, c'est ton tour ! Choisis une colonne (1-${COLUMNS}):\n${printBoard()}`);

            try {
                const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
                const col = parseInt(collected.first().content) - 1;

                // Placement du jeton
                for (let row = ROWS - 1; row >= 0; row--) {
                    if (board[row][col] === '⚪') {
                        board[row][col] = player === message.author ? '🔴' : '🟡';
                        if (checkWin(board, board[row][col])) {
                            message.channel.send(`**${player} a gagné !** 🎉\n${printBoard()}`);
                            return true;
                        }
                        return false;
                    }
                }

                message.channel.send('Cette colonne est pleine, essaie une autre colonne.');
                return playTurn(player, message); // Recommence si la colonne est pleine
            } catch (e) {
                message.channel.send(`Temps écoulé ! ${nextPlayer} gagne par forfait.`);
                return true;
            }
        };

        // Initialisation du jeu
        const gameMessage = await message.channel.send(`**${message.author}** a commencé une partie de **Puissance 4**! Un autre joueur peut réagir avec 🔄 pour rejoindre.`);

        // Ajout de la réaction
        await gameMessage.react('🔄');

        // Attente d'un deuxième joueur
        const reactionFilter = (reaction, user) => reaction.emoji.name === '🔄' && user.id !== message.author.id;
        const opponentReaction = await gameMessage.awaitReactions({ filter: reactionFilter, max: 1, time: 60000 });

        if (!opponentReaction.size) {
            return message.channel.send('Aucun joueur n\'a rejoint. Annulation de la partie.');
        }

        nextPlayer = opponentReaction.first().users.cache.filter(user => !user.bot).last(); // S'assurer que c'est bien un joueur humain
        message.channel.send(`**${nextPlayer}** a rejoint la partie ! C'est parti !`);

        // Boucle du jeu
        let gameOver = false;
        while (!gameOver) {
            gameOver = await playTurn(currentPlayer, message);
            [currentPlayer, nextPlayer] = [nextPlayer, currentPlayer]; // Inversion des joueurs
        }
    }
};
