const Discord = require('discord.js');
const Snoway = require('../../structures/client/index.js');

module.exports = {
    name: 'easyembed',
    description: "Crée un embed simple",
    usage: {
        "easyembed <couleur> <texte>": "Crée un embed simple"
    },
    /**
     * 
     * @param {Snoway} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     * @returns 
     */
    run: async (client, message, args) => {
        // Permission checking
        let pass = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(client.noperm || 'Vous n\'avez pas la permission d\'exécuter cette commande.');
        }

        // Command logic starts here
        if (args.length < 2) {
            return message.channel.send(`👀 ${client.prefix}easyembed <couleur> <texte>`);
        }

        const textArg = args.slice(1).join(' ');
        
        const embed = new Discord.EmbedBuilder()
            .setDescription(textArg);

        message.channel.send({embeds: [embed]});
    },
};
