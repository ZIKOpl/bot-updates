const { EmbedBuilder } = require('discord.js');
const Astroia = require("../../structures/client");

module.exports = {
    name: "warn",
    description: "Permet d'ajouter un avertissement à un membre du serveur.",
    usages: "warn <@user/ID> [raison] Permet d'ajouter un avertissement à un membre du serveur",
    /**
     * @param {Astroia} client
     * @param {Astroia} message
     * @param {Astroia} args
     * @returns
     */
    run: async (client, message, args) => {
        console.log("Command 'warn' initiated.");

        try {
            // Vérification des permissions
            let pass = false;
            let staff = client.staff;

            if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
                console.log("Checking permissions.");
                if (client.db.get(`perm_warn.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (client.db.get(`perm_warn.${message.guild.id}`) === "public") pass = true;
            } else {
                pass = true;
            }

            if (!pass) {
                if (client.noperm && client.noperm.trim() !== '') {
                    return message.channel.send(client.noperm);
                } else {
                    return;
                }
            }

            // Vérification des arguments
            if (args.length < 1) {
                return message.channel.send("Utilisation incorrecte : warn <membre>");
            }

            // Récupérer l'utilisateur
            let user = message.mentions.users.first();
            let memberId = args[0];

            if (!user && memberId) {
                user = await client.users.fetch(memberId).catch(() => null);
            }

            if (!user) {
                return message.channel.send("Utilisateur non trouvé. Utilisation correcte : warn <@user/ID> [raison]");
            }

            let reason = args.slice(1).join(' ') || "Aucune raison spécifiée.";
            const db = await client.db.get(`sanction_${message.guild.id}`) || [];
            const genkey = client.functions?.bot?.gen ? client.functions.bot.gen() : generateFallbackKey();

            function generateFallbackKey() {
                // Fallback key generation logic
                return Math.random().toString(36).substring(2, 15);
            }

            db.push({
                userId: user.id,
                code: genkey,
                reason: reason,
                date: Date.now()
            });

            await client.db.set(`sanction_${message.guild.id}`, db);

            // Envoi de l'embed de confirmation
            const successEmbed = new EmbedBuilder()
                .setTitle('Avertissement Ajouté')
                .setDescription(`<@${user.id}> a été **warn** pour \`${reason}\``)
                .setColor(client.color)
                .setFooter(client.footer)
                .setTimestamp();

            await message.channel.send({ embeds: [successEmbed] });

        } catch (err) {
            console.error('Erreur:', err);
            message.reply("Une erreur vient de se produire...");
        }
    }
};
