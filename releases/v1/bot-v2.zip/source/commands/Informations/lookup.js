const Discord = require('discord.js');
const ms = require("ms");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ComponentType } = require("discord.js");

module.exports = {
    name: "lookup",
    aliases: ["lookup"],
    description: "Affiche des informations détaillées sur un utilisateur en fonction de sa mention ou de son ID.",
    usage: "lookup <@user/ID>",
    run: async (client, message, args) => {
        let pass = false;

        let staff = client.staff;

        // Permission checks
        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            
            const commandPermission = client.db.get(`perm_lookup.${message.guild.id}`);

            if (commandPermission === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (commandPermission === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (commandPermission === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (commandPermission === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (commandPermission === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (commandPermission === "public") pass = true;
        } else {
            pass = true; // Bypass for staff, buyers, and owners
        }

        // If the user doesn't have permission
        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        let target;
        if (message.mentions.members.first()) {
            target = message.mentions.members.first();
        } else if (args[0]) {
            try {
                target = await message.guild.members.fetch(args[0]);
            } catch (error) {
                return message.channel.send("Utilisateur introuvable. Veuillez mentionner un utilisateur valide ou fournir un ID d'utilisateur.");
            }
        } else {
            return message.channel.send("Veuillez mentionner un utilisateur ou fournir un ID.");
        }

        const user = target.user;
        const member = target;
        const nickname = member.nickname || "Aucun";
        const isAdmin = member.permissions.has("ADMINISTRATOR") ? '✅ Oui' : '❌ Non';
        const inVoiceChannel = member.voice.channel ? '✅ Oui' : '❌ Non';
        const botStatus = user.bot ? '✅ Oui' : '❌ Non';

        const accountCreated = `<t:${Math.floor(user.createdAt / 1000)}:F> (<t:${Math.floor(user.createdAt / 1000)}:R>)`;
        const joinedAt = `<t:${Math.floor(member.joinedAt / 1000)}:F> (<t:${Math.floor(member.joinedAt / 1000)}:R>)`;

        const userBanner = user.banner ? `https://cdn.discordapp.com/banners/${user.id}/${user.banner}.gif?size=512` : null; // Use .gif for animated banners

        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle(`Profil de l'utilisateur`)
            .setDescription(`<@${user.id}>`)
            .setThumbnail(user.avatarURL())
            .setImage(userBanner || '') // Set the user's banner as the image if available
            .addFields(
                { name: "Bot:", value: botStatus, inline: true },
                { name: "Compte créé:", value: accountCreated, inline: false },
                { name: "\u200A", value: " ", inline: false }, // Spacer line for separation
                { name: "Profil du serveur", value: " ", inline: false }, // Spacer for section separation
                { name: "Surnom:", value: nickname, inline: true },
                { name: "Présent depuis:", value: joinedAt, inline: false },
                { name: "Admin:", value: isAdmin, inline: true },
                { name: "En vocal:", value: inVoiceChannel, inline: true },
            )
            .setFooter(client.footer);    

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setURL(`https://discord.com/users/${user.id}`)
                .setLabel("Voir le profil")
                .setStyle(Discord.ButtonStyle.Link),
            new ButtonBuilder()
                .setCustomId('permissions') // Custom ID for the permissions button
                .setEmoji("🔒")
                .setLabel("Permissions")
                .setStyle(Discord.ButtonStyle.Primary), // Primary style to highlight the button
            new ButtonBuilder()
                .setCustomId('roles') // Custom ID for the roles button
                .setEmoji("👤")
                .setLabel("Rôles")
                .setStyle(Discord.ButtonStyle.Primary) // Primary style for the roles button
        );

        const reply = await message.reply({ embeds: [embed], components: [row] });

        // Create a collector for button interactions
        const filter = (interaction) => interaction.user.id === message.author.id;
        const collector = reply.createMessageComponentCollector({ filter, time: 15000 }); // 15 seconds timeout

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'permissions') {
                const permissions = member.permissions.toArray().map(perm => {
                    return `${perm}`;
                }).join('\n') || "Aucune permission accordée.";
                
                const permissionsEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`Permissions de ${user.username}`)
                    .setDescription(permissions)
                    .setFooter(client.footer);

                await interaction.reply({ embeds: [permissionsEmbed], ephemeral: true }); // Send as ephemeral message
            } else if (interaction.customId === 'roles') {
                const roles = member.roles.cache
                    .filter(role => role.id !== message.guild.id) // Exclude @everyone role
                    .map(role => role.toString())
                    .join(', ') || "Aucun rôle";

                const rolesEmbed = new EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`Liste des rôles de ${user.username}`) // Correctly mentions the user
                    .setDescription(roles);

                await interaction.reply({ embeds: [rolesEmbed], ephemeral: true }); // Send as ephemeral message
            }
        });

        collector.on('end', collected => {
            // Disable buttons when collector ends
            row.components.forEach(button => button.setDisabled(true));
            reply.edit({ components: [row] });
        });
    },
};
