const Discord = require('discord.js');
const fs = require('fs');
const { Astroia } = require('../../structures/client/index.js');

// Définition de la fonction createSupportButton en dehors de run()
function createSupportButton() {
    return new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
            .setLabel('Support')
            .setURL('https://discord.com/channels/1432753003785359452/1432755774362222663') // Remplace par ton lien d'invitation de serveur
            .setStyle(Discord.ButtonStyle.Link) // Style de lien pour rediriger vers un site externe
    );
}

module.exports = {
    name: "help",
    description: "Affiche les commandes du bot",
    usage: "help [commande] Affiche les commandes ou une commande du bot",
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     * @returns 
     */
    run: async (client, message, args, commandName) => {
        try {
            // Vérification des permissions
            let pass = false;
            const staff = client.staff;

            if (!staff.includes(message.author.id) && 
                !client.config.buyers.includes(message.author.id) && 
                client.db.get(`owner_${message.author.id}`) !== true) {
                const perms = client.db.get(`perm_${commandName}.${message.guild.id}`);
                if (perms === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (perms === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (perms === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (perms === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (perms === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
                if (perms === "public") pass = true;
            } else pass = true;

            if (!pass) {
                if (client.noperm && client.noperm.trim() !== '') {
                    return message.channel.send(client.noperm);
                } else {
                    return;
                }
            }

            const prefix = client.prefix;
            const helpMode = client.db.get(`sethelp_${message.guild.id}`) || 'menu'; // Default to 'boutton' if not set

            // Mapping emojis to categories
            const fileEmojis = {
                Informations: '🔍〃',
                Buyers: '🔰〃',
                Moderation: '⚔〃',
                Contact: "✉〃",
                Gestion: '🛠〃',
                Permissions: '🎭〃',
                Musique: '🎶〃',
                Logs: '📁〃',
                Antiraid: '🛡〃',
                GestionBot: '🔑',
                Fun: '🎗〃',
                Outils: '🔧〃',
                Statistiques: '📈〃',
                Embeds: '📋〃',
                Formulaire: '📄〃'
            };

            if (args.length === 0) {
                if (helpMode === 'boutton') {
                    // Mode "boutton"
                    const commandFolders = fs.readdirSync('./source/commands').filter(folder => folder !== 'Dev');
                    let currentCategoryIndex = 0;

                    function createButtons(currentIndex, totalCategories) {
                        return new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId('previous')
                                .setLabel('◀')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(currentIndex === 0),

                            new Discord.ButtonBuilder()
                                .setCustomId('category_display')
                                .setLabel(`${currentIndex + 1}/${totalCategories}`)
                                .setStyle(Discord.ButtonStyle.Secondary)
                                .setDisabled(true),

                            new Discord.ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('▶')
                                .setStyle(Discord.ButtonStyle.Primary)
                                .setDisabled(currentIndex === totalCategories - 1)
                        );
                    }

                    function displayCommands(categoryIndex) {
                        const folder = commandFolders[categoryIndex];
                        const commandFiles = fs.readdirSync(`./source/commands/${folder}`).filter(file => file.endsWith('.js'));
                        const commandsList = commandFiles.map(file => {
                            const command = require(`../${folder}/${file}`);
                            return `- \`${prefix}${command.name}\`\n\***<:homemarket:1433115296742379600> ${command.description || "Pas de description"}***`;
                        }).join('\n\n');

                        const embed = new Discord.EmbedBuilder()
                            .setColor(client.color)
                            .setTitle(`${fileEmojis[folder] || '❓'} ${folder}`)
                            .setDescription(commandsList.length > 4096 ? commandsList.substring(0, 4096) : commandsList)
                            .setFooter(client.footer);

                        return embed;
                    }

                    const embed = displayCommands(currentCategoryIndex);
                    const buttons = createButtons(currentCategoryIndex, commandFolders.length);
                    const supportButton = createSupportButton();

                    const reply = await message.reply({ embeds: [embed], components: [buttons, supportButton] });

                    const filter = i => i.user.id === message.author.id;
                    const collector = reply.createMessageComponentCollector({ filter, time: 60000 });

                    collector.on('collect', async (interaction) => {
                        if (interaction.isButton()) {
                            if (interaction.customId === 'previous') {
                                currentCategoryIndex = Math.max(currentCategoryIndex - 1, 0);
                            } else if (interaction.customId === 'next') {
                                currentCategoryIndex = Math.min(currentCategoryIndex + 1, commandFolders.length - 1);
                            }

                            const updatedEmbed = displayCommands(currentCategoryIndex);
                            const updatedButtons = createButtons(currentCategoryIndex, commandFolders.length);

                            await interaction.update({ embeds: [updatedEmbed], components: [updatedButtons, supportButton] });
                        }
                    });

                } else if (helpMode === 'onepage') {
                    // Mode "onepage"
                    const commandFolders = fs.readdirSync('./source/commands').filter(folder => folder !== 'Dev');
                    const formattedCategories = [];

                    for (const folder of commandFolders) {
                        const commandFiles = fs.readdirSync(`./source/commands/${folder}`).filter(file => file.endsWith('.js'));
                        const categoryCommands = commandFiles.map(file => {
                            const command = require(`../${folder}/${file}`);
                            return command.name;
                        });

                        const emoji = fileEmojis[folder] || '❓'; // Emoji for the category
                        formattedCategories.push(`**${emoji} ${folder}**\n\`${categoryCommands.join('`, `')}\``);
                    }

                    const commandsList = formattedCategories.join('\n\n');

                    const embed = new Discord.EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('Commandes du Bot')
                        .setDescription(commandsList.length > 4096 ? commandsList.substring(0, 4096) : commandsList)
                        .setFooter(client.footer);

                    const supportButton = createSupportButton();

                    message.channel.send({ embeds: [embed], components: [supportButton] });

                } else if (helpMode === 'menu') {
                    // Mode "menu"
                    const commandFolders = fs.readdirSync('./source/commands').filter(folder => folder !== 'Dev');
                
                    // Création d'options avec des emojis
                    const options = commandFolders.map(folder => ({
                        label: `${fileEmojis[folder] || '❓'} ${folder}`, // Ajouter l'emoji au label
                        value: folder
                    }));
                
                    const selectMenu = new Discord.ActionRowBuilder().addComponents(
                        new Discord.StringSelectMenuBuilder()
                            .setCustomId('select-category')
                            .setPlaceholder('Regarde mes options')
                            .addOptions(options)
                    );
                
                    const supportButton = createSupportButton();
                
                    // Création de l'embed pour la sélection
                    const embed = new Discord.EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('Sélectionnez une catégorie')
                        .setDescription('Choisissez une catégorie ci-dessous pour voir les commandes disponibles.')
                        .setFooter(client.footer);
                
                    const reply = await message.reply({ embeds: [embed], components: [selectMenu, supportButton] });
                
                    const filter = i => i.user.id === message.author.id;
                    const collector = reply.createMessageComponentCollector({ filter, time: 60000 });
                
                    collector.on('collect', async (interaction) => {
                        if (interaction.isStringSelectMenu()) {
                            const selectedCategory = interaction.values[0];
                            const commandFiles = fs.readdirSync(`./source/commands/${selectedCategory}`).filter(file => file.endsWith('.js'));
                            const commandsList = commandFiles.map(file => {
                                const command = require(`../${selectedCategory}/${file}`);
                                return `- \`${prefix}${command.name}\`\n\***<:homemarket:1433115296742379600> ${command.description || "Pas de description"}***`;
                            }).join('\n\n');

                            const embed = new Discord.EmbedBuilder()
                                .setColor(client.color)
                                .setTitle(`${fileEmojis[selectedCategory] || '❓'} ${selectedCategory}`)
                                .setDescription(commandsList.length > 4096 ? commandsList.substring(0, 4096) : commandsList)
                                .setFooter(client.footer);
                
                            await interaction.update({ embeds: [embed], components: [selectMenu, supportButton] });
                        }
                    });
                }

            } else {
                // Aide pour une commande spécifique
                const cmdname = args[0];
                const command = client.commands.get(cmdname) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(cmdname));
                if (!command) {
                    return message.reply(`Cette commande n'existe pas. Utilisez \`${prefix}help\` pour voir la liste des commandes.`);
                }

                const usages = command.usage || 'Aucune information sur l\'utilisation disponible.';
                const description = command.description || 'Aucune description disponible.';

                const embed = new Discord.EmbedBuilder()
                    .setTitle(`Commande : \`${command.name}\``)
                    .setColor(client.color)
                    .setDescription(`**Description :** ${description}\n**Utilisation :** ${usages}\n**Alias :** ${command.aliases ? command.aliases.join(', ') : 'Aucun'}`)
                    .setFooter(client.footer);

                const supportButton = createSupportButton();

                message.channel.send({ embeds: [embed], components: [supportButton] });
            }
        } catch (error) {
            console.error('Error executing help command:', error);
            message.channel.send('Une erreur est survenue lors de l\'exécution de la commande.');
        }
    }
};

async function perms(command) {
    switch (command) {
        case '1': return 'Permission 1'; 
        case '2': return 'Permission 2'; 
        case '3': return 'Permission 3'; 
        case '4': return 'Permission 4'; 
        case '5': return 'Permission 5'; 
        case 'ticket': return 'Permission Ticket'; 
        case 'Giveaway': return 'Permission Giveaway';
        default: return 'Aucune';
    }
}
