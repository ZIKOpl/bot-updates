const Discord = require('discord.js');
const math = require('mathjs');

module.exports = {
    name: "calc",
    aliases: ["calculate"],
    description: "Permet de résoudre une équation mathématique.",
    usages: "calc <équation>",
    run: async (client, message, args, commandName) => {
        let pass = false;

        let staff = client.staff;

        // Check permissions for the user
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        // If the user does not have permission, send a message and exit
        if (pass === false) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        // Join all arguments to form the equation
        const equation = args.join(' ');

        // Check if an equation is provided
        if (!equation) {
            return message.channel.send("Veuillez fournir une équation à résoudre.");
        }

        try {
            // Evaluate the equation using mathjs
            const result = math.evaluate(equation);
            // Create the embed to display the result
            const embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setTitle("Résultat de l'équation")
                .addFields(
                    { name: "Équation", value: `\`${equation}\``, inline: false },
                    { name: "Résultat", value: `\`${result}\``, inline: false }
                )
                .setFooter(client.footer)
                .setTimestamp();

            // Send the embed message
            await message.channel.send({ embeds: [embed] });
        } catch (error) {
            // Handle any errors that occur during evaluation
            console.error(error);
            return message.channel.send("Erreur lors de l'évaluation de l'équation. Assurez-vous que votre équation est correcte.");
        }
    },
};
