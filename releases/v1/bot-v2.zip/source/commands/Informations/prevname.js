const axios = require('axios');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const ms = require('ms');

module.exports = {
  name: 'prevname',
  description: 'Affiche vos anciens pseudos',
  usages: 'prevname <utilisateur/id>',

  run: async (client, message, args, commandName) => {
    const permissions = client.db.get(`perm_${commandName}.${message.guild.id}`);
    let hasPermission = false;

    // Check for permissions
    if (client.staff.includes(message.author.id) || 
        client.config.buyers.includes(message.author.id) || 
        client.db.get(`owner_${message.author.id}`) === true) {
      hasPermission = true;
    } else if (permissions === 'public' || message.member.roles.cache.some(r => client.db.get(`perm${permissions}.${message.guild.id}`)?.includes(r.id))) {
      hasPermission = true;
    }

    if (!hasPermission) {
      return message.channel.send(client.noperm || 'You do not have permission to use this command.');
    }

    const original = await message.channel.send({ content: await client.lang('prevname.recherche') });
    let target;

    if (message.mentions.members.first()) {
      target = message.mentions.members.first();
    } else if (args[0]) {
      try {
        target = await client.users.fetch(args[0]);
      } catch (error) {
        return original.edit(await client.lang('prevname.nouser'));
      }
    } else {
      target = message.member;
    }

    const userId = target.id;

    try {
      const response = await axios.get(`http://localhost:3002/prevnames/${userId}`);
      const pseudonyms = response.data.pseudonyms;

      if (pseudonyms.length === 0) {
        return original.edit(await client.lang('prevname.nopseudo'));
      }

      const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle(await client.lang('prevname.title'))
        .setDescription(pseudonyms.map((entry, index) => `**${index + 1} -** <t:${Math.floor(entry.timestamp / 1000)}:D> - [\`${entry.old_name}\`](https://discord.com/users/${userId})`).join('\n'))
        .setFooter({ text: `${await client.lang('prevname.footer')} ${pseudonyms.length}`, iconURL: message.author.avatarURL() });

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`prevname_button_${message.id}`)
            .setEmoji('🗑️')
            .setStyle(ButtonStyle.Secondary)
        );

      const reply = await original.edit({ embeds: [embed], components: [row], content: null });

      const collector = reply.createMessageComponentCollector({
        filter: i => i.user.id === target.user.id,
        componentType: ComponentType.Button,
        time: ms('2m')
      });

      collector.on('collect', async (interaction) => {
        if (interaction.customId === `prevname_button_${message.id}`) {
          await interaction.reply({ content: await client.lang('prevname.buttonreply'), ephemeral: true });
          reply.delete().catch(console.error);
        }
      });

      collector.on('end', collected => {
        if (collected.size === 0) {
          reply.delete().catch(console.error);
        }
      });

    } catch (error) {
      console.error('Error fetching pseudonyms:', error);
      original.edit(await client.lang('erreur'));
    }
  }
};
