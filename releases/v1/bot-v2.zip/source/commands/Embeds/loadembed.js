const Discord = require('discord.js');
const Astroia = require('../../structures/client/index.js');

module.exports = {
    name: 'loadembed',
    description: "Charge et affiche un embed sauvegardé par son nom",
    usage: { 
        "loadembed <nom>": "Charge et affiche un embed sauvegardé par son nom"
    },
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message 
     * @param {string[]} args 
     * @returns 
     */
    run: async (client, message, args) => {
        // Permission checking
        let pass = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (client.db.get(`perm_ticket.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(client.noperm || 'Vous n\'avez pas la permission d\'exécuter cette commande.');
        }

        // Command logic starts here
        const savedEmbeds = await client.db.get(`embeds`);
        
        if (!savedEmbeds || savedEmbeds.length === 0) {
            return message.channel.send("Aucun embed enregistré.");
        }

        const name = args[0];
        const filteredEmbeds = savedEmbeds.filter(e => e.name === name);

        if (filteredEmbeds.length === 0) {
            return message.channel.send(`Aucun embed enregistré avec le nom \`${name}\`.`);
        }

        const embed = new Discord.EmbedBuilder(filteredEmbeds[0]);
        message.channel.send({ embeds: [embed] });
    },
};
