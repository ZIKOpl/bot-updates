const ms = require('ms');
const Discord = require('discord.js');
const { StringSelectMenuBuilder, ActionRowBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'soutien',
    description: 'Permet de configurer le système de soutien',
    usage: "soutien",
    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const guildId = message.guild.id;
            if (client.db.get(`perm_${commandName}.${guildId}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${guildId}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${guildId}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${guildId}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${guildId}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${guildId}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${guildId}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${guildId}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${guildId}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${guildId}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${guildId}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (pass === false) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        const originalmsg = await message.channel.send(await client.lang('soutien.chargement'));

        async function updateEmbed() {
            const db = client.db.get(`soutien_${message.guild.id}`) || client.db.set(`soutien_${message.guild.id}`, {
                name: null,
                role: [],
                status: false
            });
            const status = db?.status === true ? "🟢 Actif" : "🔴 Désactivé";
            const namesoutien = db.name || 'Aucun statut personnalisé';
            const role = db?.role || [];
            const rolename = role.length > 0
                ? await Promise.all(role.map(async (roleId) => (await message.guild.roles.fetch(roleId))?.name || 'Rôle inconnu'))
                : ['Aucun rôle associé'];

            const embed = new EmbedBuilder()
                .setTitle('🎯 Configuration du Soutien')
                .setColor(client.color)
                .setFooter(client.footer)
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .addFields(
                    { name: '📊 Statut', value: `\`\`\`yml\n${status}\`\`\``, inline: true },
                    { name: '📝 Statut personnalisé', value: `\`\`\`yml\n${namesoutien}\`\`\``, inline: true },
                    { name: '🔰 Rôle(s)', value: `\`\`\`yml\n${rolename.join(', ')}\`\`\`` }
                );

            const buttonReset = new Discord.ButtonBuilder()
                .setCustomId('soutien_reset_' + message.id)
                .setLabel('🔄 Réinitialiser')
                .setStyle(Discord.ButtonStyle.Danger);

            const select = new StringSelectMenuBuilder()
                .setCustomId(`soutien_setup_` + message.id)
                .setPlaceholder('Sélectionnez une option...')
                .addOptions([
                    {
                        label: '🔄 Activer/Désactiver le statut',
                        value: 'status_' + message.id,
                    },
                    {
                        label: '✏️ Modifier le statut personnalisé',
                        value: 'statusperso_' + message.id,
                    },
                    {
                        label: '🔰 Associer un rôle',
                        value: 'role_' + message.id,
                    },
                ]);

            const rowSelect = new ActionRowBuilder().addComponents(select);
            const rowButton = new ActionRowBuilder().addComponents(buttonReset);

            originalmsg.edit({ content: null, components: [rowSelect, rowButton], embeds: [embed] });
        }

        await updateEmbed();

        const collector = message.channel.createMessageComponentCollector({ 
            filter: m => m.user.id == message.author.id, 
            componentType: Discord.ComponentType.StringSelect || Discord.ComponentType.Button, 
            time: ms("2m") 
        });

        collector.on("collect", async (i) => {
            const db = client.db.get(`soutien_${message.guild.id}`);
            if (i.values[0] === `status_${message.id}`) {
                let missingOptions = [];

                if (!db) {
                    missingOptions.push('Pas de statut configuré.');
                } else {
                    if (db.role === null) {
                        missingOptions.push('Aucun rôle configuré.');
                    }
                    if (db.name === null) {
                        missingOptions.push('Aucun statut personnalisé.');
                    }
                    if (missingOptions.length === 0) {
                        const currentStatus = db.status;
                        db.status = !currentStatus;
                        client.db.set(`soutien_${message.guild.id}`, db);
                        const statusMessage = db.status ? "Statut activé." : "Statut désactivé.";
                        await i.reply({ content: statusMessage, ephemeral: true });
                        await updateEmbed();
                    } else {
                        const missingOptionsString = missingOptions.map(option => `- \`${option}\``).join('\n');
                        await i.reply({ content: `Veuillez compléter les options manquantes :\n${missingOptionsString}`, ephemeral: true });
                    }
                }
            } else if (i.values[0] === `role_${message.id}`) {
                const roleRow = new Discord.ActionRowBuilder().addComponents(
                    new Discord.RoleSelectMenuBuilder()
                        .setCustomId('soutien_setup_role_' + message.id)
                        .setPlaceholder('Sélectionnez un ou plusieurs rôles')
                        .setMaxValues(25)
                );
                await i.reply({ content: 'Sélectionnez les rôles à associer au soutien.', components: [roleRow], ephemeral: true });
            } else if (i.values[0] === 'statusperso_' + message.id) {
                const filter = response => response.author.id === message.author.id;
                const sentMessage = await i.reply('Veuillez fournir le nouveau statut personnalisé :');

                try {
                    const collected = await message.channel.awaitMessages({ filter, max: 1, time: ms("1m"), errors: ['time'] });
                    const msg = collected.first().content.trim();
                    db.name = msg;
                    client.db.set(`soutien_${message.guild.id}`, db);
                    await updateEmbed();
                    sentMessage.delete();
                    collected.first().delete();
                } catch (error) {
                    console.error(error);
                    await i.followUp('Temps écoulé, veuillez réessayer.', { ephemeral: true });
                }
            }
        });

        client.on('interactionCreate', async (i) => {
            if (message.author.id === i.user.id) {
                const db = client.db.get(`soutien_${message.guild.id}`);
                if (i.customId === `soutien_reset_${message.id}`) {
                    client.db.delete(`soutien_${message.guild.id}`);
                    await i.reply({ content: 'Le système de soutien a été réinitialisé.', ephemeral: true });
                    await updateEmbed();
                }
                if (i.customId === `soutien_setup_role_${message.id}`) {
                    const selectedRoles = i.values;
                    db.role = selectedRoles;
                    client.db.set(`soutien_${message.guild.id}`, db);
                    await updateEmbed();
                    await i.update({ content: 'Les rôles ont été mis à jour.', components: [], embeds: [] });
                }
            }
        });
    }
};
