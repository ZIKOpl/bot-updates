const Discord = require('discord.js');
const Astroia = require('../../structures/client');

module.exports = {
    name: "wl",
    aliases: ["whitelist"],
    description: "Permet de gérer la whitelist",
    category: "botcontrol",
    usage: "wl",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message
     */
    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;

        // Vérification des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Fonction pour mettre à jour l'embed de la whitelist
        const updateWhitelistEmbed = async () => {
            let wlz = client.db.get(`wl.${message.guild.id}`);
            let wl;

            if (!wlz || wlz.length === 0) {
                wl = await client.lang(`wl.aucun`);
                return new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`Liste des whitelist`)
                    .setDescription(`${wl}`)
                    .setFooter(client.footer);
            } else {
                wl = wlz.map(a => `<@${a}>`).join("\n");
                return new Discord.EmbedBuilder()
                    .setColor(client.color)
                    .setTitle(`Liste des whitelist`)
                    .setDescription(`${wl}`)
                    .setFooter(client.footer);
            }
        };

        // Créer les boutons
        const addButton = new Discord.ButtonBuilder()
            .setCustomId('wl_add')
            .setLabel('Ajouter')
            .setStyle(Discord.ButtonStyle.Primary);

        const removeButton = new Discord.ButtonBuilder()
            .setCustomId('wl_remove')
            .setLabel('Supprimer')
            .setStyle(Discord.ButtonStyle.Danger);

        const clearButton = new Discord.ButtonBuilder()
            .setCustomId('wl_clear')
            .setLabel('Effacer')
            .setStyle(Discord.ButtonStyle.Secondary);

        const row = new Discord.ActionRowBuilder()
            .addComponents(addButton, removeButton, clearButton);

        // Afficher la whitelist avec les boutons
        let embed = await updateWhitelistEmbed();
        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        // Filtrer les interactions de boutons
        const filter = (interaction) => interaction.isButton() && interaction.user.id === message.author.id;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async (interaction) => {
            // Lorsque l'utilisateur clique sur Ajouter
            if (interaction.customId === 'wl_add') {
                interaction.reply({ content: "Veuillez mentionner un utilisateur ou entrer son ID à ajouter à la whitelist. Vous avez 30 secondes.", ephemeral: true });

                const msgFilter = m => m.author.id === interaction.user.id;
                const msgCollector = message.channel.createMessageCollector({ filter: msgFilter, time: 30000, max: 1 });

                msgCollector.on('collect', async (msg) => {
                    const member = msg.mentions.members.first() || message.guild.members.cache.get(msg.content);

                    if (!member || !message.guild.members.cache.has(member.id)) {
                        return interaction.followUp({ content: "Utilisateur invalide.", ephemeral: true });
                    }

                    // Vérifiez si l'utilisateur est déjà dans la whitelist
                    if (client.db.get(`wl.${message.guild.id}`).includes(member.id)) {
                        return interaction.followUp({ content: `${member.user.username} est déjà dans la whitelist.`, ephemeral: true });
                    }

                    client.db.push(`wl.${message.guild.id}`, member.id);
                    client.db.set(`wlmd_${message.guild.id}_${member.id}`, true);
                    msgCollector.stop();  // Arrête le collecteur de messages

                    // Met à jour l'embed après l'ajout
                    embed = await updateWhitelistEmbed();
                    await sentMessage.edit({ embeds: [embed] });

                    // Désactiver les boutons après l'ajout
                    row.components.forEach(button => button.setDisabled(true));
                    await sentMessage.edit({ components: [row] });

                    interaction.followUp({ content: `**${member.user.username}** a été ajouté à la whitelist.`, ephemeral: true });
                });

                msgCollector.on('end', collected => {
                    if (collected.size === 0) {
                        interaction.followUp({ content: "Aucun utilisateur ajouté à la whitelist.", ephemeral: true });
                    }
                });

            // Lorsque l'utilisateur clique sur Supprimer
            } else if (interaction.customId === 'wl_remove') {
                interaction.reply({ content: "Veuillez mentionner un utilisateur ou entrer son ID à supprimer de la whitelist. Vous avez 30 secondes.", ephemeral: true });

                const msgFilter = m => m.author.id === interaction.user.id;
                const msgCollector = message.channel.createMessageCollector({ filter: msgFilter, time: 30000, max: 1 });

                msgCollector.on('collect', async (msg) => {
                    const member = msg.mentions.members.first() || message.guild.members.cache.get(msg.content);

                    if (!member || !client.db.get(`wl.${message.guild.id}`).includes(member.id)) {
                        return interaction.followUp({ content: "L'utilisateur n'est pas dans la whitelist.", ephemeral: true });
                    }

                    // Supprimer l'utilisateur de la whitelist
                    client.db.set(`wl.${message.guild.id}`, client.db.get(`wl.${message.guild.id}`).filter(id => id !== member.id));
                    client.db.delete(`wlmd_${message.guild.id}_${member.id}`);
                    msgCollector.stop();  // Arrête le collecteur de messages

                    // Met à jour l'embed après la suppression
                    embed = await updateWhitelistEmbed();
                    await sentMessage.edit({ embeds: [embed] });

                    // Désactiver les boutons après la suppression
                    row.components.forEach(button => button.setDisabled(true));
                    await sentMessage.edit({ components: [row] });

                    interaction.followUp({ content: `**${member.user.username}** a été supprimé de la whitelist.`, ephemeral: true });
                });

                msgCollector.on('end', collected => {
                    if (collected.size === 0) {
                        interaction.followUp({ content: "Aucun utilisateur supprimé de la whitelist.", ephemeral: true });
                    }
                });

            // Lorsque l'utilisateur clique sur Effacer
            } else if (interaction.customId === 'wl_clear') {
                let data = await client.db.all().filter(data => data.ID.startsWith(`wlmd_${message.guild.id}`));
                client.db.set(`wl.${message.guild.id}`, []);
                let count = 0;

                for (let i = 0; i < data.length; i++) {
                    client.db.delete(data[i].ID);
                    count++;
                }

                interaction.reply({ content: `${count} utilisateurs ont été supprimés de la whitelist.`, ephemeral: true });

                // Met à jour l'embed après le clear
                embed = await updateWhitelistEmbed();
                await sentMessage.edit({ embeds: [embed] });

                // Désactiver les boutons après le clear
                row.components.forEach(button => button.setDisabled(true));
                await sentMessage.edit({ components: [row] });
            }
        });

        collector.on('end', () => {
            row.components.forEach(button => button.setDisabled(true));
            sentMessage.edit({ components: [row] });
        });
    }
};
