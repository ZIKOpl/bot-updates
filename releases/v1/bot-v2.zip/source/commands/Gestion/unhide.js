const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'ghostping',
    description: 'Ajoute, supprime ou liste les salons de ghost ping.',
    usage: "unhide",
    /**
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Vérification des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permissionLevel = client.db.get(`perm_ghostping.${message.guild.id}`);
            if (permissionLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (permissionLevel === "public") pass = true;   
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        const action = args[0];
        const channel = message.mentions.channels.first();

        if (action === 'list') {
            const ghostpingChannels = client.db.get(`ghostping_${message.guild.id}`) || [];
            if (ghostpingChannels.length === 0) {
                return message.reply("Il n'y a actuellement aucun salon dans la liste des salons de ghost ping.");
            }

            const channelList = ghostpingChannels.map(id => `<#${id}>`).join('\n');
            const embed = new EmbedBuilder()
                .setTitle('Salons de Ghost Ping')
                .setDescription(channelList)
                .setColor(client.color);

            return message.reply({ embeds: [embed] });
        }

        if (action === 'add') {
            if (!channel) {
                return message.reply("Vous devez mentionner un salon.");
            }

            const ghostpingChannels = client.db.get(`ghostping_${message.guild.id}`) || [];
            if (ghostpingChannels.includes(channel.id)) {
                return message.reply("Ce salon est déjà dans la liste des salons de ghost ping.");
            }

            ghostpingChannels.push(channel.id);
            client.db.set(`ghostping_${message.guild.id}`, ghostpingChannels);

            return message.reply(`Le salon ${channel} a été ajouté à la liste des salons de ghost ping.`);
        } else if (action === 'remove') {
            if (!channel) {
                return message.reply("Vous devez mentionner un salon.");
            }

            let ghostpingChannels = client.db.get(`ghostping_${message.guild.id}`) || [];
            if (!ghostpingChannels.includes(channel.id)) {
                return message.reply("Ce salon n'est pas dans la liste des salons de ghost ping.");
            }

            ghostpingChannels = ghostpingChannels.filter(id => id !== channel.id);
            client.db.set(`ghostping_${message.guild.id}`, ghostpingChannels);

            return message.reply(`Le salon ${channel} a été supprimé de la liste des salons de ghost ping.`);
        } else {
            return message.reply("Vous devez spécifier une action valide : `add`, `remove` ou `list`.");
        }
    }
};
