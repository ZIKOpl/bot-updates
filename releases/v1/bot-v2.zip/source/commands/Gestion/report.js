const Discord = require('discord.js');
const Astroia = require('../../structures/client');

module.exports = {
  name: "report",
  description: "Permet de reporter un message",
  /**
   * @param {Astroia} client 
   * @param {Discord.Message} message
   */
  run: async (client, message, args) => {
    // Vérifier si le système de report est activé et si un canal de report est configuré
    const reportConfig = client.db.get(`report_${message.guild.id}`);
    
    if (!reportConfig || reportConfig.status === false || !reportConfig.channel) {
      return message.reply("Le système de report n'est pas configuré ou désactivé.");
    }

    // Vérifier si l'ID du message à reporter est fourni
    const messageId = args[0];
    if (!messageId || isNaN(messageId) || messageId.length < 17) {
      return message.reply("Veuillez fournir un ID de message valide.");
    }

    // Vérifier si le motif du report est fourni
    const reportReason = args.slice(1).join(" ");
    if (!reportReason) {
      return message.reply("Veuillez fournir une raison pour le report.");
    }

    try {
      // Récupérer le message à reporter
      const reportedMessage = await message.channel.messages.fetch(messageId);

      if (!reportedMessage) {
        return message.reply("Message introuvable.");
      }

      // Retirer la commande de report du message
      const cleanMessageContent = reportedMessage.content.replace(/^\+report\s*/i, "");

      // Récupérer le canal de report configuré
      const reportChannel = client.channels.cache.get(reportConfig.channel);
      if (!reportChannel) {
        return message.reply("Le canal de report n'est pas configuré correctement.");
      }

      // Créer un embed pour le report
      const reportEmbed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setTitle("Nouveau Report de Message")
        .addFields(
          { name: "Message", value: `[Voir le message](https://discord.com/channels/${message.guild.id}/${message.channel.id}/${reportedMessage.id})`, inline: false },
          { name: "Auteur du message", value: reportedMessage.author.tag, inline: true },
          { name: "ID du message", value: reportedMessage.id, inline: true },
          { name: "Contenu du message", value: cleanMessageContent || "Pas de contenu", inline: false },
          { name: "Signalé par", value: `<@${message.author.id}>`, inline: true },
          { name: "Raison", value: reportReason, inline: false }
        )
        .setTimestamp();

      // Envoyer l'embed dans le canal de report
      await reportChannel.send({ embeds: [reportEmbed] });

      // Répondre à l'utilisateur pour confirmer le report
      message.reply(`Le message a été signalé avec succès dans ${reportChannel}.`);

    } catch (error) {
      console.error("Erreur lors du report du message :", error);

      // Vérifier si l'erreur provient d'un mauvais message ID
      if (error.message.includes('Unknown Message')) {
        return message.reply("Le message spécifié est introuvable ou n'existe plus.");
      }

      // Message générique pour toute autre erreur
      message.reply("Une erreur est survenue lors du report du message.");
    }
  },
};
