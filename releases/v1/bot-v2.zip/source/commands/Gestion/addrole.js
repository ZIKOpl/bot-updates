const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "addrole",
    description: "Permet d'ajouter un rôle à un membre.",
    usage: "addrole <membre> <mention-du-rôle/id-du-rôle>",
    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        if (args.length < 2) {
            return message.channel.send("Utilisation incorrecte : addrole <membre> <mention-du-rôle/id-du-rôle>");
        }

        let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!member) {
            return message.channel.send("Membre introuvable sur le serveur.");
        }

        let role;
        const roleArg = args[1];

        // Check if the role argument is a mention or an ID
        if (roleArg.startsWith('<@&') && roleArg.endsWith('>')) {
            const roleId = roleArg.slice(3, -1);
            role = message.guild.roles.cache.get(roleId);
        } else {
            role = message.guild.roles.cache.get(roleArg) || message.guild.roles.cache.find(r => r.name === roleArg);
        }

        if (!role) {
            return message.channel.send("Rôle introuvable sur le serveur.");
        }

        // Ensure bot's member object is available
        const botMember = message.guild.members.cache.get(client.user.id);

        if (!botMember) {
            return message.channel.send("Je ne suis pas dans ce serveur.");
        }

        // Check bot's permissions
        if (!botMember.permissions.has('MANAGE_ROLES')) {
            return message.channel.send("Je n'ai pas la permission de gérer les rôles.");
        }

        // Check role hierarchy
        if (role.position >= botMember.roles.highest.position) {
            return message.channel.send("Je ne peux pas ajouter un rôle plus élevé ou égal au mien.");
        }

        // Check if the bot's highest role is higher than the target role
        if (botMember.roles.highest.position <= role.position) {
            return message.channel.send("Je ne peux pas gérer ce rôle car il est plus élevé ou égal au mien.");
        }

        if (member.roles.cache.has(role.id)) {
            return message.channel.send(`${member.user.tag} a déjà le rôle ${role.name}.`);
        }

        try {
            await member.roles.add(role);
            message.channel.send(`${member.user.tag} vient de recevoir le rôle : ${role.name}.`);
        } catch (error) {
            console.error(error);
            message.channel.send("Une erreur est survenue.");
        }
    }
}
