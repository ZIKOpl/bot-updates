const { MessageEmbed, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'constentmessage',
    description: 'Active le contentmessage pour ce channel.',
    usage: "constentmessage <message>",
    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;
        let commandName = 'constentmessage'; // Assurez-vous que `commandName` est défini pour les permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (pass === false) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        let content = args.join(' ');

        if (args.length === 1 && !isNaN(args[0])) {
            try {
                const fetchedMessage = await message.channel.messages.fetch(args[0]);
                if (fetchedMessage) {
                    content = fetchedMessage.content;
                    if (fetchedMessage.embeds.length > 0) {
                        const embedData = fetchedMessage.embeds[0];
                        const embed = new EmbedBuilder(embedData);
                        await client.db.set(`constentmsg_${message.guild.id}_${message.channel.id}`, { embed: embed.toJSON(), content: content, msgID: null });
                        return message.channel.send('L\'embed du message spécifié a été sauvegardé avec succès dans la base de données !');
                    }
                }
            } catch (error) {
                console.error(error.message);
                return message.channel.send('Le message spécifié est introuvable ou inaccessible.');
            }
        }

        try {
            // Supprime l'ancien message si existant
            const previousMessageId = await client.db.get(`constentmsg_${message.guild.id}_${message.channel.id}.msgID`);
            if (previousMessageId) {
                const previousMessage = await message.channel.messages.fetch(previousMessageId).catch(() => null);
                if (previousMessage) {
                    await previousMessage.delete();
                }
            }

            // Envoie le nouveau message
            const sentMessage = await message.channel.send(content);

            // Sauvegarde le nouveau message dans la base de données
            await client.db.set(`constentmsg_${message.guild.id}_${message.channel.id}`, { content: content, msgID: sentMessage.id });

        } catch (error) {
            console.error(error.message);
            message.channel.send('Une erreur s\'est produite lors de la sauvegarde du message.');
        }
    }
}
