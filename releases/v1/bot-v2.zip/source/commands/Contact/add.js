const Discord = require('discord.js');

module.exports = {
    name: "add",
    description: "Ajoute un utilisateur à un ticket",
    usage: "add <@user>",
    /**
     * @param {Discord.Client} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args) => {
        // Vérifiez les permissions de l'utilisateur
        let pass = false;
        if (client.staff.includes(message.author.id) || client.config.buyers.includes(message.author.id) || client.db.get(`owner_${message.author.id}`) === true) {
            pass = true;
        } else {
            const permLevel = client.db.get(`perm_add.${message.guild.id}`);
            if (permLevel) {
                const roles = client.db.get(`perm${permLevel}.${message.guild.id}`) || [];
                if (roles.some(r => message.member.roles.cache.has(r))) {
                    pass = true;
                }
            }
        }
        if (!pass) {
            return message.channel.send("Vous n'avez pas les permissions nécessaires pour utiliser cette commande.");
        }

        // Vérifiez si un utilisateur est mentionné
        const user = message.mentions.members.first();
        if (!user) {
            return message.channel.send("Vous devez mentionner un utilisateur pour l'ajouter au ticket.");
        }

        // Identifiez le ticket à partir du salon actuel
        const channelId = message.channel.id;
        let db = await client.db.get(`ticket_${message.guild.id}`);

        if (!db) {
            db = {
                tickets: [] // Initialisez la base de données si elle est vide
            };
        }

        if (!Array.isArray(db.tickets)) {
            db.tickets = [];
        }

        // Trouvez le ticket lié au salon actuel
        let ticket = db.tickets.find(t => t.channelId === channelId);

        if (!ticket) {
            // Créez un nouveau ticket si aucun n'est trouvé
            ticket = {
                id: Date.now().toString(), // Utilisez un ID unique
                channelId: channelId,
                users: []
            };
            db.tickets.push(ticket);
        }

        // Vérifiez si l'utilisateur a déjà les permissions dans le salon
        const hasPermission = message.channel.permissionsFor(user).has(['ViewChannel', 'SendMessages']);

        // Si l'utilisateur est déjà dans la base de données mais n'a pas de permissions, on les met à jour
        if (!ticket.users.includes(user.id) || !hasPermission) {
            // Ajoutez l'utilisateur à la liste des utilisateurs du ticket s'il n'est pas déjà dans la liste
            if (!ticket.users.includes(user.id)) {
                ticket.users.push(user.id);
            }

            // Mettez à jour les permissions pour l'utilisateur dans le salon
            try {
                await message.channel.permissionOverwrites.edit(user.id, {
                    ViewChannel: true,
                    SendMessages: true
                });

                // Mettez à jour la base de données
                await client.db.set(`ticket_${message.guild.id}`, db);

                // Envoyez un message de confirmation
                return message.channel.send(`**${user.user.username}** a été ajouté au ticket.`);
            } catch (error) {
                console.error("Erreur lors de la mise à jour des permissions :", error);
                return message.channel.send("Une erreur s'est produite lors de la mise à jour des permissions.");
            }
        } else {
            return message.channel.send("Cet utilisateur est déjà ajouté au ticket avec les permissions appropriées.");
        }
    }
};
