const Discord = require('discord.js');

module.exports = {
    name: "rename",
    description: "Renomme le salon",
    usage: "rename <nouveau_nom>",
    /**
     * @param {Discord.Client} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args) => {
        // Vérifiez les permissions de l'utilisateur
        let hasPermission = false;
        if (client.staff.includes(message.author.id) || client.config.buyers.includes(message.author.id) || client.db.get(`owner_${message.author.id}`) === true) {
            hasPermission = true;
        } else {
            const permLevel = client.db.get(`perm_rename.${message.guild.id}`);
            if (permLevel) {
                const roles = client.db.get(`perm${permLevel}.${message.guild.id}`) || [];
                if (roles.some(roleId => message.member.roles.cache.has(roleId))) {
                    hasPermission = true;
                }
            }
        }
        if (!hasPermission) {
            return message.channel.send("Vous n'avez pas les permissions nécessaires pour utiliser cette commande.");
        }

        // Vérifiez si un nouveau nom est fourni
        const newName = args.join(" ");
        if (!newName) {
            return message.channel.send("Veuillez fournir un nouveau nom pour le salon.");
        }

        // Limitez la longueur du nom (Discord a une limite de 100 caractères pour les noms de salon)
        if (newName.length > 100) {
            return message.channel.send("Le nom du salon ne peut pas dépasser 100 caractères.");
        }

        // Renommer le salon
        try {
            await message.channel.setName(newName);
            // Envoyer un message de confirmation
            return message.channel.send(`Le salon a été renommé en **${newName}**.`);
        } catch (error) {
            console.error("Erreur lors du renommage du salon :", error);
            return message.channel.send("Une erreur s'est produite lors du renommage du salon.");
        }
    }
};
