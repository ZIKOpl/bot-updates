const Discord = require('discord.js');

module.exports = {
    name: "remove",
    description: "Retire un utilisateur d'un ticket",
    usage: "remove <@user>",
    /**
     * @param {Discord.Client} client
     * @param {Discord.Message} message
     * @param {string[]} args
     */
    run: async (client, message, args) => {
        // Vérifiez les permissions de l'utilisateur
        let pass = false;
        if (client.staff.includes(message.author.id) || client.config.buyers.includes(message.author.id) || client.db.get(`owner_${message.author.id}`) === true) {
            pass = true;
        } else {
            const permLevel = client.db.get(`perm_remove.${message.guild.id}`);
            if (permLevel) {
                const roles = client.db.get(`perm${permLevel}.${message.guild.id}`) || [];
                if (roles.some(r => message.member.roles.cache.has(r))) {
                    pass = true;
                }
            }
        }
        if (!pass) {
            return message.channel.send("Vous n'avez pas les permissions nécessaires pour utiliser cette commande.");
        }

        // Vérifiez si un utilisateur est mentionné
        const user = message.mentions.members.first();
        if (!user) {
            return message.channel.send("Vous devez mentionner un utilisateur pour le retirer du ticket.");
        }

        // Identifiez le ticket à partir du salon actuel
        const channelId = message.channel.id;
        let db = await client.db.get(`ticket_${message.guild.id}`);

        if (!db || !Array.isArray(db.tickets)) {
            return message.channel.send("Aucun ticket n'a été trouvé dans ce salon.");
        }

        // Trouvez le ticket lié au salon actuel
        let ticket = db.tickets.find(t => t.channelId === channelId);

        if (!ticket) {
            return message.channel.send("Aucun ticket n'a été trouvé dans ce salon.");
        }

        // Vérifiez si l'utilisateur fait partie du ticket
        if (!ticket.users.includes(user.id)) {
            return message.channel.send("Cet utilisateur n'est pas dans ce ticket.");
        }

        // Retirer les permissions de l'utilisateur dans le salon
        try {
            await message.channel.permissionOverwrites.edit(user.id, {
                ViewChannel: false,
                SendMessages: false
            });

            // Retirer l'utilisateur de la liste des utilisateurs du ticket
            ticket.users = ticket.users.filter(u => u !== user.id);

            // Mettez à jour la base de données
            await client.db.set(`ticket_${message.guild.id}`, db);

            // Envoyez un message de confirmation
            return message.channel.send(`**${user.user.username}** a été retiré du ticket.`);
        } catch (error) {
            console.error("Erreur lors de la mise à jour des permissions :", error);
            return message.channel.send("Une erreur s'est produite lors de la mise à jour des permissions.");
        }
    }
};
