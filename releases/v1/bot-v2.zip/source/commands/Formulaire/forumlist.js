const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "forumlist",
    description: "Liste tous les formulaires créés avec leurs configurations.",
    usages: "forumlist",

    run: async (client, message, args) => {
        // Vérification des permissions
        let pass = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            
            const permissionLevel = client.db.get(`perm_forumlist.${message.guild.id}`);
            if (permissionLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permissionLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true; 
            if (permissionLevel === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.channel.send(client.noperm?.trim() || "Permission non accordée.");
        }

        const guildId = message.guild.id;
        const forms = client.db.get(`forms_${guildId}`) || [];

        // Créer l'embed
        const embed = new EmbedBuilder()
            .setColor(client.color) // Choisir la couleur de l'embed
            .setTitle('Formulaires pour ce serveur');

        if (forms.length === 0) {
            embed.setDescription('Aucun formulaire créé.');
        } else {
            forms.forEach((form) => {
                embed.addFields(
                    { 
                        name: `ID du Formulaire: ${form.id}`, 
                        value: `**Titre :** ${form.title}\n**Message :** ${form.formMessage}\n**Options :** ${form.options.join(', ')}\n**Salon de publication :** <#${form.postChannelId}>\n**Salon des logs :** <#${form.logChannelId}>`, 
                        inline: false 
                    }
                );
            });
        }

        embed.setTimestamp()
            .setFooter({ text: 'Voici la liste des formulaires' });

        // Envoyer l'embed
        message.channel.send({ embeds: [embed] });
    }
};
