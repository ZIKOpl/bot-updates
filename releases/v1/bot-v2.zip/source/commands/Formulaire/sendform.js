const { ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, ButtonStyle, ComponentType } = require('discord.js');

module.exports = {
    name: "sendform",
    description: "Envoie le formulaire configuré.",
    usages: "sendform <formId>",

    run: async (client, message, args) => {
        if (!args[0]) {
            return message.channel.send("Veuillez fournir l'ID du formulaire que vous souhaitez envoyer.");
        }

        const guildId = message.guild.id;
        const forms = client.db.get(`forms_${guildId}`) || [];
        const form = forms.find(f => f.id === args[0]);

        if (!form) {
            return message.channel.send("Formulaire introuvable.");
        }

        const postChannel = message.guild.channels.cache.get(form.postChannelId);
        const logChannel = message.guild.channels.cache.get(form.logChannelId);

        if (!postChannel) {
            return message.channel.send("Le salon pour le formulaire est introuvable.");
        }

        if (!logChannel) {
            return message.channel.send("Le salon de logs est introuvable. Assurez-vous que l'ID est correct et que le bot a les permissions nécessaires.");
        }

        // Créer le bouton pour ouvrir le formulaire
        const button = new ButtonBuilder()
            .setCustomId('open_form')
            .setLabel(form.buttonText || 'Ouvrir le formulaire')  // Vérification du texte du bouton
            .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder().addComponents(button);

        // Créer l'embed pour le formulaire
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle(form.title || 'Formulaire')  // Titre par défaut si manquant
            .setDescription(form.formMessage || 'Veuillez remplir le formulaire ci-dessous.')
            .setTimestamp();

        await postChannel.send({ embeds: [embed], components: [row] });
        message.channel.send("Le formulaire a été envoyé avec succès !");

        // Gestion des interactions avec le bouton
        const filter = i => i.customId === 'open_form';
        const collector = postChannel.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 900000 }); // 15 minutes

        collector.on('collect', async i => {
            // Assurez-vous que l'interaction n'a pas déjà été reconnue ou différée
            if (i.replied || i.deferred) {
                return;
            }

            try {
                // Créer le modal
                const modal = new ModalBuilder()
                    .setCustomId('response_modal')
                    .setTitle('Répondez aux questions');

                // Ajout des questions dans le modal
                form.options.forEach((option, index) => {
                    const label = typeof option === 'string' && option.trim() && option.length <= 45
                        ? option.trim()
                        : `Question ${index + 1}`;

                    const textInput = new TextInputBuilder()
                        .setCustomId(`response_input_${index}`)
                        .setLabel(`Question: ${label}`)
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('Entrez votre réponse ici')
                        .setRequired(true);

                    const actionRow = new ActionRowBuilder().addComponents(textInput);
                    modal.addComponents(actionRow);
                });

                // Afficher le modal
                await i.showModal(modal);

            } catch (error) {
                console.error("Erreur lors de l'affichage du modal :", error);
                if (!i.replied) {
                    await i.reply({ content: "Une erreur s'est produite lors de l'affichage du formulaire.", ephemeral: true });
                }
            }
        });

        collector.on('end', async collected => {
            if (collected.size === 0) {
                await postChannel.send("Le formulaire a expiré. Veuillez cliquer sur le bouton ci-dessous pour rouvrir le formulaire.");
                const retryButton = new ButtonBuilder()
                    .setCustomId('retry_form')
                    .setLabel('Réessayer')
                    .setStyle(ButtonStyle.Primary);

                const retryRow = new ActionRowBuilder().addComponents(retryButton);
                await postChannel.send({ components: [retryRow] });
            }
        });

        // Gestion des soumissions de modal
        client.on('interactionCreate', async interaction => {
            try {
                if (!interaction.isModalSubmit()) return;

                if (interaction.customId === 'response_modal') {
                    const responses = [];
                    form.options.forEach((option, index) => {
                        const response = interaction.fields.getTextInputValue(`response_input_${index}`);
                        responses.push(`**${option}**: ${response}`);
                    });

                    const userMention = interaction.user.toString();

                    const logChannel = message.guild.channels.cache.get(form.logChannelId);
                    if (logChannel) {
                        const logEmbed = new EmbedBuilder()
                            .setColor(client.color)
                            .setTitle(`Réponses au Formulaire: ${form.title}`)
                            .setDescription(`Réponses soumises par ${userMention}:\n${responses.join('\n')}`)
                            .setTimestamp();

                        await logChannel.send({ embeds: [logEmbed] });
                    } else {
                        console.error("Salon de logs introuvable. Vérifiez l'ID du salon de logs.");
                        await interaction.reply({ content: "Erreur lors de l'envoi des logs. Salon de logs introuvable.", ephemeral: true });
                        return;
                    }

                    await interaction.reply({ content: "Vos réponses ont été envoyées avec succès !", ephemeral: true });
                }
            } catch (error) {
                console.error("Erreur lors de la soumission du modal :", error);
                if (!interaction.replied) {
                    await interaction.reply({ content: "Une erreur s'est produite lors du traitement de votre réponse.", ephemeral: true });
                }
            }
        });
    }
};
