const Discord = require('discord.js');

module.exports = {
    name: '8ball',
    description: "Pose une question au bot.",
    /**
     * 
     * @param {Astroia} client 
     * @param {Message} message 
     * @param {string[]} args 
     */
    run: async (client, message, args) => {
        let pass = false;
        const staff = client.staff;

        // Vérification des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permLevel = client.db.get(`perm_8ball.${message.guild.id}`);
            if (permLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            return message.reply(client.noperm || 'Vous n\'avez pas la permission d\'exécuter cette commande.');
        }

        const responses = [
            "C'est certain.",
            "C'est décidément ainsi.",
            "Sans aucun doute.",
            "Oui, absolument.",
            "Tu peux compter dessus.",
            "Comme je le vois, oui.",
            "Probablement.",
            "Oui.",
            "Les signes pointent vers le oui.",
            "Mieux vaut ne pas te le dire maintenant.",
            "Je ne peux pas prédire maintenant.",
            "Ne compte pas là-dessus.",
            "Ma réponse est non.",
            "Mes sources disent non.",
            "D'après le wiki de google, non.",
            "Très douteux.",
            "._."
        ];

        const question = args.join(" ");
        if (!question) {
            return message.reply("Demande-moi quelque chose.");
        }

        const randomIndex = Math.floor(Math.random() * responses.length);
        const response = responses[randomIndex];
        message.reply(`${response}`);
    }
};
