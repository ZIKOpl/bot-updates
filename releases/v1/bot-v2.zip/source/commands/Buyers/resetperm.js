const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "resetperms",
    description: "Permet de réinitialiser toutes les permissions",
    category: "botcontrol",
    usage: ["resetperms"],
    /**
     * 
     * @param {bot} client 
     * @param {Discord.Message} message 
     * @param {Array<>} args 
     * @param {*} color 
     * @param {*} prefix 
     * @param {*} footer 
     * @param {string} commandName 
     */
    run: async (client, message, args, commandName) => {

        if (!client.config.buyers.includes(message.author.id)) {
            return message.channel.send(await client.lang(`resetperms.perm`));
        }

        // Création des boutons pour confirmer ou annuler la réinitialisation
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirmReset')
                    .setLabel('✅')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('cancelReset')
                    .setLabel('❌')
                    .setStyle(ButtonStyle.Secondary)
            );

        // Envoyer le message avec les boutons
        const resetMessage = await message.channel.send({
            content: "Es-tu sûr de vouloir réinitialiser toutes les permissions ?",
            components: [row]
        });

        // Création du collecteur de boutons
        const filter = i => ['confirmReset', 'cancelReset'].includes(i.customId) && i.user.id === message.author.id;
        const collector = resetMessage.createMessageComponentCollector({ filter, time: 15000 });

        collector.on('collect', async i => {
            if (i.customId === 'confirmReset') {
                // Réinitialisation des permissions en supprimant les clés du système
                await resetPermissions(client, message.guild.id);
                
                // Mise à jour du message pour montrer la confirmation
                await i.update({ content: "✅ Toutes les permissions ont été réinitialisées avec succès.", components: [] });
            } else if (i.customId === 'cancelReset') {
                // Annulation de l'action et mise à jour du message
                await i.update({ content: "❌ Réinitialisation des permissions annulée.", components: [] });
            }
        });

        collector.on('end', async collected => {
            if (!collected.size) {
                resetMessage.edit({ content: "⏲️ Temps écoulé. Réinitialisation annulée.", components: [] });
            }
        });
    }
}

/**
 * Fonction pour réinitialiser toutes les permissions en les supprimant de la base de données.
 * @param {bot} client 
 * @param {string} guildId 
 */
async function resetPermissions(client, guildId) {
    // Supprime toutes les permissions pour les tickets, giveaways et les autres permissions personnalisées
    await client.db.delete(`perm_ticket.${guildId}`);
    await client.db.delete(`perm_giveaway.${guildId}`);
    await client.db.delete(`perm1.${guildId}`);
    await client.db.delete(`perm2.${guildId}`);
    await client.db.delete(`perm3.${guildId}`);
    await client.db.delete(`perm4.${guildId}`);
    await client.db.delete(`perm5.${guildId}`);
}
