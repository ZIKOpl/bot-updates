const Discord = require('discord.js');
const { bot } = require('../../structures/client');

module.exports = {
    name: "setperm",
    description: "Configurer les permissions pour un rôle donné",
    usage: "setperm <perm1/2/3/4/5> <@role>",
    run: async(client, message, args, commandName) => {

        if (!client.config.buyers.includes(message.author.id)) {
            return message.channel.send(await client.lang(`setperm.perm`));
        }

        // Récupération des permissions actuelles
        let perm_1 = client.db.get(`perm1.${message.guild.id}`);
        let perm_2 = client.db.get(`perm2.${message.guild.id}`);
        let perm_3 = client.db.get(`perm3.${message.guild.id}`);
        let perm_4 = client.db.get(`perm4.${message.guild.id}`);
        let perm_5 = client.db.get(`perm5.${message.guild.id}`);

        // Définir les permissions valides
        let valid_perms = ["perm1", "perm2", "perm3", "perm4", "perm5"];
        let perm_to_edit = args[0];
        let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);

        if (!valid_perms.includes(perm_to_edit)) {
            return message.channel.send(await client.lang(`setperm.invalide-perm`));
        }

        if (!role) {
            return message.channel.send(await client.lang(`setperm.invalide-role`));
        }

        // Récupérer la liste des rôles pour la permission donnée
        let current_perms = client.db.get(`${perm_to_edit}.${message.guild.id}`);
        if (!Array.isArray(current_perms)) current_perms = [];

        if (current_perms.includes(role.id)) {
            // Si le rôle existe déjà, le retirer
            client.db.set(`${perm_to_edit}.${message.guild.id}`, current_perms.filter(r => r !== role.id));
            return message.channel.send(await client.lang(`setperm.role`) + ` \`\`${role.name}\`\` ` + await client.lang(`setperm.perm-remove`));
        } else {
            // Si le rôle n'existe pas, l'ajouter
            client.db.push(`${perm_to_edit}.${message.guild.id}`, role.id);
            return message.channel.send(await client.lang(`setperm.role`) + ` \`\`${role.name}\`\` ` + await client.lang(`setperm.perm-add`));
        }
    }
};
