const Discord = require('discord.js');
const Astroia = require('../../structures/client/index');

module.exports = {
    name: "sethelp",
    description: "Permet de définir le type de message d'aide (`boutton`, `onepage` ou `menu`).",
    aliases: ["setuphelp"],
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {string[]} args
     * @param {string} commandName
     * 
     **/
    run: async (client, message, args, commandName) => {
        // Vérification des permissions
        let hasPermission = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            const permissionLevel = client.db.get(`perm_${commandName}.${message.guild.id}`);
            if (permissionLevel) {
                const rolePermissions = client.db.get(`perm${permissionLevel}.${message.guild.id}`) || [];
                hasPermission = message.member.roles.cache.some(r => rolePermissions.includes(r.id));
            } else {
                hasPermission = client.db.get(`perm_${commandName}.${message.guild.id}`) === "public";
            }
        } else {
            hasPermission = true;
        }

        if (!hasPermission) {
            return message.channel.send(client.noperm || 'Vous n\'avez pas la permission d\'utiliser cette commande.');
        }

        // Validation du type d'aide
        const helpType = args[0];

        if (!helpType || (helpType !== 'boutton' && helpType !== 'onepage' && helpType !== 'menu')) {
            return message.channel.send('Veuillez mentionner un type d\'aide valide: `boutton`, `onepage` ou `menu`.');
        }

        // Mise à jour du type d'aide dans la base de données
        client.db.set(`sethelp_${message.guild.id}`, helpType);
        
        // Confirmation
        message.channel.send(`Le mode d'aide a été modifié en \`${helpType}\`.`);
    }
};
