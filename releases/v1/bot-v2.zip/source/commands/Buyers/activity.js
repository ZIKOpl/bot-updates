const Astroia = require('../../structures/client/index');
const db = require('quick.db');
const Discord = require('discord.js');

module.exports = {
    name: 'activity',
    usage: 'activity [type activiter] [ton status]',
    description: 'Changer le statut du bot',
    /**
     * 
     * @param {Astroia} client 
     * @param {Discord.Message} message
     * @param {Discord.args} args
     */
    run: async (client, message, args, commandName) => {
        let staff = client.staff;
        let pass = false;

        // Vérification des permissions du membre
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return; 
            }
        }

        // Paramètres du bot
        const prefix = client.config.prefix;
        const activityType = args[0];
        const activityName = args.slice(1).join(' ');
        const presence = client.db.get('presence');
        let activity;

        // Vérifie si l'activité demandée est valide
        if (!activityType || !activityName) {
            const messages = await client.lang('activity.invalide');
            const messagesss = messages.replaceAll("{prefix}", `\`${prefix}`);
            return message.channel.send({ content: messagesss, allowedMentions: { repliedUser: false } });
        }

        // Définir l'activité en fonction du type
        if (activityType === 'playto' || activityType === 'play') {
            client.user.setPresence({
                activities: [{ name: activityName, type: Discord.ActivityType.Playing }],
                status: presence
            });
            activity = { name: activityName, type: 'PLAYING' };
        } else if (activityType === 'watch') {
            client.user.setPresence({
                activities: [{ name: activityName, type: Discord.ActivityType.Watching }],
                status: presence
            });
            activity = { name: activityName, type: 'WATCHING' };
        } else if (activityType === 'listen') {
            client.user.setPresence({
                activities: [{ name: activityName, type: Discord.ActivityType.Listening }],
                status: presence
            });
            activity = { name: activityName, type: 'LISTENING' };
        } else if (activityType === 'stream') {
            // Vérifier que l'URL est bien une URL valide de stream
            const streamURL = "https://www.twitch.tv/discord"; // Remplace par une URL valide
            client.user.setPresence({
                activities: [{ name: activityName, type: Discord.ActivityType.Streaming, url: streamURL }],
                status: presence
            });
            activity = { name: activityName, type: 'STREAMING', url: streamURL };
        } else {
            const messages = await client.lang('activity.invalide');
            const messagesss = messages.replaceAll("{prefix}", `\`${prefix}`);
            return message.channel.send({ content: messagesss, allowedMentions: { repliedUser: false } });
        }

        // Sauvegarder l'activité dans la base de données
        await db.set('nomstatut', activity.name);
        await db.set('type', activity.type);

        // Envoyer un message de confirmation
        const reponse = (await client.lang('activity.set'))
            .replace("{activityType}", `\`${activityType}\``)
            .replace("{activityName}", `\`${activityName}\``);
        await message.channel.send({ content: reponse, allowedMentions: { repliedUser: false } });

        // Actualiser le statut toutes les 30 secondes pour éviter les réinitialisations
        setInterval(() => {
            client.user.setPresence({
                activities: [{ name: activityName, type: Discord.ActivityType.Streaming, url: "https://www.twitch.tv/discord" }],
                status: presence
            });
        }, 10000); // 30 secondes
    }
};
