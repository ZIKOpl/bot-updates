const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");
const { EmbedBuilder } = require("discord.js");
const AdmZip = require("adm-zip"); // pour extraire le zip

module.exports = {
    name: "update",
    description: "Met à jour le bot à la dernière version",
    run: async (client, message) => {
        const updateEmbed = new EmbedBuilder()
            .setTitle("🔄 Mise à jour du bot")
            .setDescription("Vérification des mises à jour...")
            .setColor("#FFA500");

        const msg = await message.channel.send({ embeds: [updateEmbed] });

        try {
            const res = await axios.post(`http://81.254.194.142:3002/api/version`, { version: client.version });

            if (!res.data.update) {
                updateEmbed
                    .setDescription(`✅ ${res.data.message}`)
                    .setColor("#00FF00");
                return msg.edit({ embeds: [updateEmbed] });
            }

            updateEmbed
                .setDescription(`📦 Nouvelle version disponible : **${res.data.newVersion}**\nTéléchargement en cours...`)
                .setColor("#FFFF00");
            await msg.edit({ embeds: [updateEmbed] });

            const zipPath = path.join(__dirname, "update.zip");
            const writer = fs.createWriteStream(zipPath);

            // 🔹 Téléchargement du ZIP
            const response = await axios({
                url: res.data.downloadUrl,
                method: "GET",
                responseType: "stream"
            });

            response.data.pipe(writer);

            writer.on("finish", async () => {
                updateEmbed.setDescription("📂 Extraction des fichiers...").setColor("#00BFFF");
                await msg.edit({ embeds: [updateEmbed] });

                const zip = new AdmZip(zipPath);
                zip.extractAllTo(path.join(__dirname, "../../"), true);

                fs.unlinkSync(zipPath); // supprime le zip après extraction

                updateEmbed.setDescription("♻️ Redémarrage du bot...").setColor("#00FF00");
                await msg.edit({ embeds: [updateEmbed] });

                // 🔁 Redémarre automatiquement le bot
                exec("pm2 restart all", (err) => {
                    if (err) console.error(err);
                });
            });
        } catch (err) {
            console.error(err);
            updateEmbed.setDescription("❌ Erreur lors de la mise à jour.").setColor("#FF0000");
            msg.edit({ embeds: [updateEmbed] });
        }
    }
};
