const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'afk',
    description: 'Permet de mettre un utilisateur en mode AFK avec une raison.',
    usage: "afk <raison>",

    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Système de permissions : vérifier si l'utilisateur a le droit d'utiliser cette commande
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            // Vérification des permissions selon les rôles
            const permLevel = client.db.get(`perm_afk.${message.guild.id}`);
            if (permLevel === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (permLevel === "public") pass = true;
        } else {
            pass = true;
        }

        if (!pass) {
            // Si l'utilisateur n'a pas les permissions nécessaires, retourner un message d'erreur
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Récupérer la raison donnée par l'utilisateur, ou "Non spécifiée" si rien n'est fourni
        const reason = args.join(' ') || 'Non spécifiée';

        // Sauvegarder l'état AFK et la raison dans la base de données
        client.db.set(`afk_${message.author.id}`, reason);

        // Créer un embed pour informer que l'utilisateur est en mode AFK
        const embed = new EmbedBuilder()
            .setTitle('Mode AFK activé')
            .setDescription(`${message.author} est maintenant AFK.`) // Pinge l'utilisateur
            .addFields({ name: 'Raison', value: reason })
            .setColor(client.color);

        // Répondre avec l'embed
        return message.channel.send({ embeds: [embed] });
    }
};
