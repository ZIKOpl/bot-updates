const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType } = require('discord.js');

module.exports = {
  name: "suggest",
  description: "Permet aux utilisateurs d’envoyer une suggestion.",
  run: async (client, message, args) => {
        // Vérification des permissions
        let pass = false;
        const staff = client.staff;

        if (!staff.includes(message.author.id) && 
            !client.config.buyers.includes(message.author.id) && 
            client.db.get(`owner_${message.author.id}`) !== true) {
            const perms = client.db.get(`perm_${commandName}.${message.guild.id}`);
            if (perms === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (perms === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (perms === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (perms === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (perms === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (perms === "public") pass = true;
        } else pass = true;

        // Si l'utilisateur n'a pas la permission, on arrête la commande
        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Récupération des salons configurés pour chaque type de suggestion
        let acceptedChannelId = client.db.get(`suggestions_channel_accepted_${message.guild.id}`) || 'Non configuré';
        let rejectedChannelId = client.db.get(`suggestions_channel_rejected_${message.guild.id}`) || 'Non configuré';
        let pendingChannelId = client.db.get(`suggestions_channel_pending_${message.guild.id}`) || 'Non configuré';

        // Crée l'embed pour la sélection
        const embed = new EmbedBuilder()
            .setTitle('Configuration des suggestions')
            .setColor(client.color)
            .setFooter(client.footer)
            .setDescription(`Choisissez le type de suggestions pour lequel vous souhaitez définir un salon :
            
            **Suggestion Acceptée** : ${acceptedChannelId === 'Non configuré' ? 'Non configuré' : `<#${acceptedChannelId}>`}
            **Suggestion Refusée** : ${rejectedChannelId === 'Non configuré' ? 'Non configuré' : `<#${rejectedChannelId}>`}
            **Suggestion En attente** : ${pendingChannelId === 'Non configuré' ? 'Non configuré' : `<#${pendingChannelId}>`}`);

        // Crée le Select Menu
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('select_suggestion_type')
            .setPlaceholder('Choisissez un type de suggestion')
            .addOptions([
                {
                    label: 'Suggestion acceptée',
                    value: 'accepted',
                    description: 'Choisissez un salon pour les suggestions acceptées.'
                },
                {
                    label: 'Suggestion refusée',
                    value: 'rejected',
                    description: 'Choisissez un salon pour les suggestions refusées.'
                },
                {
                    label: 'Suggestion en attente',
                    value: 'pending',
                    description: 'Choisissez un salon pour les suggestions en attente.'
                },
                {
                    label: 'Réinitialiser les suggestions',
                    value: 'reset',
                    description: 'Réinitialiser toutes les configurations de suggestions.'
                }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        // Envoie l'embed avec le Select Menu
        const messageEmbed = await message.channel.send({ embeds: [embed], components: [row] });

        // Gestion des interactions avec le Select Menu
        const filter = (interaction) => interaction.customId === 'select_suggestion_type' && interaction.user.id === message.author.id;
        const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async (interaction) => {
            const selectedOption = interaction.values[0];

            if (selectedOption === 'reset') {
                // Réinitialisation des configurations de suggestions
                client.db.delete(`suggestions_channel_accepted_${message.guild.id}`);
                client.db.delete(`suggestions_channel_rejected_${message.guild.id}`);
                client.db.delete(`suggestions_channel_pending_${message.guild.id}`);

                acceptedChannelId = 'Non configuré';
                rejectedChannelId = 'Non configuré';
                pendingChannelId = 'Non configuré';

                // Met à jour l'embed initial
                embed.setDescription(`Choisissez le type de suggestions pour lequel vous souhaitez définir un salon :
                
**Suggestion Acceptée** : Non configuré
**Suggestion Refusée** : Non configuré
**Suggestion En attente** : Non configuré`);
                
                return messageEmbed.edit({ embeds: [embed] });
            }

            // Crée un modal pour demander l'ID du salon
            const modal = new ModalBuilder()
                .setCustomId(`set_channel_${selectedOption}`)
                .setTitle('Définir le salon')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('channel_id')
                            .setLabel('Entrez l\'ID du salon textuel')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder('123456789012345678')
                            .setRequired(true)
                    )
                );

            await interaction.showModal(modal);
        });

        client.on('interactionCreate', async (interaction) => {
            if (interaction.type === InteractionType.ModalSubmit && interaction.customId.startsWith('set_channel_')) {
                const suggestionType = interaction.customId.split('_')[2];
                const channelId = interaction.fields.getTextInputValue('channel_id');

                const channel = message.guild.channels.cache.get(channelId);
                if (!channel || channel.type !== 0) { // Vérifie que c'est un salon textuel
                    return interaction.reply({ content: 'Salon invalide. Assurez-vous d\'entrer un ID de salon textuel.', ephemeral: true });
                }

                // Enregistrement dans la base de données en fonction du type de suggestion
                client.db.set(`suggestions_channel_${suggestionType}_${message.guild.id}`, channelId);

                // Met à jour les variables locales et l'embed avec la nouvelle configuration
                if (suggestionType === 'accepted') acceptedChannelId = channelId;
                if (suggestionType === 'rejected') rejectedChannelId = channelId;
                if (suggestionType === 'pending') pendingChannelId = channelId;

                embed.setDescription(`Choisissez le type de suggestions pour lequel vous souhaitez définir un salon :
                
**Suggestion Acceptée** : ${acceptedChannelId === 'Non configuré' ? 'Non configuré' : `<#${acceptedChannelId}>`}
**Suggestion Refusée** : ${rejectedChannelId === 'Non configuré' ? 'Non configuré' : `<#${rejectedChannelId}>`}
**Suggestion En attente** : ${pendingChannelId === 'Non configuré' ? 'Non configuré' : `<#${pendingChannelId}>`}`);

                await messageEmbed.edit({ embeds: [embed] });

                // On n'envoie pas de réponse de confirmation pour que l'embed principal soit simplement mis à jour.
                return;
            }
        });
    }
};
