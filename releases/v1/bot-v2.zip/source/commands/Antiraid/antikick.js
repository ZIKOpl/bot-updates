const Discord = require('discord.js');

module.exports = {
    name: "antikick",
    description: "Permet d'activer ou de désactiver l'antikick, et de définir les sanctions pour les kicks",
    category: "antiraid",
    usages: "antikick <on/off> | antikick <kick> <derank/kick/ban>",

    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Vérifier les permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_antikick.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antikick.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antikick.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antikick.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antikick.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antikick.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Récupérer les données de l'antikick depuis la base de données
        const antikickData = client.db.get(`antikick_${message.guild.id}`) || {
            status: 'off',
            sanction: 'none',
        };

        // Traitement des arguments pour activer ou désactiver l'antikick
        if (args[0] === "on") {
            antikickData.status = "on";
            await client.db.set(`antikick_${message.guild.id}`, antikickData);
            return message.channel.send(`L'antikick est désormais activé.`);
        }

        if (args[0] === "off") {
            antikickData.status = "off";
            await client.db.set(`antikick_${message.guild.id}`, antikickData);
            return message.channel.send(`L'antikick est désormais désactivé.`);
        }

        // Traitement des arguments pour configurer les sanctions
        if (args[0] === "sanction") {
            const sanction = args[1];

            if (["derank", "kick", "ban"].includes(sanction)) {
                antikickData.sanction = sanction;
                await client.db.set(`antikick_${message.guild.id}`, antikickData);
                return message.channel.send(`Sanction pour kick définie sur \`${sanction}\`.`);
            } else {
                return message.channel.send(`Sanction invalide. Les sanctions possibles sont : derank, kick, ban.`);
            }
        }

        // Afficher l'utilisation correcte en cas d'erreur
        const usageWithPrefix = client.commands.get("antikick").usages.map(use => `\`${client.prefix}${use}\``).join("\n");
        return message.channel.send(`Utilisation incorrecte, utilisations possibles : \n${usageWithPrefix}`);
    }
};
