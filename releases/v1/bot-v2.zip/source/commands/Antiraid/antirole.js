const Discord = require('discord.js');

module.exports = {
    name: "antirole",
    description: "Permet d'activer, désactiver l'antirole et de définir une sanction pour toutes les actions.",
    category: "antiraid",
    usage: "antirole <on/off> | antirole sanction <derank/kick/ban/Aucune>",

    run: async (client, message, args) => {
        let pass = false;
        let staff = client.staff;

        // Vérifier les permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_antirole.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antirole.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antirole.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antirole.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antirole.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_antirole.${message.guild.id}`) === "public") pass = true;
        } else pass = true;

        if (!pass) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        // Récupérer les données de l'antirole depuis la base de données
        const antiroleData = client.db.get(`antirole_${message.guild.id}`) || {
            status: 'off',
            sanction: 'aucune',
        };

        // Activer ou désactiver l'antirole
        if (args[0] === "on") {
            antiroleData.status = "on";
            antiroleData.sanction = antiroleData.sanction === 'aucune' ? 'derank' : antiroleData.sanction;
            await client.db.set(`antirole_${message.guild.id}`, antiroleData);
            return message.channel.send(`L'antirole est désormais activé avec la sanction par défaut : \`${antiroleData.sanction}\` pour la création, la mise à jour et la suppression de rôles.`);
        }

        if (args[0] === "off") {
            antiroleData.status = "off";
            await client.db.set(`antirole_${message.guild.id}`, antiroleData);
            return message.channel.send(`L'antirole est désormais désactivé.`);
        }

        // Définir la sanction pour toutes les actions (création, mise à jour, suppression)
        if (args[0] === "sanction") {
            const sanction = args[1] ? args[1].toLowerCase() : null;
            if (sanction && ["derank", "kick", "ban", "aucune"].includes(sanction)) {
                antiroleData.sanction = sanction;
                await client.db.set(`antirole_${message.guild.id}`, antiroleData);
                return message.channel.send(`La sanction pour la création, la mise à jour et la suppression de rôles est désormais définie sur \`${sanction}\`.`);
            } else {
                return message.channel.send(`Sanction invalide ou manquante. Les sanctions possibles sont : \`derank\`, \`kick\`, \`ban\`, \`Aucune\`.`);
            }
        }

        // Afficher l'utilisation correcte en cas d'erreur
        return message.channel.send(`Utilisation incorrecte, utilisez : \`${client.prefix}antirole <on/off>\` ou \`${client.prefix}antirole sanction <derank/kick/ban/Aucune>\``);
    }
};
