const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    name: 'leaderboard',
    description: 'Affiche le classement des membres en fonction du nombre de messages, invitations ou du temps vocal.',
    usage: "leaderboard Message/Vocal/Invite",
    run: async (client, message, args, commandName) => {
        let pass = false;
        let staff = client.staff;

        // Gestion des permissions
        if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
            if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
        } else {
            pass = true;
        }

        if (pass === false) {
            if (client.noperm && client.noperm.trim() !== '') {
                return message.channel.send(client.noperm);
            } else {
                return;
            }
        }

        const guildId = message.guild.id;

        // Classement par messages
        if (['message', 'msg', 'mess', 'messages'].includes(args[0])) {
            const leaderboard = [];

            message.guild.members.cache.forEach(member => {
                const userId = member.user.id;
                const messageCount = client.db.get(`message_${guildId}_${userId}`) || 0;

                leaderboard.push({ id: userId, messages: messageCount });
            });

            leaderboard.sort((a, b) => b.messages - a.messages);

            let leaderboardMessage = '';

            for (let i = 0; i < leaderboard.length && i < 20; i++) {
                const member = await client.users.fetch(leaderboard[i].id);
                leaderboardMessage += `[ ${i + 1} ] ${member.tag} - ${leaderboard[i].messages} messages\n`;
            }

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('LeaderBoard Messages')
                .setDescription('```yml\n' + leaderboardMessage + '```')
                .setFooter(client.footer);

            // Ajouter les boutons Reset All et Reset User
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('reset_all_messages')
                    .setLabel('Reset All')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('reset_user_messages')
                    .setLabel('Reset Utilisateur')
                    .setStyle(ButtonStyle.Primary)
            );

            const msg = await message.channel.send({ embeds: [embed], components: [row] });

            // Créer un collector pour gérer les interactions des boutons
            handleCollector(client, message, msg, guildId, 'messages');
        }

        // Classement par invitations
        if (['inv', 'invite', 'invites'].includes(args[0])) {
            const leaderboard = [];

            message.guild.members.cache.forEach(member => {
                const userId = member.user.id;
                const invitesData = client.db.get(`invites_${userId}_${guildId}`);

                if (invitesData) {
                    const totalInvites = invitesData.total || 0;
                    leaderboard.push({ id: userId, invites: totalInvites });
                }
            });

            leaderboard.sort((a, b) => b.invites - a.invites);

            let leaderboardMessage = '';

            for (let i = 0; i < leaderboard.length && i < 20; i++) {
                const member = await client.users.fetch(leaderboard[i].id);
                leaderboardMessage += `[ ${i + 1} ] ${member.tag} - ${leaderboard[i].invites} invitations\n`;
            }

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('LeaderBoard Invitations')
                .setDescription('```yml\n' + (leaderboardMessage || "Aucune invitation") + '```')
                .setFooter(client.footer);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('reset_all_invites')
                    .setLabel('Reset All')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('reset_user_invites')
                    .setLabel('Reset Utilisateur')
                    .setStyle(ButtonStyle.Primary)
            );

            const msg = await message.channel.send({ embeds: [embed], components: [row] });

            // Créer un collector pour gérer les interactions des boutons
            handleCollector(client, message, msg, guildId, 'invites');
        }

        // Classement par temps vocal
        if (['vocal', 'voc', 'vocals'].includes(args[0])) {
            const leaderboard = [];

            message.guild.members.cache.forEach(member => {
                const userId = member.user.id;
                const vocalTime = client.db.get(`vocal_${guildId}_${userId}`) || 0;

                leaderboard.push({ id: userId, vocal: vocalTime });
            });

            leaderboard.sort((a, b) => b.vocal - a.vocal);

            let leaderboardMessage = '';

            for (let i = 0; i < leaderboard.length && i < 20; i++) {
                const member = await client.users.fetch(leaderboard[i].id);
                leaderboardMessage += `[ ${i + 1} ] ${member.tag} - Vocal: ${formatTime(leaderboard[i].vocal)}\n`;
            }

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('LeaderBoard Vocaux')
                .setDescription('```yml\n' + leaderboardMessage + '```')
                .setFooter(client.footer);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('reset_all_vocals')
                    .setLabel('Reset All')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('reset_user_vocals')
                    .setLabel('Reset Utilisateur')
                    .setStyle(ButtonStyle.Primary)
            );

            const msg = await message.channel.send({ embeds: [embed], components: [row] });

            // Créer un collector pour gérer les interactions des boutons
            handleCollector(client, message, msg, guildId, 'vocal');
        }

        // Fonction de formatage du temps vocal
        function formatTime(temps) {
            let time;
            if (temps < 60) {
                time = `${temps} secondes`;
            } else if (temps < 3600) {
                const minutes = Math.floor(temps / 60);
                const seconds = temps % 60;
                time = `${minutes} minute${minutes !== 1 ? 's' : ''} et ${seconds} seconde${seconds !== 1 ? 's' : ''}`;
            } else if (temps < 86400) {
                const heures = Math.floor(temps / 3600);
                const minutes = Math.floor((temps % 3600) / 60);
                time = `${heures} heure${heures !== 1 ? 's' : ''}, ${minutes} minute${minutes !== 1 ? 's' : ''}`;
            } else if (temps < 31536000) {
                const jours = Math.floor(temps / 86400);
                const heures = Math.floor((temps % 86400) / 3600);
                time = `${jours} jour${jours !== 1 ? 's' : ''}, ${heures} heure${heures !== 1 ? 's' : ''}`;
            } else {
                const ans = Math.floor(temps / 31536000);
                const jours = Math.floor((temps % 31536000) / 86400);
                time = `${ans} an${ans !== 1 ? 's' : ''}, ${jours} jour${jours !== 1 ? 's' : ''}`;
            }
            return time;
        }

        // Fonction de gestion des interactions
        function handleCollector(client, message, msg, guildId, type) {
            const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

            collector.on('collect', async interaction => {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: "Vous ne pouvez pas utiliser ce bouton.", ephemeral: true });
                }

                if (interaction.customId === `reset_all_${type}`) {
                    // Réinitialiser toutes les données
                    message.guild.members.cache.forEach(member => {
                        client.db.delete(`${type}_${guildId}_${member.user.id}`);
                    });
                    await interaction.reply({ content: `Toutes les données de ${type} ont été réinitialisées.`, ephemeral: true });
                }

                if (interaction.customId === `reset_user_${type}`) {
                    // Ouvrir un modal pour saisir l'utilisateur à réinitialiser
                    const modal = new ModalBuilder()
                        .setCustomId(`reset_user_modal_${type}`)
                        .setTitle('Reset Utilisateur');

                    const userIdInput = new TextInputBuilder()
                        .setCustomId('userIdInput')
                        .setLabel("ID de l'utilisateur")
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder("Entrez l'ID de l'utilisateur")
                        .setRequired(true);

                    const actionRow = new ActionRowBuilder().addComponents(userIdInput);
                    modal.addComponents(actionRow);

                    await interaction.showModal(modal);

                    client.once('interactionCreate', async (modalInteraction) => {
                        if (!modalInteraction.isModalSubmit()) return;

                        const userId = modalInteraction.fields.getTextInputValue('userIdInput');
                        const user = await client.users.fetch(userId).catch(() => null);

                        if (!user) {
                            return modalInteraction.reply({ content: 'Utilisateur non trouvé.', ephemeral: true });
                        }

                        client.db.delete(`${type}_${guildId}_${userId}`);
                        return modalInteraction.reply({ content: `Les données de ${type} de ${user.tag} ont été réinitialisées.`, ephemeral: true });
                    });
                }
            });

            collector.on('end', collected => {
                if (msg && msg.editable) {
                    msg.edit({ components: [] }); // Désactive les boutons après 1 minute
                }
            });
        }
    },
};
