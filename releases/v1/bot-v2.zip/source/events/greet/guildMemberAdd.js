const { Events, Message, TextChannel } = require('discord.js');

module.exports = {
    name: Events.GuildMemberAdd,
    /**
     * @param {import('discord.js').Client} client
     * @param {import('discord.js').GuildMember} member
     */
    run: async (client, member) => {
        // Récupérer les salons de ghost ping pour le serveur
        const ghostpingChannels = client.db.get(`ghostping_${member.guild.id}`) || [];

        for (const channelId of ghostpingChannels) {
            const channel = member.guild.channels.cache.get(channelId);

            if (channel instanceof TextChannel) {
                try {
                    // Envoyer un message de bienvenue avec un ping
                    const message = await channel.send(`Bienvenue ${member}!`);

                    // Supprimer le message après 3 secondes
                    setTimeout(() => {
                        message.delete().catch(() => {});
                    }, 3000);
                } catch (error) {
                    console.error(`Impossible d'envoyer un message dans le canal ${channelId} : ${error}`);
                }
            }
        }
    }
};
