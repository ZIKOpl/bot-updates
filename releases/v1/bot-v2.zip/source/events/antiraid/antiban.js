const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildBanAdd',
    run: async (client, ban) => {
        const guild = ban.guild;
        const user = ban.user;

        // Vérifiez si le bannissement est surveillé
        const antiban = client.db.get(`antiban_${guild.id}`);
        if (!antiban || antiban.status === 'off') return;

        // Fetch the audit logs to determine who banned the user
        let banCreator = null;
        try {
            const auditLogs = await guild.fetchAuditLogs({
                type: 22, // BAN_ADD action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                banCreator = entry.executor;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the ban creator is the bot or the guild owner
        if (banCreator.id === client.user.id || banCreator.id === guild.ownerId) return;

        // Check if the ban creator is whitelisted
        const whitelisted = client.db.get(`wl.${guild.id}`) || [];
        if (whitelisted.includes(banCreator.id)) {
            console.log(`L'utilisateur ${banCreator.tag} est en whitelist et ne sera pas sanctionné.`);
            return;
        }

        // Log if a user is banned
        console.log(`L'utilisateur ${user.tag} a été banni par ${banCreator.tag}.`);

        // Reinvite the user
        try {
            await guild.members.unban(user.id, 'Antiban - Réinsertion automatique après bannissement');
            console.log(`L'utilisateur ${user.tag} a été réinclus avec succès.`);
        } catch (error) {
            console.error('Erreur lors de la réinclusion de l\'utilisateur :', error);
        }

        // Log the action in the designated raid log channel if exists
        const logChannelId = client.db.get(`raidlogs_${guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Bannissement et Réinclusion')
                    .setDescription(`L'utilisateur **${user.tag}** a été banni par <@${banCreator.id}> et a été réinclus automatiquement.`)
                    .setColor(client.color) // Set a default color if none is provided
                    .setTimestamp()
                    .setFooter(client.footer || { text: 'Anti-Ban' });

                logChannel.send({ embeds: [embed] });
            }
        }

        // Optionally apply sanctions to the ban creator
        const sanction = antiban.sanction || 'none';
        const member = guild.members.resolve(banCreator.id);

        if (sanction === 'derank' && member) {
            try {
                const rolesToRemove = member.roles.cache.map(role => role.id);
                await member.roles.remove(rolesToRemove);
                console.log(`Tous les rôles ont été retirés pour ${member.user.tag}.`);
            } catch (error) {
                console.error('Erreur lors du retrait des rôles du membre :', error);
            }
        } else if (sanction === 'kick' && member) {
            try {
                await guild.members.kick(banCreator.id, 'Antiban - bannissement');
                console.log(`L'utilisateur ${banCreator.tag} a été expulsé pour le bannissement d\'un membre.`);
            } catch (error) {
                console.error('Erreur lors de l\'expulsion du membre :', error);
            }
        } else if (sanction === 'ban' && member) {
            try {
                await guild.bans.create(banCreator.id, { reason: 'Antiban - bannissement' });
                console.log(`L'utilisateur ${banCreator.tag} a été banni pour le bannissement d\'un membre.`);
            } catch (error) {
                console.error('Erreur lors du bannissement du membre :', error);
            }
        }
    }
};
