const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'channelUpdate',
    run: async (client, oldChannel, newChannel) => {
        // Vérifiez si la modification du salon est surveillée
        const antichannel = client.db.get(`antichannel_${newChannel.guild.id}`);
        if (!antichannel || antichannel.status === 'off') return;

        // Fetch the audit logs to determine who updated the channel
        let channelUpdater = null;
        try {
            const auditLogs = await newChannel.guild.fetchAuditLogs({
                type: 11, // CHANNEL_UPDATE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                channelUpdater = entry.executor;
            } else {
                console.log('Aucune entrée trouvée dans les logs d\'audit pour la mise à jour du salon.');
                return;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the updater is the bot or the guild owner
        if (channelUpdater.id === client.user.id || channelUpdater.id === newChannel.guild.ownerId) return;

        // Check if the updater is whitelisted
        const whitelisted = client.db.get(`wl.${newChannel.guild.id}`) || [];
        if (whitelisted.includes(channelUpdater.id)) {
            console.log(`L'utilisateur ${channelUpdater.tag} est en whitelist et ne sera pas sanctionné.`);
            return;
        }

        // Determine the sanction based on the configuration
        const sanction = antichannel.sanctionUpdate || 'none'; // Default to 'none' if not set

        // Check if the channel properties have changed
        const propertiesChanged = oldChannel.name !== newChannel.name ||
                                  oldChannel.topic !== newChannel.topic ||
                                  oldChannel.nsfw !== newChannel.nsfw ||
                                  oldChannel.bitrate !== newChannel.bitrate ||
                                  oldChannel.userLimit !== newChannel.userLimit ||
                                  oldChannel.parentId !== newChannel.parentId ||
                                  oldChannel.position !== newChannel.position ||
                                  !arePermissionOverwritesEqual(oldChannel.permissionOverwrites.cache, newChannel.permissionOverwrites.cache) ||
                                  oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser;

        if (propertiesChanged) {
            // Restore the channel to its previous state
            try {
                await newChannel.edit({
                    name: oldChannel.name,
                    topic: oldChannel.topic,
                    nsfw: oldChannel.nsfw,
                    bitrate: oldChannel.bitrate,
                    userLimit: oldChannel.userLimit,
                    parent: oldChannel.parent, // Catégorie
                    position: oldChannel.position,
                    permissionOverwrites: oldChannel.permissionOverwrites.cache.map(permissionOverwrite => ({
                        id: permissionOverwrite.id,
                        allow: permissionOverwrite.allow.bitfield,
                        deny: permissionOverwrite.deny.bitfield
                    })), // Règles de permission
                    rateLimitPerUser: oldChannel.rateLimitPerUser // Slowmode
                });
                console.log(`Le salon ${newChannel.name} a été restauré à son état précédent.`);
            } catch (error) {
                console.error('Erreur lors de la restauration du salon :', error);
            }

            // Appliquer la sanction si nécessaire
            if (sanction === 'derank') {
                const member = newChannel.guild.members.resolve(channelUpdater.id);
                if (member) {
                    try {
                        // Retirer tous les rôles du membre sauf @everyone
                        const rolesToRemove = member.roles.cache.filter(role => role.id !== newChannel.guild.roles.everyone.id).map(role => role.id);
                        await member.roles.remove(rolesToRemove);
                        console.log(`Tous les rôles ont été retirés pour ${member.user.tag}.`);

                        // Ajouter le rôle @everyone (si nécessaire)
                        const everyoneRole = newChannel.guild.roles.everyone;
                        if (everyoneRole && !member.roles.cache.has(everyoneRole.id)) {
                            await member.roles.add(everyoneRole.id);
                            console.log(`Le rôle @everyone a été ajouté pour ${member.user.tag}.`);
                        }
                    } catch (error) {
                        console.error('Erreur lors du retrait des rôles du membre :', error);
                    }
                } else {
                    console.error('Membre non trouvé pour le créateur ID:', channelUpdater.id);
                }
            } else if (sanction === 'kick') {
                try {
                    await newChannel.guild.members.kick(channelUpdater.id, 'Antichannel - modification de salon');
                    console.log(`L'utilisateur ${channelUpdater.tag} a été expulsé pour la modification de salon.`);
                } catch (error) {
                    console.error('Erreur lors de l\'expulsion du membre :', error);
                }
            } else if (sanction === 'ban') {
                try {
                    await newChannel.guild.bans.create(channelUpdater.id, { reason: 'Antichannel - modification de salon' });
                    console.log(`L'utilisateur ${channelUpdater.tag} a été banni pour la modification de salon.`);
                } catch (error) {
                    console.error('Erreur lors du bannissement du membre :', error);
                }
            } else {
                console.error(`Sanction non reconnue : ${sanction}`);
            }

            // Log the action if logging is enabled
            const logChannelId = client.db.get(`raidlogs_${newChannel.guild.id}`);
            if (logChannelId) {
                const logChannel = client.channels.cache.get(logChannelId);
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setTitle('Salon Modifié')
                        .setDescription(`Le salon ${newChannel.name} a été modifié par <@${channelUpdater.id}>. L'utilisateur a été ${sanction}.`)
                        .setColor(client.color || '#5a65ff')
                        .setTimestamp()
                        .setFooter(client.footer);

                    logChannel.send({ embeds: [embed] });
                } else {
                    console.error('Le canal de log est introuvable.');
                }
            }
        }
    }
};

// Fonction pour comparer les règles de permission
function arePermissionOverwritesEqual(oldOverwrites, newOverwrites) {
    if (oldOverwrites.size !== newOverwrites.size) return false;

    for (const [id, oldOverwrite] of oldOverwrites) {
        const newOverwrite = newOverwrites.get(id);
        if (!newOverwrite || oldOverwrite.deny.bitfield !== newOverwrite.deny.bitfield || oldOverwrite.allow.bitfield !== newOverwrite.allow.bitfield) {
            return false;
        }
    }
    return true;
}
