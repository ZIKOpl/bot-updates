const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'roleDelete',
    run: async (client, role) => {
        // Vérifiez si la suppression de rôle est surveillée
        const antirole = client.db.get(`antirole_${role.guild.id}`);
        if (!antirole || antirole.status === 'off') return;

        // Fetch the audit logs to determine who deleted the role
        let roleDeleter = null;
        try {
            const auditLogs = await role.guild.fetchAuditLogs({
                type: 32, // ROLE_DELETE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                roleDeleter = entry.executor;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the deleter is the bot or the guild owner
        if (roleDeleter.id === client.user.id || roleDeleter.id === role.guild.ownerId) return;

        // Check if the deleter is whitelisted
        const whitelisted = client.db.get(`wl.${role.guild.id}`) || [];
        if (whitelisted.includes(roleDeleter.id)) {
            console.log(`L'utilisateur ${roleDeleter.tag} est en whitelist et ne sera pas sanctionné.`);
            return;
        }

        // Log if a role is deleted
        console.log(`Le rôle ${role.name} a été supprimé par ${roleDeleter.tag}.`);

        // Recreate the role with the same permissions, position, etc.
        try {
            const recreatedRole = await role.guild.roles.create({
                name: role.name,
                color: role.color,
                hoist: role.hoist,
                permissions: role.permissions,
                mentionable: role.mentionable,
                position: role.rawPosition,
                reason: 'Antirole - Recréation automatique du rôle supprimé',
            });

            console.log(`Le rôle ${recreatedRole.name} a été recréé avec succès.`);

            // Log the recreation in the designated raid log channel if exists
            const logChannelId = client.db.get(`raidlogs_${role.guild.id}`);
            if (logChannelId) {
                const logChannel = client.channels.cache.get(logChannelId);
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setTitle('Rôle Supprimé et Recréé')
                        .setDescription(`Le rôle **${role.name}** a été supprimé par <@${roleDeleter.id}> et a été recréé automatiquement.`)
                        .setColor(client.color) // Set a default color if none is provided
                        .setTimestamp()
                        .setFooter(client.footer || { text: 'Anti-Role' });

                    logChannel.send({ embeds: [embed] });
                }
            }
        } catch (error) {
            console.error('Erreur lors de la recréation du rôle :', error);
        }

        // Optionally apply sanctions to the role deleter
        const sanction = antirole.deleteSanction || 'none';
        const member = role.guild.members.resolve(roleDeleter.id);

        if (sanction === 'derank' && member) {
            try {
                const rolesToRemove = member.roles.cache.map(role => role.id);
                await member.roles.remove(rolesToRemove);
                console.log(`Tous les rôles ont été retirés pour ${member.user.tag}.`);
            } catch (error) {
                console.error('Erreur lors du retrait des rôles du membre :', error);
            }
        } else if (sanction === 'kick' && member) {
            try {
                await role.guild.members.kick(roleDeleter.id, 'Antirole - suppression de rôle');
                console.log(`L'utilisateur ${roleDeleter.tag} a été expulsé pour la suppression de rôle.`);
            } catch (error) {
                console.error('Erreur lors de l\'expulsion du membre :', error);
            }
        } else if (sanction === 'ban' && member) {
            try {
                await role.guild.bans.create(roleDeleter.id, { reason: 'Antirole - suppression de rôle' });
                console.log(`L'utilisateur ${roleDeleter.tag} a été banni pour la suppression de rôle.`);
            } catch (error) {
                console.error('Erreur lors du bannissement du membre :', error);
            }
        }
    }
};
