const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'channelDelete',
    run: async (client, channel) => {
        // Vérifiez si la suppression du salon est surveillée
        const antichannel = await client.db.get(`antichannel_${channel.guild.id}`);
        if (!antichannel || antichannel.status === 'off') return;

        // Fetch the audit logs to determine who deleted the channel
        let channelDeleter = null;
        try {
            const auditLogs = await channel.guild.fetchAuditLogs({
                type: 12, // CHANNEL_DELETE action type
                limit: 1,
            });
            const entry = auditLogs.entries.first();
            if (entry) {
                channelDeleter = entry.executor;
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des logs d\'audit :', error);
            return;
        }

        // Skip if the deleter is the bot or the guild owner
        if (channelDeleter.id === client.user.id || channelDeleter.id === channel.guild.ownerId) return;

        // Check if the deleter is whitelisted
        const isWhitelisted = client.db.get(`wl.${channel.guild.id}`) || [];
        if (isWhitelisted.includes(channelDeleter.id)) return;

        // Recreate the channel
        try {
            let parentCategory = null;
            if (channel.parent) {
                parentCategory = channel.parent.id;
            }

            await channel.guild.channels.create({
                name: channel.name,
                type: channel.type,
                parent: parentCategory,
                position: channel.rawPosition,
            });
        } catch (error) {
            console.error('Erreur lors de la recréation du salon :', error);
            return;
        }

        // Determine the sanction based on the configuration
        const sanction = antichannel.sanction || 'none'; // Default to 'none' if not set

        // Apply the sanction
        if (sanction === 'derank') {
            const member = channel.guild.members.resolve(channelDeleter.id);
            if (member) {
                try {
                    // Retirer tous les rôles du membre
                    const rolesToRemove = member.roles.cache.map(role => role.id);
                    await member.roles.remove(rolesToRemove);
                    console.log(`Tous les rôles ont été retirés pour ${member.user.tag}.`);

                    // Ajouter le rôle @everyone (si nécessaire)
                    const everyoneRole = channel.guild.roles.everyone;
                    if (everyoneRole) {
                        try {
                            if (!member.roles.cache.has(everyoneRole.id)) {
                                await member.roles.add(everyoneRole.id);
                                console.log(`Le rôle @everyone a été ajouté pour ${member.user.tag}.`);
                            }
                        } catch (error) {
                            console.error('Erreur lors de l\'ajout du rôle @everyone :', error);
                        }
                    } else {
                        console.error('Le rôle @everyone n\'est pas trouvé sur le serveur.');
                    }
                } catch (error) {
                    console.error('Erreur lors du retrait des rôles du membre :', error);
                }
            } else {
                console.error('Membre non trouvé pour le déléteur ID:', channelDeleter.id);
            }
        } else if (sanction === 'kick') {
            try {
                await channel.guild.members.kick(channelDeleter.id, 'Antichannel - suppression de salon');
                console.log(`L'utilisateur ${channelDeleter.tag} a été expulsé pour la suppression de salon.`);
            } catch (error) {
                console.error('Erreur lors de l\'expulsion du membre :', error);
            }
        } else if (sanction === 'ban') {
            try {
                await channel.guild.bans.create(channelDeleter.id, { reason: 'Antichannel - suppression de salon' });
                console.log(`L'utilisateur ${channelDeleter.tag} a été banni pour la suppression de salon.`);
            } catch (error) {
                console.error('Erreur lors du bannissement du membre :', error);
            }
        } else {
            console.error(`Sanction non reconnue : ${sanction}`);
        }

        // Log the action if logging is enabled
        const logChannelId = client.db.get(`raidlogs_${channel.guild.id}`);
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Salon Supprimé')
                    .setDescription(`Le salon ${channel.name} a été supprimé par <@${channelDeleter.id}>. Le salon a été recréé et l'utilisateur a été ${sanction}.`)
                    .setColor(client.color) // Assurez-vous que la couleur est valide
                    .setTimestamp()
                    .setFooter(client.footer);

                logChannel.send({ embeds: [embed] });
            }
        }
    }
};
