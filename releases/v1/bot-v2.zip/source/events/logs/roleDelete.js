const Discord = require('discord.js');

module.exports = {
    name: 'roleDelete',
    run: async (client, role) => {
        const color = client.db.get(`color_${role.guild.id}`) || client.config.default_color;
        const guild = role.guild;
        if (!guild) return;

        const channel = client.db.get(`rolelog_${guild.id}`);
        if (!channel) return;

        const chan = guild.channels.cache.get(channel);
        if (!chan) return;

        const roleName = role.name;
        const roleId = role.id;
        const roleColor = role.hexColor;

        // Obtention des logs d'audit pour le créateur du rôle
        let creator = '[Inconnu](https://discord.com)';
        try {
            const auditLogs = await guild.fetchAuditLogs({ type: Discord.AuditLogEvent.RoleDelete, limit: 1 });
            const entry = auditLogs.entries.first();
            if (entry && entry.target.id === role.id) {
                creator = `[${entry.executor.username}](https://discord.com/users/${entry.executor.id})`;
            }
        } catch (error) {
            console.error('Failed to fetch audit logs:', error);
        }

        const userStat = `Le rôle **${roleName}** (\`${roleId}\`) a été supprimé par ${creator}. Couleur du rôle : ${roleColor}.`;

        const Embed = new Discord.EmbedBuilder()
            .setColor(color)
            .setTitle('Rôle Supprimé')
            .setDescription(userStat)
            .setFooter(client.footer)
            .setTimestamp();

        chan.send({ embeds: [Embed] });
    },
};
