const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberAdd',
    run: async (client, member) => {
        // Récupère les données de membre partiel si nécessaire
        if (member.partial) member = await member.fetch();

        // Récupère les invitations actuelles et les données d'URL personnalisées
        const newInvites = await member.guild.invites.fetch();
        if (member.guild.vanityURLCode) {
            newInvites.set(member.guild.vanityURLCode, await member.guild.fetchVanityData());
        }

        // Recherche l'invitation utilisée par le membre
        let usedInvite = newInvites.find(i =>
            (client.db.has(`invite_${member.guild.id}.${i.code}`) &&
                client.db.get(`invite_${member.guild.id}.${i.code}.uses`) < i.uses) ||
            (client.db.get(`url_${member.guild.id}.url`) === i.code)
        );

        if (usedInvite && usedInvite.inviter) {
            const inviterId = usedInvite.inviter.id;
            const invitesOfUser = await client.db.get(`invites_${inviterId}_${member.guild.id}`) || {
                total: 0,
                valid: 0,
                left: 0,
                bonus: 0
            };
        
            invitesOfUser.total++;
            invitesOfUser.valid++;
        
            await client.db.set(`invites_${inviterId}_${member.guild.id}`, invitesOfUser);
            await client.db.set(`invitedby_${member.guild.id}_${member.id}`, inviterId);
            await client.db.set(`invite_${member.guild.id}.${usedInvite.code}.uses`, usedInvite.uses);
        } else if (usedInvite && usedInvite.code === member.guild.vanityURLCode) {
            await client.db.set(`invitedby_${member.guild.id}_${member.id}`, "vanity");
        } else {
            console.warn('Impossible de trouver l’inviteur pour cette invitation.');
        }
        
        // Obtenez la couleur configurée du serveur et le canal de journalisation
        const color = client.db.get(`color_${member.guild.id}`) || client.config.default_color;
        const channelID = client.db.get(`joinsleave_${member.guild.id}`);

        if (channelID) {
            const logChannel = member.guild.channels.cache.get(channelID);
            if (logChannel) {
                const inviterID = await client.db.get(`invitedby_${member.guild.id}_${member.id}`);
                const urlData = await client.db.get(`url_${member.guild.id}`);
                let joinMessage = "";

                if (inviterID === "vanity") {
                    joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur via l'URL personnalisée, utilisations de l'URL : \`${member.guild.vanityURLUses || (urlData ? urlData.uses : 0)}\``;
                } else if (inviterID) {
                    const inviter = member.guild.members.cache.get(inviterID);
                    if (member.user.bot) {
                        joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur via l'API OAuth2.`;
                    } else if (inviter) {
                        joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur, invité par ${inviter} (\`${inviter.id}\`).`;
                    } else {
                        joinMessage = `${member} (\`${member.id}\`) a rejoint le serveur, mais je ne peux pas déterminer qui l'a invité.`;
                    }
                }

                // Vérifie que joinMessage n'est pas vide
                const joinEmbed = new EmbedBuilder()
                    .setColor(color)
                    .setDescription(joinMessage || "Un membre a rejoint le serveur.")
                    .setFooter({ text: `Nous sommes maintenant : ${member.guild.memberCount}` });

                logChannel.send({ embeds: [joinEmbed] });
            }
        }

        // Gère le message de bienvenue si les paramètres de jointure sont activés
        const db = client.db.get(`joinsettings_${member.guild.id}`);
        if (!db || db.status === false) return;

        const welcomeChannel = client.channels.cache.get(db.channel);
        if (!usedInvite) return;

        const inviter = usedInvite.inviter;
        const invitesOfUser = inviter ? await client.db.get(`invites_${inviter.id}_${member.guild.id}`) || { total: 0, valid: 0, left: 0, bonus: 0 } : {
            total: 0,
            valid: 0,
            left: 0,
            bonus: 0
        };

        let joinMessageTemplate = db.message;

        let toSend = joinMessageTemplate
            .replaceAll('{user.id}', member.user.id)
            .replaceAll('{user.tag}', member.user.tag)
            .replaceAll('{user.username}', member.user.username)
            .replaceAll('{user}', member.user)
            .replaceAll('{inviter.id}', inviter ? inviter.id : 'N/A')
            .replaceAll('{inviter.username}', inviter ? inviter.user.username : 'Unknown')
            .replaceAll('{inviter.tag}', inviter ? inviter.user.tag : 'Unknown')
            .replaceAll('{inviter}', inviter ? inviter : 'Unknown')
            .replaceAll('{inviter.total}', invitesOfUser.total)
            .replaceAll('{inviter.valid}', invitesOfUser.valid)
            .replaceAll('{inviter.invalide}', invitesOfUser.left)
            .replaceAll('{inviter.bonus}', invitesOfUser.bonus)
            .replaceAll('{guild.name}', member.guild.name)
            .replaceAll('{guild.id}', member.guild.id)
            .replaceAll('{guild.count}', member.guild.memberCount);

        if (welcomeChannel) {
            welcomeChannel.send(toSend);
        }
    }
};
